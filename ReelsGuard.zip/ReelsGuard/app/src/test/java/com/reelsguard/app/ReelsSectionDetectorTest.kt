package com.reelsguard.app

import com.reelsguard.app.model.Platform
import com.reelsguard.app.service.ReelsSectionDetector
import com.reelsguard.app.service.ScreenSignalSnapshot
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ReelsSectionDetectorTest {

    @Test
    fun instagramReels_withClipsViewerId_isDetected() {
        val snapshot = ScreenSignalSnapshot(
            packageName = "com.instagram.android",
            viewIds = listOf("com.instagram.android:id/clips_viewer_view_pager"),
            contentDescriptions = listOf("Like", "Comment", "Original audio")
        )
        val result = ReelsSectionDetector.detect(snapshot)
        assertEquals(Platform.INSTAGRAM, result.platform)
        assertTrue(result.isShortFormSection)
    }

    @Test
    fun instagramDirectMessages_isNotDetectedAsReels() {
        val snapshot = ScreenSignalSnapshot(
            packageName = "com.instagram.android",
            viewIds = listOf("com.instagram.android:id/direct_thread_view", "com.instagram.android:id/message_composer"),
            contentDescriptions = listOf("Send message")
        )
        val result = ReelsSectionDetector.detect(snapshot)
        assertEquals(Platform.INSTAGRAM, result.platform)
        assertFalse(result.isShortFormSection)
    }

    @Test
    fun youtubeShorts_withReelRecycler_isDetected() {
        val snapshot = ScreenSignalSnapshot(
            packageName = "com.google.android.youtube",
            viewIds = listOf("com.google.android.youtube:id/reel_recycler"),
            contentDescriptions = listOf("Remix this Short")
        )
        val result = ReelsSectionDetector.detect(snapshot)
        assertEquals(Platform.YOUTUBE, result.platform)
        assertTrue(result.isShortFormSection)
    }

    @Test
    fun youtubeLongFormVideo_isExcludedFromShorts() {
        val snapshot = ScreenSignalSnapshot(
            packageName = "com.google.android.youtube",
            viewIds = listOf("com.google.android.youtube:id/watch_while_time_bar"),
            textSnippets = listOf("Shorts"),
            contentDescriptions = listOf("Subscribe", "Pause video")
        )
        val result = ReelsSectionDetector.detect(snapshot)
        assertEquals(Platform.YOUTUBE, result.platform)
        assertFalse(result.isShortFormSection)
    }

    @Test
    fun facebookReels_withShortsId_isDetected() {
        val snapshot = ScreenSignalSnapshot(
            packageName = "com.facebook.katana",
            viewIds = listOf("com.facebook.katana:id/fb_shorts_viewer_container"),
            contentDescriptions = listOf("Like", "Share")
        )
        val result = ReelsSectionDetector.detect(snapshot)
        assertEquals(Platform.FACEBOOK, result.platform)
        assertTrue(result.isShortFormSection)
    }

    @Test
    fun unrelatedApp_returnsNullPlatformAndFalse() {
        val snapshot = ScreenSignalSnapshot(
            packageName = "com.android.settings",
            viewIds = listOf("android:id/list")
        )
        val result = ReelsSectionDetector.detect(snapshot)
        assertNull(result.platform)
        assertFalse(result.isShortFormSection)
    }
}
