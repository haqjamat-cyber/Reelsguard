package com.reelsguard.app

import com.reelsguard.app.database.entity.DailySummaryEntity
import com.reelsguard.app.model.BadgeType
import com.reelsguard.app.repository.AchievementEvaluator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AchievementEvaluatorTest {

    @Test
    fun consecutiveGoalMetDays_computesStreakAndUnlocksBadges() {
        val summaries = listOf(
            DailySummaryEntity(dateKey = "2026-11-22", totalVerifiedSeconds = 600, goalMet = true, blockEventsCount = 0),
            DailySummaryEntity(dateKey = "2026-11-23", totalVerifiedSeconds = 900, goalMet = true, blockEventsCount = 1),
            DailySummaryEntity(dateKey = "2026-11-24", totalVerifiedSeconds = 500, goalMet = true, blockEventsCount = 0)
        )

        val (progress, badges) = AchievementEvaluator.calculateProgress(summaries)
        assertEquals(3, progress.currentStreak)
        assertEquals(3, progress.bestStreak)
        assertEquals(3, progress.weeklyGoalMetCount)

        val badgeMap = badges.associateBy { it.badgeId }
        assertTrue(badgeMap[BadgeType.FIRST_MINDFUL_DAY.id]!!.isUnlocked)
        assertTrue(badgeMap[BadgeType.STREAK_3.id]!!.isUnlocked)
        assertTrue(badgeMap[BadgeType.ZERO_BLOCK_DAY.id]!!.isUnlocked)
    }

    @Test
    fun brokenStreak_resetsCurrentStreakButRetainsBestStreak() {
        val summaries = listOf(
            DailySummaryEntity(dateKey = "2026-11-20", totalVerifiedSeconds = 400, goalMet = true),
            DailySummaryEntity(dateKey = "2026-11-21", totalVerifiedSeconds = 400, goalMet = true),
            DailySummaryEntity(dateKey = "2026-11-22", totalVerifiedSeconds = 400, goalMet = true),
            DailySummaryEntity(dateKey = "2026-11-23", totalVerifiedSeconds = 3600, goalMet = false),
            DailySummaryEntity(dateKey = "2026-11-24", totalVerifiedSeconds = 300, goalMet = true)
        )

        val (progress, _) = AchievementEvaluator.calculateProgress(summaries)
        assertEquals(1, progress.currentStreak)
        assertEquals(3, progress.bestStreak)
    }
}
