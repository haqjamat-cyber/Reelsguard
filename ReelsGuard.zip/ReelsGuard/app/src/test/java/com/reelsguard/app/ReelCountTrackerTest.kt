package com.reelsguard.app

import com.reelsguard.app.model.Platform
import com.reelsguard.app.service.ReelCountTracker
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ReelCountTrackerTest {

    @Test
    fun halfWatchedOrSkippedVideo_isNeverCounted() {
        val tracker = ReelCountTracker()

        // Enter Reels -> never counts immediately
        assertFalse(tracker.onObservation(Platform.INSTAGRAM, isShortFormSection = true, nowMs = 0L, playbackProgressFraction = 0.05f, videoFingerprint = "vid1"))
        // Watch only 45% (6 seconds) and swipe away
        assertFalse(tracker.onObservation(Platform.INSTAGRAM, isShortFormSection = true, nowMs = 2_000L, playbackProgressFraction = 0.20f, videoFingerprint = "vid1"))
        assertFalse(tracker.onObservation(Platform.INSTAGRAM, isShortFormSection = true, nowMs = 4_000L, playbackProgressFraction = 0.35f, videoFingerprint = "vid1"))
        assertFalse(tracker.onObservation(Platform.INSTAGRAM, isShortFormSection = true, nowMs = 6_000L, playbackProgressFraction = 0.45f, videoFingerprint = "vid1"))
        // Skip to next video -> MUST NOT COUNT!
        assertFalse(tracker.onObservation(Platform.INSTAGRAM, isShortFormSection = true, nowMs = 6_500L, playbackProgressFraction = 0.02f, videoFingerprint = "vid2", isVerticalScrollEvent = true))
    }

    @Test
    fun fullVideoWithProgressBar_countsExactlyOnceAndNeverDoubleCountsOnLoop() {
        val tracker = ReelCountTracker()

        assertFalse(tracker.onObservation(Platform.YOUTUBE, isShortFormSection = true, nowMs = 0L, playbackProgressFraction = 0.05f, videoFingerprint = "short1"))
        assertFalse(tracker.onObservation(Platform.YOUTUBE, isShortFormSection = true, nowMs = 2_000L, playbackProgressFraction = 0.35f, videoFingerprint = "short1"))
        assertFalse(tracker.onObservation(Platform.YOUTUBE, isShortFormSection = true, nowMs = 4_000L, playbackProgressFraction = 0.65f, videoFingerprint = "short1"))
        // Reaches >= 90% after >= 4s -> COUNTS +1
        assertTrue(tracker.onObservation(Platform.YOUTUBE, isShortFormSection = true, nowMs = 6_000L, playbackProgressFraction = 0.92f, videoFingerprint = "short1"))

        // Same video loops and plays again -> NEVER double counts!
        assertFalse(tracker.onObservation(Platform.YOUTUBE, isShortFormSection = true, nowMs = 7_000L, playbackProgressFraction = 0.05f, videoFingerprint = "short1"))
        assertFalse(tracker.onObservation(Platform.YOUTUBE, isShortFormSection = true, nowMs = 11_000L, playbackProgressFraction = 0.95f, videoFingerprint = "short1"))

        // Swipe to genuinely new video #2 and watch it fully -> COUNTS +1 again
        assertFalse(tracker.onObservation(Platform.YOUTUBE, isShortFormSection = true, nowMs = 12_000L, playbackProgressFraction = 0.05f, videoFingerprint = "short2", isVerticalScrollEvent = true))
        assertFalse(tracker.onObservation(Platform.YOUTUBE, isShortFormSection = true, nowMs = 14_000L, playbackProgressFraction = 0.45f, videoFingerprint = "short2"))
        assertTrue(tracker.onObservation(Platform.YOUTUBE, isShortFormSection = true, nowMs = 16_500L, playbackProgressFraction = 0.91f, videoFingerprint = "short2"))
    }

    @Test
    fun noProgressBar_requiresFullContinuousWatchAndIgnoresShortSkips() {
        val tracker = ReelCountTracker(fullWatchFallbackMs = 15_000L)

        // Start video 1 with no SeekBar exposed
        assertFalse(tracker.onObservation(Platform.INSTAGRAM, isShortFormSection = true, nowMs = 0L, videoFingerprint = "reelA"))
        // Watch 8 seconds and skip -> NOT counted
        var t = 1_000L
        while (t <= 8_000L) {
            assertFalse(tracker.onObservation(Platform.INSTAGRAM, isShortFormSection = true, nowMs = t, videoFingerprint = "reelA"))
            t += 1_000L
        }
        assertFalse(tracker.onObservation(Platform.INSTAGRAM, isShortFormSection = true, nowMs = 8_500L, videoFingerprint = "reelB", isVerticalScrollEvent = true))

        // Watch video 2 for full 15 seconds -> counted ONCE at 15s, never again at 18s
        var countedTimes = 0
        for (sec in 1..20) {
            if (tracker.onObservation(Platform.INSTAGRAM, isShortFormSection = true, nowMs = 8_500L + sec * 1_000L, videoFingerprint = "reelB")) {
                countedTimes++
            }
        }
        assertTrue(countedTimes == 1)
    }

    @Test
    fun pausedVideo_doesNotCountTowardFullWatch() {
        val tracker = ReelCountTracker(fullWatchFallbackMs = 15_000L)

        assertFalse(tracker.onObservation(Platform.INSTAGRAM, isShortFormSection = true, nowMs = 0L, isVideoPaused = false, videoFingerprint = "reelP"))
        for (sec in 1..25) {
            assertFalse(tracker.onObservation(Platform.INSTAGRAM, isShortFormSection = true, nowMs = sec * 1_000L, isVideoPaused = true, videoFingerprint = "reelP"))
        }
    }
}
