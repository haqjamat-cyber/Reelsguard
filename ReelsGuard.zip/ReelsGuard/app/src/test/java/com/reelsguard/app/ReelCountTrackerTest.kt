package com.reelsguard.app

import com.reelsguard.app.model.Platform
import com.reelsguard.app.service.ReelCountTracker
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ReelCountTrackerTest {

    @Test
    fun enteringShortForm_countsFirstVideoOnceAndDebouncesRapidScrolls() {
        val tracker = ReelCountTracker(swipeDebounceMs = 1_800L, reentryGraceMs = 3_000L)

        assertFalse(tracker.onSignal(Platform.INSTAGRAM, isShortFormSection = false, isVerticalScrollEvent = true, nowMs = 1_000L))
        assertTrue(tracker.onSignal(Platform.INSTAGRAM, isShortFormSection = true, isVerticalScrollEvent = false, nowMs = 5_000L))
        assertFalse(tracker.onSignal(Platform.INSTAGRAM, isShortFormSection = true, isVerticalScrollEvent = true, nowMs = 5_400L))
        assertFalse(tracker.onSignal(Platform.INSTAGRAM, isShortFormSection = true, isVerticalScrollEvent = true, nowMs = 6_200L))
        assertTrue(tracker.onSignal(Platform.INSTAGRAM, isShortFormSection = true, isVerticalScrollEvent = true, nowMs = 7_000L))
    }

    @Test
    fun briefFlickerExitAndReentry_doesNotDoubleCountSameVideo() {
        val tracker = ReelCountTracker(swipeDebounceMs = 1_800L, reentryGraceMs = 3_000L)

        assertTrue(tracker.onSignal(Platform.YOUTUBE, isShortFormSection = true, isVerticalScrollEvent = false, nowMs = 10_000L))
        assertFalse(tracker.onSignal(Platform.YOUTUBE, isShortFormSection = false, isVerticalScrollEvent = false, nowMs = 11_000L))
        assertFalse(tracker.onSignal(Platform.YOUTUBE, isShortFormSection = true, isVerticalScrollEvent = false, nowMs = 12_500L))
    }

    @Test
    fun switchingPlatforms_countsNewPlatformEntry() {
        val tracker = ReelCountTracker(swipeDebounceMs = 1_800L, reentryGraceMs = 3_000L)

        assertTrue(tracker.onSignal(Platform.INSTAGRAM, isShortFormSection = true, isVerticalScrollEvent = false, nowMs = 10_000L))
        assertTrue(tracker.onSignal(Platform.FACEBOOK, isShortFormSection = true, isVerticalScrollEvent = false, nowMs = 13_000L))
    }
}
