package com.reelsguard.app

import com.reelsguard.app.utils.TimeFormatter
import org.junit.Assert.assertEquals
import org.junit.Test

class TimeFormatterTest {

    @Test
    fun formatDurationCompact_handlesSecondsMinutesHours() {
        assertEquals("0s", TimeFormatter.formatDurationCompact(0L))
        assertEquals("45s", TimeFormatter.formatDurationCompact(45L))
        assertEquals("1m", TimeFormatter.formatDurationCompact(60L))
        assertEquals("1m 15s", TimeFormatter.formatDurationCompact(75L))
        assertEquals("1h 1m", TimeFormatter.formatDurationCompact(3665L))
    }

    @Test
    fun formatCountdown_formatsZeroPaddedHMS() {
        assertEquals("01:02:03", TimeFormatter.formatCountdown((3600L + 120L + 3L) * 1000L))
        assertEquals("00:00:00", TimeFormatter.formatCountdown(-500L))
    }
}
