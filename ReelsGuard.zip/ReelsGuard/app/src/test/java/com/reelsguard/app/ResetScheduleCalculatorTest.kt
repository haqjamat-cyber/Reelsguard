package com.reelsguard.app

import com.reelsguard.app.utils.ResetScheduleCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

class ResetScheduleCalculatorTest {

    @Test
    fun midnightReset_returnsCurrentLocalDate() {
        val now = ZonedDateTime.of(2026, 11, 25, 14, 30, 0, 0, ZoneId.of("Asia/Kolkata"))
        val dateKey = ResetScheduleCalculator.getCurrentCycleDateKey(now, resetHour = 0, resetMinute = 0)
        assertEquals("2026-11-25", dateKey)
    }

    @Test
    fun customResetTime_beforeBoundary_belongsToPreviousDayCycle() {
        val now = ZonedDateTime.of(2026, 11, 25, 2, 15, 0, 0, ZoneId.of("Asia/Kolkata"))
        val dateKey = ResetScheduleCalculator.getCurrentCycleDateKey(now, resetHour = 4, resetMinute = 0)
        assertEquals("2026-11-24", dateKey)
    }

    @Test
    fun customResetTime_atOrAfterBoundary_belongsToCurrentDayCycle() {
        val now = ZonedDateTime.of(2026, 11, 25, 4, 0, 0, 0, ZoneId.of("Asia/Kolkata"))
        val dateKey = ResetScheduleCalculator.getCurrentCycleDateKey(now, resetHour = 4, resetMinute = 0)
        assertEquals("2026-11-25", dateKey)
    }

    @Test
    fun nextResetDateTime_sameDayWhenBeforeResetTime() {
        val zone = ZoneId.of("UTC")
        val now = ZonedDateTime.of(2026, 11, 25, 1, 0, 0, 0, zone)
        val next = ResetScheduleCalculator.getNextResetDateTime(now, resetHour = 3, resetMinute = 30)
        assertEquals(ZonedDateTime.of(2026, 11, 25, 3, 30, 0, 0, zone), next)
    }

    @Test
    fun nextResetDateTime_nextDayWhenAfterResetTime() {
        val zone = ZoneId.of("America/New_York")
        val now = ZonedDateTime.of(2026, 11, 25, 22, 0, 0, 0, zone)
        val next = ResetScheduleCalculator.getNextResetDateTime(now, resetHour = 0, resetMinute = 0)
        assertEquals(ZonedDateTime.of(2026, 11, 26, 0, 0, 0, 0, zone), next)
    }

    @Test
    fun timezoneShift_recomputesCycleKeyAccurately() {
        // 2026-11-25 20:00 UTC is 2026-11-26 01:30 IST
        val utcInstant = ZonedDateTime.of(2026, 11, 25, 20, 0, 0, 0, ZoneId.of("UTC"))
        val istInstant = utcInstant.withZoneSameInstant(ZoneId.of("Asia/Kolkata"))

        assertEquals("2026-11-25", ResetScheduleCalculator.getCurrentCycleDateKey(utcInstant, 0, 0))
        assertEquals("2026-11-26", ResetScheduleCalculator.getCurrentCycleDateKey(istInstant, 0, 0))
    }

    @Test
    fun millisUntilNextReset_isAlwaysPositive() {
        val now = ZonedDateTime.of(2026, 11, 25, 23, 59, 59, 0, ZoneId.of("UTC"))
        val delay = ResetScheduleCalculator.millisUntilNextReset(now, 0, 0)
        assertTrue(delay >= 1_000L)
    }
}
