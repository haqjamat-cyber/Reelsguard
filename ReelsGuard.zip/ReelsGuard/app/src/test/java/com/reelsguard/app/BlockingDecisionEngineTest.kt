package com.reelsguard.app

import com.reelsguard.app.database.entity.PlatformLimitEntity
import com.reelsguard.app.model.BlockMode
import com.reelsguard.app.model.Platform
import com.reelsguard.app.service.BlockingDecision
import com.reelsguard.app.service.BlockingDecisionEngine
import org.junit.Assert.assertTrue
import org.junit.Test

class BlockingDecisionEngineTest {

    @Test
    fun missingAccessibilityPermission_neverClaimsBlockSuccess() {
        val limit = PlatformLimitEntity(
            platform = Platform.INSTAGRAM,
            isTrackingEnabled = true,
            isLimitEnabled = true,
            dailyLimitMinutes = 20,
            blockMode = BlockMode.SECTION_ONLY
        )
        val decision = BlockingDecisionEngine.evaluate(
            hasAccessibilityPermission = false,
            platform = Platform.INSTAGRAM,
            limitConfig = limit,
            isShortFormSectionDetected = true,
            platformUsedSeconds = 25L * 60L,
            totalUsedSecondsAcrossPlatforms = 25L * 60L,
            totalDailyLimitMinutes = 45,
            isTotalDailyLimitEnabled = true
        )
        assertTrue(decision is BlockingDecision.PermissionRequired)
    }

    @Test
    fun sectionOnlyMode_blocksOnlyWhenShortFormDetectedAndLimitReached() {
        val limit = PlatformLimitEntity(
            platform = Platform.YOUTUBE,
            isTrackingEnabled = true,
            isLimitEnabled = true,
            dailyLimitMinutes = 15,
            blockMode = BlockMode.SECTION_ONLY
        )

        val outsideShorts = BlockingDecisionEngine.evaluate(
            hasAccessibilityPermission = true,
            platform = Platform.YOUTUBE,
            limitConfig = limit,
            isShortFormSectionDetected = false,
            platformUsedSeconds = 16L * 60L,
            totalUsedSecondsAcrossPlatforms = 16L * 60L,
            totalDailyLimitMinutes = 45,
            isTotalDailyLimitEnabled = true
        )
        assertTrue(outsideShorts is BlockingDecision.Allow)

        val insideShorts = BlockingDecisionEngine.evaluate(
            hasAccessibilityPermission = true,
            platform = Platform.YOUTUBE,
            limitConfig = limit,
            isShortFormSectionDetected = true,
            platformUsedSeconds = 16L * 60L,
            totalUsedSecondsAcrossPlatforms = 16L * 60L,
            totalDailyLimitMinutes = 45,
            isTotalDailyLimitEnabled = true
        )
        assertTrue(insideShorts is BlockingDecision.Block)
    }

    @Test
    fun fullAppFallbackMode_blocksEvenWithoutSectionSignalWhenLimitReached() {
        val limit = PlatformLimitEntity(
            platform = Platform.FACEBOOK,
            isTrackingEnabled = true,
            isLimitEnabled = true,
            dailyLimitMinutes = 10,
            blockMode = BlockMode.FULL_APP_FALLBACK
        )

        val decision = BlockingDecisionEngine.evaluate(
            hasAccessibilityPermission = true,
            platform = Platform.FACEBOOK,
            limitConfig = limit,
            isShortFormSectionDetected = false,
            platformUsedSeconds = 10L * 60L,
            totalUsedSecondsAcrossPlatforms = 10L * 60L,
            totalDailyLimitMinutes = 45,
            isTotalDailyLimitEnabled = true
        )
        assertTrue(decision is BlockingDecision.Block)
    }

    @Test
    fun totalDailyLimit_blocksEvenWhenIndividualLimitNotExceeded() {
        val limit = PlatformLimitEntity(
            platform = Platform.INSTAGRAM,
            isTrackingEnabled = true,
            isLimitEnabled = true,
            dailyLimitMinutes = 30,
            blockMode = BlockMode.SECTION_ONLY
        )

        val decision = BlockingDecisionEngine.evaluate(
            hasAccessibilityPermission = true,
            platform = Platform.INSTAGRAM,
            limitConfig = limit,
            isShortFormSectionDetected = true,
            platformUsedSeconds = 20L * 60L,
            totalUsedSecondsAcrossPlatforms = 46L * 60L,
            totalDailyLimitMinutes = 45,
            isTotalDailyLimitEnabled = true
        )
        assertTrue(decision is BlockingDecision.Block)
    }

    @Test
    fun disabledTracking_allowsAccess() {
        val limit = PlatformLimitEntity(
            platform = Platform.INSTAGRAM,
            isTrackingEnabled = false,
            isLimitEnabled = true,
            dailyLimitMinutes = 10,
            blockMode = BlockMode.FULL_APP_FALLBACK
        )
        val decision = BlockingDecisionEngine.evaluate(
            hasAccessibilityPermission = true,
            platform = Platform.INSTAGRAM,
            limitConfig = limit,
            isShortFormSectionDetected = true,
            platformUsedSeconds = 30L * 60L,
            totalUsedSecondsAcrossPlatforms = 30L * 60L,
            totalDailyLimitMinutes = 45,
            isTotalDailyLimitEnabled = true
        )
        assertTrue(decision is BlockingDecision.Allow)
    }
}
