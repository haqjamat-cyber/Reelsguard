package com.reelsguard.app

import com.reelsguard.app.database.entity.PlatformLimitEntity
import com.reelsguard.app.model.BlockMode
import com.reelsguard.app.model.Platform
import com.reelsguard.app.service.BlockingDecision
import com.reelsguard.app.service.BlockingDecisionEngine
import org.junit.Assert.assertTrue
import org.junit.Test

class BlockingDecisionEngineTest {

    @Test
    fun missingAccessibilityPermission_neverClaimsBlockSuccess() {
        val limit = PlatformLimitEntity(
            platform = Platform.INSTAGRAM,
            isTrackingEnabled = true,
            isLimitEnabled = true,
            dailyVideoLimit = 10,
            blockMode = BlockMode.SECTION_ONLY
        )
        val decision = BlockingDecisionEngine.evaluate(
            hasAccessibilityPermission = false,
            platform = Platform.INSTAGRAM,
            limitConfig = limit,
            isShortFormSectionDetected = true,
            platformWatchedVideos = 12,
            totalWatchedVideosAcrossPlatforms = 12,
            totalDailyVideoLimit = 15,
            isTotalDailyLimitEnabled = true
        )
        assertTrue(decision is BlockingDecision.PermissionRequired)
    }

    @Test
    fun unsetVideoTarget_allowsWatchingUntilUserTypesTarget() {
        val limit = PlatformLimitEntity(
            platform = Platform.YOUTUBE,
            isTrackingEnabled = true,
            isLimitEnabled = false,
            dailyVideoLimit = 0,
            blockMode = BlockMode.SECTION_ONLY
        )
        val decision = BlockingDecisionEngine.evaluate(
            hasAccessibilityPermission = true,
            platform = Platform.YOUTUBE,
            limitConfig = limit,
            isShortFormSectionDetected = true,
            platformWatchedVideos = 50,
            totalWatchedVideosAcrossPlatforms = 50,
            totalDailyVideoLimit = 0,
            isTotalDailyLimitEnabled = false
        )
        assertTrue(decision is BlockingDecision.Allow)
    }

    @Test
    fun sectionOnlyMode_blocksOnlyWhenShortFormDetectedAndVideoTargetReached() {
        val limit = PlatformLimitEntity(
            platform = Platform.YOUTUBE,
            isTrackingEnabled = true,
            isLimitEnabled = true,
            dailyVideoLimit = 10,
            blockMode = BlockMode.SECTION_ONLY
        )

        val outsideShorts = BlockingDecisionEngine.evaluate(
            hasAccessibilityPermission = true,
            platform = Platform.YOUTUBE,
            limitConfig = limit,
            isShortFormSectionDetected = false,
            platformWatchedVideos = 10,
            totalWatchedVideosAcrossPlatforms = 10,
            totalDailyVideoLimit = 0,
            isTotalDailyLimitEnabled = false
        )
        assertTrue(outsideShorts is BlockingDecision.Allow)

        val insideShorts = BlockingDecisionEngine.evaluate(
            hasAccessibilityPermission = true,
            platform = Platform.YOUTUBE,
            limitConfig = limit,
            isShortFormSectionDetected = true,
            platformWatchedVideos = 10,
            totalWatchedVideosAcrossPlatforms = 10,
            totalDailyVideoLimit = 0,
            isTotalDailyLimitEnabled = false
        )
        assertTrue(insideShorts is BlockingDecision.Block)
    }

    @Test
    fun totalDailyVideoLimit_blocksEvenWhenIndividualLimitNotSet() {
        val limit = PlatformLimitEntity(
            platform = Platform.INSTAGRAM,
            isTrackingEnabled = true,
            isLimitEnabled = false,
            dailyVideoLimit = 0,
            blockMode = BlockMode.SECTION_ONLY
        )

        val decision = BlockingDecisionEngine.evaluate(
            hasAccessibilityPermission = true,
            platform = Platform.INSTAGRAM,
            limitConfig = limit,
            isShortFormSectionDetected = true,
            platformWatchedVideos = 6,
            totalWatchedVideosAcrossPlatforms = 15,
            totalDailyVideoLimit = 15,
            isTotalDailyLimitEnabled = true
        )
        assertTrue(decision is BlockingDecision.Block)
    }
}
