package com.reelsguard.app

import android.content.Context
import com.reelsguard.app.data.UserPreferencesRepository
import com.reelsguard.app.database.ReelsGuardDatabase
import com.reelsguard.app.repository.AchievementRepository
import com.reelsguard.app.repository.AnalyticsRepository
import com.reelsguard.app.repository.UsageRepository
import com.reelsguard.app.service.UsageStatsSyncManager

/**
 * Lightweight manual dependency injection container for clean MVVM wiring and effortless testing.
 */
class AppContainer(context: Context) {

    val appContext: Context = context.applicationContext

    val database: ReelsGuardDatabase by lazy {
        ReelsGuardDatabase.getInstance(appContext)
    }

    val preferencesRepository: UserPreferencesRepository by lazy {
        UserPreferencesRepository(appContext)
    }

    val usageStatsSyncManager: UsageStatsSyncManager by lazy {
        UsageStatsSyncManager(appContext)
    }

    val achievementRepository: AchievementRepository by lazy {
        AchievementRepository(
            achievementDao = database.achievementDao(),
            dailySummaryDao = database.dailySummaryDao()
        )
    }

    val usageRepository: UsageRepository by lazy {
        UsageRepository(
            context = appContext,
            dailyUsageDao = database.dailyUsageDao(),
            platformLimitDao = database.platformLimitDao(),
            blockingEventDao = database.blockingEventDao(),
            dailySummaryDao = database.dailySummaryDao(),
            achievementDao = database.achievementDao(),
            preferencesRepository = preferencesRepository,
            usageStatsSyncManager = usageStatsSyncManager,
            achievementRepository = achievementRepository
        )
    }

    val analyticsRepository: AnalyticsRepository by lazy {
        AnalyticsRepository(
            dailyUsageDao = database.dailyUsageDao(),
            dailySummaryDao = database.dailySummaryDao(),
            blockingEventDao = database.blockingEventDao(),
            preferencesRepository = preferencesRepository
        )
    }
}
