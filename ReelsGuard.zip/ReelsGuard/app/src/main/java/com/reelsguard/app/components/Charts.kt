package com.reelsguard.app.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.patrykandpatrick.vico.compose.axis.horizontal.rememberBottomAxis
import com.patrykandpatrick.vico.compose.axis.vertical.rememberStartAxis
import com.patrykandpatrick.vico.compose.chart.Chart
import com.patrykandpatrick.vico.compose.chart.column.columnChart
import com.patrykandpatrick.vico.compose.chart.line.lineChart
import com.patrykandpatrick.vico.compose.m3.style.m3ChartStyle
import com.patrykandpatrick.vico.compose.style.ProvideChartStyle
import com.patrykandpatrick.vico.core.axis.AxisPosition
import com.patrykandpatrick.vico.core.axis.formatter.AxisValueFormatter
import com.patrykandpatrick.vico.core.entry.ChartEntryModelProducer
import com.patrykandpatrick.vico.core.entry.entryOf
import com.reelsguard.app.model.DailyChartPoint
import com.reelsguard.app.model.PlatformComparisonItem
import com.reelsguard.app.ui.theme.ReelsGuardTheme
import com.reelsguard.app.utils.TimeFormatter

/**
 * Weekly column chart built with Vico Compose M3.
 */
@Composable
fun WeeklyUsageBarChart(
    points: List<DailyChartPoint>,
    modifier: Modifier = Modifier
) {
    val extra = ReelsGuardTheme.colors
    val safePoints = if (points.isEmpty()) {
        listOf(DailyChartPoint("", "Today", 0f, 0f, 0f, true))
    } else {
        points
    }

    val modelProducer = remember { ChartEntryModelProducer() }
    LaunchedEffect(safePoints) {
        val entries = safePoints.mapIndexed { index, point ->
            entryOf(index.toFloat(), point.totalMinutes)
        }
        modelProducer.setEntries(entries)
    }

    val bottomFormatter = remember(safePoints) {
        AxisValueFormatter<AxisPosition.Horizontal.Bottom> { value, _ ->
            safePoints.getOrNull(value.toInt())?.shortLabel.orEmpty()
        }
    }

    val startFormatter = remember {
        AxisValueFormatter<AxisPosition.Vertical.Start> { value, _ ->
            "${value.toInt()}m"
        }
    }

    ProvideChartStyle(
        m3ChartStyle(
            entityColors = listOf(extra.accentPurple, extra.accentBlue)
        )
    ) {
        Chart(
            chart = columnChart(),
            chartModelProducer = modelProducer,
            startAxis = rememberStartAxis(valueFormatter = startFormatter),
            bottomAxis = rememberBottomAxis(valueFormatter = bottomFormatter),
            modifier = modifier
                .fillMaxWidth()
                .height(195.dp)
        )
    }
}

/**
 * Daily platform distribution line/column trend chart using Vico Compose M3.
 */
@Composable
fun MonthlyTrendLineChart(
    points: List<DailyChartPoint>,
    modifier: Modifier = Modifier
) {
    val extra = ReelsGuardTheme.colors
    val safePoints = if (points.size < 2) {
        listOf(
            DailyChartPoint("", "1", 0f, 0f, 0f, true),
            DailyChartPoint("", "2", 0f, 0f, 0f, true)
        )
    } else {
        points
    }

    val modelProducer = remember { ChartEntryModelProducer() }
    LaunchedEffect(safePoints) {
        val entries = safePoints.mapIndexed { index, point ->
            entryOf(index.toFloat(), point.totalMinutes)
        }
        modelProducer.setEntries(entries)
    }

    val bottomFormatter = remember(safePoints) {
        AxisValueFormatter<AxisPosition.Horizontal.Bottom> { value, _ ->
            val idx = value.toInt()
            if (idx == 0 || idx == safePoints.lastIndex || idx % 6 == 0) {
                safePoints.getOrNull(idx)?.dateKey?.takeLast(2).orEmpty()
            } else {
                ""
            }
        }
    }

    val startFormatter = remember {
        AxisValueFormatter<AxisPosition.Vertical.Start> { value, _ ->
            "${value.toInt()}m"
        }
    }

    ProvideChartStyle(
        m3ChartStyle(
            entityColors = listOf(extra.accentBlue, extra.accentCyan)
        )
    ) {
        Chart(
            chart = lineChart(),
            chartModelProducer = modelProducer,
            startAxis = rememberStartAxis(valueFormatter = startFormatter),
            bottomAxis = rememberBottomAxis(valueFormatter = bottomFormatter),
            modifier = modifier
                .fillMaxWidth()
                .height(185.dp)
        )
    }
}

/**
 * Platform-wise comparison bars separating Verified Reels vs Full-App Fallback explicitly.
 */
@Composable
fun PlatformComparisonBars(
    items: List<PlatformComparisonItem>,
    modifier: Modifier = Modifier
) {
    val extra = ReelsGuardTheme.colors
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        items.forEach { item ->
            val accent = Color(item.platform.accentHex)
            val secondary = Color(item.platform.secondaryAccentHex)
            val effectiveSec = if (item.verifiedSeconds > 0L) item.verifiedSeconds else item.fallbackSeconds
            val modeCaption = when {
                item.verifiedSeconds > 0L -> "Verified Reels/Shorts"
                item.fallbackSeconds > 0L -> "Full-App Fallback"
                else -> "No activity recorded"
            }

            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = item.platform.shortFormLabel,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = modeCaption,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = TimeFormatter.formatDurationCompact(effectiveSec),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(CircleShape)
                        .background(extra.subtleTrack)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(item.shareFraction.coerceIn(0f, 1f))
                            .height(8.dp)
                            .clip(CircleShape)
                            .background(Brush.horizontalGradient(listOf(accent, secondary)))
                    )
                }
            }
        }
    }
}

/**
 * 30-day visual discipline grid showing intensity and goal compliance per day.
 */
@Composable
fun MonthlyDisciplineHeatmap(
    points: List<DailyChartPoint>,
    modifier: Modifier = Modifier
) {
    val extra = ReelsGuardTheme.colors
    val rows = points.chunked(7)
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        rows.forEach { weekRow ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                weekRow.forEach { day ->
                    val cellColor = when {
                        day.totalMinutes <= 0f -> extra.subtleTrack
                        day.goalMet && day.totalMinutes < 20f -> extra.success.copy(alpha = 0.65f)
                        day.goalMet -> extra.accentBlue.copy(alpha = 0.72f)
                        else -> extra.danger.copy(alpha = 0.72f)
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(cellColor),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = day.dateKey.takeLast(2),
                            style = MaterialTheme.typography.labelSmall,
                            color = if (day.totalMinutes > 0f) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                repeat(7 - weekRow.size) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            LegendDot(color = extra.success.copy(alpha = 0.75f), label = "Under limit")
            LegendDot(color = extra.accentBlue.copy(alpha = 0.75f), label = "Balanced")
            LegendDot(color = extra.danger.copy(alpha = 0.75f), label = "Over limit")
        }
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Box(
            modifier = Modifier
                .height(8.dp)
                .clip(CircleShape)
                .background(color)
                .padding(horizontal = 4.dp)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
