package com.reelsguard.app.model

/**
 * Defines how ReelsGuard restricts a platform once a limit is reached.
 */
enum class BlockMode(val label: String, val description: String) {
    SECTION_ONLY(
        label = "Reels / Shorts Section",
        description = "Exits the short-form video feed via Accessibility while leaving normal app screens accessible where detectable."
    ),
    FULL_APP_FALLBACK(
        label = "Full App Fallback",
        description = "Blocks the entire selected application when section-specific detection is unavailable or preferred."
    )
}

/**
 * Strictly separates verified Reels/Shorts screen tracking from app-wide UsageStats fallback.
 * ReelsGuard never presents app-wide fallback minutes as verified Reels viewing time.
 */
enum class TrackingConfidence(val label: String, val shortTag: String) {
    VERIFIED_SECTION(
        label = "Verified Reels/Shorts Session",
        shortTag = "Verified Reels"
    ),
    APP_WIDE_FALLBACK(
        label = "Full-App Fallback (Usage Access)",
        shortTag = "Full-App Fallback"
    ),
    UNTRACKED(
        label = "Not Active",
        shortTag = "Inactive"
    )
}

enum class ThemeMode(val label: String) {
    SYSTEM("System Default"),
    DARK("Deep Obsidian Dark"),
    LIGHT("Crisp Light")
}

enum class DisciplineStatus(
    val title: String,
    val subtitle: String
) {
    EXCELLENT(
        title = "Mindful & Balanced",
        subtitle = "You are comfortably within your daily goal."
    ),
    APPROACHING_LIMIT(
        title = "Approaching Daily Cap",
        subtitle = "A few minutes remain. Great moment to wrap up."
    ),
    LIMIT_REACHED(
        title = "Daily Limit Reached",
        subtitle = "Short-form pause active until your next reset."
    ),
    SETUP_REQUIRED(
        title = "Permissions Needed",
        subtitle = "Enable Accessibility or Usage Access to begin tracking."
    )
}

enum class BlockingGuardState(val label: String) {
    ACTIVE_SECTION_GUARD("Section Guard Active"),
    ACTIVE_FALLBACK_GUARD("Full-App Guard Active"),
    PERMISSION_MISSING("Blocking Inactive (Needs Accessibility)"),
    PAUSED_BY_USER("Tracking Paused")
}

enum class BadgeType(
    val id: String,
    val title: String,
    val description: String,
    val targetCount: Int
) {
    FIRST_MINDFUL_DAY(
        id = "first_mindful_day",
        title = "First Mindful Day",
        description = "Finish your first complete day within your configured limit.",
        targetCount = 1
    ),
    STREAK_3(
        id = "streak_3",
        title = "3-Day Focus Rhythm",
        description = "Stay within your daily short-form limit for 3 consecutive days.",
        targetCount = 3
    ),
    STREAK_7(
        id = "streak_7",
        title = "7-Day Reels Guardian",
        description = "Complete a full week of mindful short-form habits.",
        targetCount = 7
    ),
    STREAK_14(
        id = "streak_14",
        title = "14-Day Calm Master",
        description = "Maintain 2 consecutive weeks of balanced viewing.",
        targetCount = 14
    ),
    STREAK_30(
        id = "streak_30",
        title = "30-Day Digital Zen",
        description = "An entire month of consistent digital wellbeing.",
        targetCount = 30
    ),
    WEEKLY_CHAMPION(
        id = "weekly_champion",
        title = "Weekly Discipline Champion",
        description = "Meet your daily goal at least 5 days in a 7-day week.",
        targetCount = 5
    ),
    ZERO_BLOCK_DAY(
        id = "zero_block_day",
        title = "Self-Paced Day",
        description = "Finish a tracked day under your limit without needing a block.",
        targetCount = 1
    )
}
