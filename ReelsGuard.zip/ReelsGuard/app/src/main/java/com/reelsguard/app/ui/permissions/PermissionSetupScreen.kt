package com.reelsguard.app.ui.permissions

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.reelsguard.app.components.GlassCard
import com.reelsguard.app.components.GradientPrimaryButton
import com.reelsguard.app.components.PremiumBackground
import com.reelsguard.app.components.ScreenTopHeader
import com.reelsguard.app.components.StatusPill
import com.reelsguard.app.ui.theme.ReelsGuardTheme
import com.reelsguard.app.utils.PermissionHelper

@Composable
fun PermissionSetupScreen(
    viewModel: PermissionViewModel,
    showBackButton: Boolean,
    onBack: () -> Unit,
    onContinueToDashboard: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val extra = ReelsGuardTheme.colors
    val status by viewModel.status.collectAsStateWithLifecycle()

    var showAccessibilityDisclosure by remember { mutableStateOf(false) }
    var showUsageDisclosure by remember { mutableStateOf(false) }

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        viewModel.refreshPermissions()
    }

    // Re-check real Android system permissions whenever returning from Android Settings
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshPermissions()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    if (showAccessibilityDisclosure) {
        AlertDialog(
            onDismissRequest = { showAccessibilityDisclosure = false },
            icon = {
                Icon(
                    imageVector = Icons.Rounded.AccessibilityNew,
                    contentDescription = null,
                    tint = extra.accentPurple
                )
            },
            title = { Text("Accessibility Service Disclosure") },
            text = {
                Text(
                    text = "ReelsGuard requests Android's Accessibility Service strictly to:\n\n" +
                        "1. Recognize when Instagram Reels, YouTube Shorts, or Facebook Reels are open on screen.\n" +
                        "2. Count verified short-form viewing time against your daily limits.\n" +
                        "3. Show ReelsGuard's pause screen and exit the short-form feed when your limit is reached.\n\n" +
                        "Privacy guarantee: ReelsGuard never reads passwords, chats, or personal messages, never modifies third-party apps internally, and never uploads data off your device.\n\n" +
                        "In Android Settings, locate 'ReelsGuard Focus Monitor' and enable it only if you consent."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showAccessibilityDisclosure = false
                        viewModel.recordAccessibilityConsent()
                        context.startActivity(PermissionHelper.createAccessibilitySettingsIntent())
                    }
                ) {
                    Text("I Understand — Open Settings")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAccessibilityDisclosure = false }) {
                    Text("Not Now")
                }
            }
        )
    }

    if (showUsageDisclosure) {
        AlertDialog(
            onDismissRequest = { showUsageDisclosure = false },
            icon = {
                Icon(
                    imageVector = Icons.Rounded.BarChart,
                    contentDescription = null,
                    tint = extra.accentBlue
                )
            },
            title = { Text("Usage Access Disclosure") },
            text = {
                Text(
                    text = "Android Usage Access (UsageStatsManager) allows ReelsGuard to read app-level foreground duration for Instagram, YouTube, and Facebook.\n\n" +
                        "Important: Android does not separate Reels/Shorts inside Usage Access. ReelsGuard clearly labels these figures as 'Full-App Fallback' and uses them only when section-specific tracking is unavailable."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showUsageDisclosure = false
                        viewModel.recordUsageAccessConsent()
                        context.startActivity(PermissionHelper.createUsageAccessSettingsIntent(context))
                    }
                ) {
                    Text("Open Usage Access")
                }
            },
            dismissButton = {
                TextButton(onClick = { showUsageDisclosure = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    PremiumBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
        ) {
            ScreenTopHeader(
                title = "Permission Setup",
                subtitle = "Transparent, local-only Android permissions",
                onBack = if (showBackButton) onBack else null
            )

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Security,
                            contentDescription = null,
                            tint = extra.success
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "No silent activation. Every special permission requires your explicit approval in Android Settings.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                PermissionItemCard(
                    icon = Icons.Rounded.AccessibilityNew,
                    title = "Accessibility Service",
                    badge = "CORE FOR REELS DETECTION & BLOCKING",
                    description = "Detects Instagram Reels, YouTube Shorts, and Facebook Reels surfaces and triggers the pause screen when your limit is reached.",
                    isGranted = status.isAccessibilityEnabled,
                    actionLabel = if (status.isAccessibilityEnabled) "Manage" else "Review & Enable",
                    onActionClick = { showAccessibilityDisclosure = true }
                )

                PermissionItemCard(
                    icon = Icons.Rounded.BarChart,
                    title = "Usage Access (Fallback Mode)",
                    badge = "RECOMMENDED FALLBACK",
                    description = "Provides whole-app foreground duration via UsageStatsManager when Reels-only section detection is unavailable. Always labeled transparently.",
                    isGranted = status.isUsageAccessGranted,
                    actionLabel = if (status.isUsageAccessGranted) "Manage" else "Review & Enable",
                    onActionClick = { showUsageDisclosure = true }
                )

                PermissionItemCard(
                    icon = Icons.Rounded.Layers,
                    title = "Display Over Other Apps",
                    badge = "OPTIONAL • SMOOTHER BLOCKING",
                    description = "Improves reliability when launching the full-screen blocking interface from background on Android 10+ devices.",
                    isGranted = status.isOverlayGranted,
                    actionLabel = if (status.isOverlayGranted) "Granted" else "Allow",
                    onActionClick = {
                        context.startActivity(PermissionHelper.createOverlaySettingsIntent(context))
                    }
                )

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    PermissionItemCard(
                        icon = Icons.Rounded.Notifications,
                        title = "Notifications",
                        badge = "OPTIONAL",
                        description = "Allows gentle milestone reminders and daily reset confirmations.",
                        isGranted = status.isNotificationGranted,
                        actionLabel = if (status.isNotificationGranted) "Granted" else "Allow",
                        onActionClick = {
                            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
            }

            Spacer(modifier = Modifier.height(10.dp))

            GradientPrimaryButton(
                text = if (status.hasAnyTrackingPermission) "Continue to Dashboard" else "Continue (Setup Later)",
                onClick = onContinueToDashboard,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
private fun PermissionItemCard(
    icon: ImageVector,
    title: String,
    badge: String,
    description: String,
    isGranted: Boolean,
    actionLabel: String,
    onActionClick: () -> Unit
) {
    val extra = ReelsGuardTheme.colors
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        highlightAccent = if (isGranted) extra.success else null
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isGranted) extra.success else extra.accentPurple
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = badge,
                        style = MaterialTheme.typography.labelSmall,
                        color = extra.accentBlue
                    )
                }
            }
            StatusPill(
                text = if (isGranted) "Active" else "Off",
                tint = if (isGranted) extra.success else extra.warning,
                icon = if (isGranted) Icons.Rounded.CheckCircle else null
            )
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = description,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedButton(
            onClick = onActionClick,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = actionLabel)
        }
    }
}
