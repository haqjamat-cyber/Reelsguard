package com.reelsguard.app.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.reelsguard.app.ui.theme.ReelsGuardTheme

@Composable
fun PremiumBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val extra = ReelsGuardTheme.colors
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(extra.backgroundTop, extra.backgroundBottom)
                )
            )
    ) {
        // Subtle top ambient purple-blue glow in dark mode
        if (extra.isDark) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                extra.accentPurple.copy(alpha = 0.14f),
                                extra.accentBlue.copy(alpha = 0.05f),
                                Color.Transparent
                            ),
                            radius = 950f
                        )
                    )
            )
        }
        content()
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(22.dp),
    contentPadding: Dp = 18.dp,
    highlightAccent: Color? = null,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val extra = ReelsGuardTheme.colors
    val borderBrush = Brush.linearGradient(
        colors = listOf(
            highlightAccent?.copy(alpha = 0.45f) ?: extra.glassBorderStart,
            extra.glassBorderEnd
        )
    )

    if (onClick != null) {
        Surface(
            onClick = onClick,
            modifier = modifier.clip(shape),
            shape = shape,
            color = extra.glassSurface,
            border = BorderStroke(1.dp, borderBrush),
            tonalElevation = if (extra.isDark) 0.dp else 2.dp,
            shadowElevation = if (extra.isDark) 0.dp else 4.dp
        ) {
            Column(modifier = Modifier.padding(contentPadding), content = content)
        }
    } else {
        Surface(
            modifier = modifier.clip(shape),
            shape = shape,
            color = extra.glassSurface,
            border = BorderStroke(1.dp, borderBrush),
            tonalElevation = if (extra.isDark) 0.dp else 2.dp,
            shadowElevation = if (extra.isDark) 0.dp else 4.dp
        ) {
            Column(modifier = Modifier.padding(contentPadding), content = content)
        }
    }
}
