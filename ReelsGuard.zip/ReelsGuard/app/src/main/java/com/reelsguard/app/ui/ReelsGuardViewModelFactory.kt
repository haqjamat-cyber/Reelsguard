package com.reelsguard.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.reelsguard.app.AppContainer
import com.reelsguard.app.analytics.AnalyticsViewModel
import com.reelsguard.app.settings.SettingsViewModel
import com.reelsguard.app.ui.achievements.AchievementViewModel
import com.reelsguard.app.ui.dashboard.DashboardViewModel
import com.reelsguard.app.ui.limits.DailyLimitViewModel
import com.reelsguard.app.ui.permissions.PermissionViewModel
import com.reelsguard.app.ui.platforms.PlatformManagementViewModel

class ReelsGuardViewModelFactory(
    private val container: AppContainer
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(DashboardViewModel::class.java) -> DashboardViewModel(
                appContext = container.appContext,
                usageRepository = container.usageRepository,
                preferencesRepository = container.preferencesRepository,
                achievementRepository = container.achievementRepository
            ) as T

            modelClass.isAssignableFrom(PermissionViewModel::class.java) -> PermissionViewModel(
                appContext = container.appContext,
                preferencesRepository = container.preferencesRepository,
                usageRepository = container.usageRepository
            ) as T

            modelClass.isAssignableFrom(PlatformManagementViewModel::class.java) -> PlatformManagementViewModel(
                appContext = container.appContext,
                usageRepository = container.usageRepository
            ) as T

            modelClass.isAssignableFrom(DailyLimitViewModel::class.java) -> DailyLimitViewModel(
                usageRepository = container.usageRepository,
                preferencesRepository = container.preferencesRepository
            ) as T

            modelClass.isAssignableFrom(AnalyticsViewModel::class.java) -> AnalyticsViewModel(
                analyticsRepository = container.analyticsRepository,
                usageRepository = container.usageRepository
            ) as T

            modelClass.isAssignableFrom(AchievementViewModel::class.java) -> AchievementViewModel(
                achievementRepository = container.achievementRepository
            ) as T

            modelClass.isAssignableFrom(SettingsViewModel::class.java) -> SettingsViewModel(
                appContext = container.appContext,
                preferencesRepository = container.preferencesRepository,
                usageRepository = container.usageRepository
            ) as T

            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
