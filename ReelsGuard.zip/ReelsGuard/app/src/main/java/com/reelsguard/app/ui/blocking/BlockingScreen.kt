package com.reelsguard.app.ui.blocking

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.HourglassTop
import androidx.compose.material.icons.rounded.SelfImprovement
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.reelsguard.app.components.GlassCard
import com.reelsguard.app.components.GradientPrimaryButton
import com.reelsguard.app.components.PremiumBackground
import com.reelsguard.app.components.StatusPill
import com.reelsguard.app.model.BlockMode
import com.reelsguard.app.model.Platform
import com.reelsguard.app.ui.theme.ReelsGuardTheme
import com.reelsguard.app.utils.ResetScheduleCalculator
import com.reelsguard.app.utils.TimeFormatter
import kotlinx.coroutines.delay

@Composable
fun BlockingScreen(
    platform: Platform,
    usedSeconds: Long,
    limitMinutes: Int,
    blockMode: BlockMode,
    reason: String,
    resetHour: Int,
    resetMinute: Int,
    isPreview: Boolean,
    onGoHome: () -> Unit,
    onOpenReelsGuard: () -> Unit
) {
    val extra = ReelsGuardTheme.colors
    var millisUntilReset by remember(resetHour, resetMinute) {
        mutableLongStateOf(
            ResetScheduleCalculator.millisUntilNextReset(
                resetHour = resetHour,
                resetMinute = resetMinute
            )
        )
    }

    LaunchedEffect(resetHour, resetMinute) {
        while (true) {
            millisUntilReset = ResetScheduleCalculator.millisUntilNextReset(
                resetHour = resetHour,
                resetMinute = resetMinute
            )
            delay(1_000L)
        }
    }

    val nextResetLabel = ResetScheduleCalculator.formatResetTime(resetHour, resetMinute)

    PremiumBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                StatusPill(
                    text = if (isPreview) "Blocking Preview" else blockMode.label,
                    tint = if (isPreview) extra.accentBlue else extra.accentPurple
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(92.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(extra.accentPurple, extra.accentBlue)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.SelfImprovement,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(46.dp)
                    )
                }

                Spacer(modifier = Modifier.height(22.dp))

                Text(
                    text = "Time for a Mindful Pause",
                    style = MaterialTheme.typography.headlineLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "${platform.shortFormLabel} has reached your daily limit.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(24.dp))

                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    highlightAccent = extra.accentPurple
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "TIME USED TODAY",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = TimeFormatter.formatDurationCompact(usedSeconds),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "DAILY LIMIT",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = TimeFormatter.formatMinutesReadable(limitMinutes),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = extra.accentBlue
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.HourglassTop,
                                contentDescription = null,
                                tint = extra.accentCyan,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = " Resets at $nextResetLabel",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = TimeFormatter.formatCountdown(millisUntilReset),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = extra.accentCyan
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = reason.ifBlank {
                        "Take a breath, stretch, or dive into something offline — your limits refresh automatically."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                GradientPrimaryButton(
                    text = if (isPreview) "Close Preview" else "Return to Home Screen",
                    onClick = onGoHome,
                    icon = Icons.Rounded.Home,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(
                    onClick = onOpenReelsGuard,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (isPreview) "Go to Daily Limits" else "Open ReelsGuard Dashboard")
                }
            }
        }
    }
}
