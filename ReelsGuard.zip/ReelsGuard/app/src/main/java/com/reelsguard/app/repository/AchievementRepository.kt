package com.reelsguard.app.repository

import com.reelsguard.app.database.dao.AchievementDao
import com.reelsguard.app.database.dao.DailySummaryDao
import com.reelsguard.app.database.entity.AchievementEntity
import com.reelsguard.app.database.entity.DailySummaryEntity
import com.reelsguard.app.model.BadgeType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

data class AchievementOverview(
    val currentStreak: Int = 0,
    val bestStreak: Int = 0,
    val weeklyGoalMetCount: Int = 0,
    val totalGoalMetDays: Int = 0,
    val motivationalMessage: String = "",
    val recentSummaries: List<DailySummaryEntity> = emptyList(),
    val badges: List<AchievementEntity> = emptyList()
)

class AchievementRepository(
    private val achievementDao: AchievementDao,
    private val dailySummaryDao: DailySummaryDao
) {

    fun observeOverview(): Flow<AchievementOverview> {
        return combine(
            dailySummaryDao.observeAllSummaries(),
            achievementDao.observeAll()
        ) { summaries, badges ->
            val (progress, computedBadges) = AchievementEvaluator.calculateProgress(
                summaries = summaries,
                existingAchievements = badges.associateBy { it.badgeId }
            )
            AchievementOverview(
                currentStreak = progress.currentStreak,
                bestStreak = progress.bestStreak,
                weeklyGoalMetCount = progress.weeklyGoalMetCount,
                totalGoalMetDays = progress.totalGoalMetDays,
                motivationalMessage = progress.motivationalMessage,
                recentSummaries = summaries.take(7).reversed(),
                badges = computedBadges
            )
        }
    }

    suspend fun ensureDefaultBadgesExist() {
        val existing = achievementDao.getAll()
        if (existing.isEmpty()) {
            val defaults = BadgeType.entries.map { badge ->
                AchievementEntity(
                    badgeId = badge.id,
                    title = badge.title,
                    description = badge.description,
                    progressCurrent = 0,
                    progressTarget = badge.targetCount,
                    isUnlocked = false,
                    unlockedAtEpochMs = null
                )
            }
            achievementDao.upsertAll(defaults)
        }
    }

    suspend fun recalculateAndPersist() {
        val summaries = dailySummaryDao.getAllSummaries()
        val existingMap = achievementDao.getAll().associateBy { it.badgeId }
        val (_, updatedBadges) = AchievementEvaluator.calculateProgress(
            summaries = summaries,
            existingAchievements = existingMap
        )
        achievementDao.upsertAll(updatedBadges)
    }
}
