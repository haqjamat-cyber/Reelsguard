package com.reelsguard.app.service

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.reelsguard.app.R
import com.reelsguard.app.model.Platform
import com.reelsguard.app.ui.theme.loadPoppinsTypeface

class DynamicIslandOverlayManager(private val context: Context) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var rootPill: LinearLayout? = null
    private var liveDotView: View? = null
    private var platformBadgeText: TextView? = null
    private var countTextView: TextView? = null
    private var isAttached: Boolean = false
    private var lastDisplayedCount: Int = -1
    private var lastDisplayedPlatform: Platform? = null

    fun showOrUpdate(
        platform: Platform,
        watchedCount: Int,
        targetCount: Int = 0,
        isActivelyInReels: Boolean,
        animateIncrement: Boolean = false
    ) {
        mainHandler.post {
            runCatching {
                ensureOverlayAttached()
                val pill = rootPill ?: return@runCatching

                val shortTag = when (platform) {
                    Platform.INSTAGRAM -> "IG"
                    Platform.YOUTUBE -> "YT"
                    Platform.FACEBOOK -> "FB"
                }
                val unitLabel = when (platform) {
                    Platform.YOUTUBE -> if (watchedCount == 1 && targetCount <= 0) "Short" else "Shorts"
                    Platform.INSTAGRAM, Platform.FACEBOOK -> if (watchedCount == 1 && targetCount <= 0) "Reel" else "Reels"
                }

                platformBadgeText?.text = shortTag
                countTextView?.text = if (targetCount > 0) {
                    "$watchedCount/$targetCount $unitLabel"
                } else {
                    "$watchedCount $unitLabel"
                }

                (liveDotView?.background as? GradientDrawable)?.setColor(
                    if (isActivelyInReels) Color.parseColor("#F59E51")
                    else Color.parseColor("#99B890C4")
                )

                if (pill.visibility != View.VISIBLE) {
                    pill.visibility = View.VISIBLE
                    pill.alpha = 0f
                    pill.scaleX = 0.86f
                    pill.scaleY = 0.86f
                    pill.animate()
                        .alpha(1f)
                        .scaleX(1f)
                        .scaleY(1f)
                        .setDuration(220L)
                        .setInterpolator(OvershootInterpolator(1.2f))
                        .start()
                } else if (animateIncrement || (platform == lastDisplayedPlatform && watchedCount > lastDisplayedCount)) {
                    pill.animate().cancel()
                    pill.scaleX = 1f
                    pill.scaleY = 1f
                    pill.animate()
                        .scaleX(1.1f)
                        .scaleY(1.1f)
                        .setDuration(120L)
                        .withEndAction {
                            pill.animate()
                                .scaleX(1f)
                                .scaleY(1f)
                                .setDuration(160L)
                                .start()
                        }
                        .start()
                }

                lastDisplayedPlatform = platform
                lastDisplayedCount = watchedCount
            }
        }
    }

    fun hide() {
        mainHandler.post {
            runCatching {
                val pill = rootPill ?: return@runCatching
                if (pill.visibility == View.VISIBLE) {
                    pill.animate()
                        .alpha(0f)
                        .scaleX(0.9f)
                        .scaleY(0.9f)
                        .setDuration(160L)
                        .withEndAction {
                            pill.visibility = View.GONE
                        }
                        .start()
                }
            }
        }
    }

    fun destroy() {
        mainHandler.post {
            runCatching {
                if (isAttached && rootPill != null) {
                    windowManager.removeViewImmediate(rootPill)
                }
            }
            isAttached = false
            rootPill = null
            liveDotView = null
            platformBadgeText = null
            countTextView = null
        }
    }

    private fun ensureOverlayAttached() {
        if (isAttached && rootPill != null) return

        val poppinsSemiBold = loadPoppinsTypeface(context, semiBold = true)
        val poppinsRegular = loadPoppinsTypeface(context, semiBold = false)

        val pillBackground = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(
                Color.parseColor("#EB3A0353"),
                Color.parseColor("#EB5D2571"),
                Color.parseColor("#EB804A8A")
            )
        ).apply {
            cornerRadius = dp(999f)
            setStroke(dpInt(1.2f), Color.parseColor("#CCF59E51"))
        }

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = pillBackground
            setPadding(dpInt(11f), dpInt(5f), dpInt(13f), dpInt(5f))
            elevation = dp(8f)
            visibility = View.GONE
        }

        val playIcon = ImageView(context).apply {
            setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_dynamic_island_play))
            layoutParams = LinearLayout.LayoutParams(dpInt(15f), dpInt(15f)).apply {
                marginEnd = dpInt(6f)
            }
        }

        val dot = View(context).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#F59E51"))
            }
            layoutParams = LinearLayout.LayoutParams(dpInt(6f), dpInt(6f)).apply {
                marginEnd = dpInt(6f)
            }
        }

        val badgeText = TextView(context).apply {
            text = "IG"
            setTextColor(Color.parseColor("#F8D299"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = poppinsRegular
            includeFontPadding = false
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = dpInt(6f)
            }
        }

        val countText = TextView(context).apply {
            text = "0 Reels"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            typeface = poppinsSemiBold
            includeFontPadding = false
            letterSpacing = 0.01f
        }

        container.addView(playIcon)
        container.addView(dot)
        container.addView(badgeText)
        container.addView(countText)

        val topOffsetPx = computeSafeTopOffsetPx()
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = topOffsetPx
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        windowManager.addView(container, params)
        rootPill = container
        liveDotView = dot
        platformBadgeText = badgeText
        countTextView = countText
        isAttached = true
    }

    private fun computeSafeTopOffsetPx(): Int {
        val defaultTop = dpInt(10f)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val cutout = runCatching {
                windowManager.currentWindowMetrics.windowInsets.displayCutout
            }.getOrNull()
            val topCutoutBottom = cutout?.boundingRectTop?.bottom ?: 0
            if (topCutoutBottom > 0) {
                return (topCutoutBottom + dpInt(3f)).coerceAtMost(dpInt(48f))
            }
        }
        val statusBarResId = context.resources.getIdentifier("status_bar_height", "dimen", "android")
        val statusBarHeight = if (statusBarResId > 0) {
            context.resources.getDimensionPixelSize(statusBarResId)
        } else {
            0
        }
        return if (statusBarHeight > 0) {
            (statusBarHeight + dpInt(2f)).coerceAtMost(dpInt(44f))
        } else {
            defaultTop
        }
    }

    private fun dp(value: Float): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, context.resources.displayMetrics)

    private fun dpInt(value: Float): Int = dp(value).toInt()
}
