package com.reelsguard.app.ui.onboarding

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoGraph
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.reelsguard.app.R
import com.reelsguard.app.components.GlassCard
import com.reelsguard.app.components.GradientPrimaryButton
import com.reelsguard.app.components.PremiumBackground
import com.reelsguard.app.ui.theme.BrandGoldAmber
import com.reelsguard.app.ui.theme.BrandGoldLight
import com.reelsguard.app.ui.theme.BrandPurpleDark
import com.reelsguard.app.ui.theme.BrandPurpleLight
import com.reelsguard.app.ui.theme.ReelsGuardTheme
import kotlinx.coroutines.launch

private data class OnboardingPage(
    val icon: ImageVector,
    val badge: String,
    val title: String,
    val description: String,
    val detailNote: String,
    val useBrandLogo: Boolean = false
)

private val onboardingPages = listOf(
    OnboardingPage(
        icon = Icons.Rounded.Shield,
        badge = "MINDFUL CONTROL",
        title = "Reclaim Your Focus From Endless Scrolls",
        description = "Set personal daily budgets for Instagram Reels, YouTube Shorts, and Facebook Reels without deleting your favorite apps.",
        detailNote = "Includes a live Dynamic Island reel counter while browsing Instagram, YouTube, and Facebook.",
        useBrandLogo = true
    ),
    OnboardingPage(
        icon = Icons.Rounded.Timer,
        badge = "HONEST TRACKING",
        title = "Transparent Dual-Mode Measurement",
        description = "With your explicit Accessibility permission, ReelsGuard detects Reels & Shorts surfaces. If unavailable, it offers a clearly labeled Full-App Fallback using Usage Access.",
        detailNote = "We never disguise total app usage as verified Reels time."
    ),
    OnboardingPage(
        icon = Icons.Rounded.AutoGraph,
        badge = "GENTLE BOUNDARIES",
        title = "Automatic Pauses & Calm Streaks",
        description = "When a daily cap is reached, ReelsGuard displays a calm pause screen until your chosen daily reset time and tracks your streaks without guilt.",
        detailNote = "Supports midnight or custom daily reset hours across timezone changes."
    ),
    OnboardingPage(
        icon = Icons.Rounded.Lock,
        badge = "100% ON-DEVICE PRIVACY",
        title = "Your Activity Never Leaves Your Phone",
        description = "All usage history, limits, and achievements live strictly in your device's local Room database. Zero accounts, zero cloud tracking, zero ads.",
        detailNote = "You stay in full control of every permission and can clear local data with one tap."
    )
)

@Composable
fun OnboardingScreen(
    onFinishToPermissions: () -> Unit,
    onSkipToDashboard: () -> Unit
) {
    val extra = ReelsGuardTheme.colors
    val pagerState = rememberPagerState(pageCount = { onboardingPages.size })
    val scope = rememberCoroutineScope()

    PremiumBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onSkipToDashboard) {
                    Text(
                        text = "Skip",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            HorizontalPager(
                state = pagerState,
                modifier = Modifier.weight(1f)
            ) { index ->
                val page = onboardingPages[index]
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    if (page.useBrandLogo) {
                        Box(
                            modifier = Modifier
                                .size(100.dp)
                                .clip(RoundedCornerShape(28.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(BrandPurpleLight, BrandPurpleDark)
                                    )
                                )
                                .border(
                                    width = 1.5.dp,
                                    brush = Brush.linearGradient(
                                        listOf(BrandGoldLight.copy(alpha = 0.75f), BrandGoldAmber.copy(alpha = 0.5f))
                                    ),
                                    shape = RoundedCornerShape(28.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_launcher_foreground),
                                contentDescription = "ReelsGuard Logo",
                                modifier = Modifier.size(92.dp)
                            )
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .size(96.dp)
                                .clip(RoundedCornerShape(28.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(BrandPurpleLight, BrandPurpleDark)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = page.icon,
                                contentDescription = null,
                                tint = BrandGoldLight,
                                modifier = Modifier.size(46.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(28.dp))

                    Text(
                        text = page.badge,
                        style = MaterialTheme.typography.labelMedium,
                        color = BrandGoldAmber
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = page.title,
                        style = MaterialTheme.typography.headlineLarge,
                        color = MaterialTheme.colorScheme.onBackground,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = page.description,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = page.detailNote,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(onboardingPages.size) { idx ->
                    val selected = pagerState.currentPage == idx
                    Box(
                        modifier = Modifier
                            .height(8.dp)
                            .width(if (selected) 26.dp else 8.dp)
                            .clip(CircleShape)
                            .background(
                                if (selected) BrandGoldAmber else extra.subtleTrack
                            )
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            val isLastPage = pagerState.currentPage == onboardingPages.lastIndex
            GradientPrimaryButton(
                text = if (isLastPage) "Set Up Permissions" else "Continue",
                onClick = {
                    if (isLastPage) {
                        onFinishToPermissions()
                    } else {
                        scope.launch {
                            pagerState.animateScrollToPage(pagerState.currentPage + 1)
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}
