package com.reelsguard.app.ui.permissions

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.reelsguard.app.data.UserPreferencesRepository
import com.reelsguard.app.model.PermissionStatusSnapshot
import com.reelsguard.app.repository.UsageRepository
import com.reelsguard.app.utils.PermissionHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class PermissionViewModel(
    private val appContext: Context,
    private val preferencesRepository: UserPreferencesRepository,
    private val usageRepository: UsageRepository
) : ViewModel() {

    private val _status = MutableStateFlow(PermissionHelper.getPermissionSnapshot(appContext))
    val status: StateFlow<PermissionStatusSnapshot> = _status.asStateFlow()

    fun refreshPermissions() {
        val current = PermissionHelper.getPermissionSnapshot(appContext)
        _status.value = current
        if (current.isUsageAccessGranted) {
            viewModelScope.launch {
                usageRepository.syncFallbackUsageStatsIfPermitted()
            }
        }
    }

    fun recordAccessibilityConsent() {
        viewModelScope.launch {
            preferencesRepository.setAccessibilityDisclosureAccepted(true)
        }
    }

    fun recordUsageAccessConsent() {
        viewModelScope.launch {
            preferencesRepository.setUsageAccessDisclosureAccepted(true)
        }
    }
}
