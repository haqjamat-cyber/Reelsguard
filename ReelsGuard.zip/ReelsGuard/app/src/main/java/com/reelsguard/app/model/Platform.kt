package com.reelsguard.app.model

enum class Platform(
    val displayName: String,
    val shortFormLabel: String,
    val packageNames: List<String>,
    val defaultLimitMinutes: Int,
    val accentHex: Long,
    val secondaryAccentHex: Long
) {
    INSTAGRAM(
        displayName = "Instagram",
        shortFormLabel = "Instagram Reels",
        packageNames = listOf("com.instagram.android"),
        defaultLimitMinutes = 20,
        accentHex = 0xFFE1306C,
        secondaryAccentHex = 0xFF833AB4
    ),
    YOUTUBE(
        displayName = "YouTube",
        shortFormLabel = "YouTube Shorts",
        packageNames = listOf("com.google.android.youtube"),
        defaultLimitMinutes = 15,
        accentHex = 0xFFFF2E4C,
        secondaryAccentHex = 0xFFFF6B35
    ),
    FACEBOOK(
        displayName = "Facebook",
        shortFormLabel = "Facebook Reels",
        packageNames = listOf("com.facebook.katana", "com.facebook.lite"),
        defaultLimitMinutes = 10,
        accentHex = 0xFF1877F2,
        secondaryAccentHex = 0xFF38BDF8
    );

    companion object {
        fun fromPackageName(packageName: String?): Platform? {
            if (packageName.isNullOrBlank()) return null
            return entries.firstOrNull { platform ->
                platform.packageNames.any { it.equals(packageName, ignoreCase = true) }
            }
        }
    }
}
