package com.reelsguard.app.model

data class DailyChartPoint(
    val dateKey: String,
    val shortLabel: String,
    val verifiedMinutes: Float,
    val fallbackMinutes: Float,
    val totalMinutes: Float,
    val goalMet: Boolean
)

data class PlatformComparisonItem(
    val platform: Platform,
    val verifiedSeconds: Long,
    val fallbackSeconds: Long,
    val shareFraction: Float
) {
    val totalTrackedSeconds: Long
        get() = verifiedSeconds + fallbackSeconds
}

data class HistoricalUsageRow(
    val dateKey: String,
    val formattedDate: String,
    val instagramSeconds: Long,
    val youtubeSeconds: Long,
    val facebookSeconds: Long,
    val verifiedTotalSeconds: Long,
    val fallbackTotalSeconds: Long,
    val goalMet: Boolean
) {
    val combinedSeconds: Long
        get() = if (verifiedTotalSeconds > 0L) verifiedTotalSeconds else fallbackTotalSeconds
}

data class MonthlyOverview(
    val daysTracked: Int = 0,
    val daysGoalMet: Int = 0,
    val totalTrackedSeconds: Long = 0L,
    val averageDailySeconds: Long = 0L,
    val dailyPoints: List<DailyChartPoint> = emptyList()
)

data class WeeklyReportSummary(
    val weekLabel: String = "",
    val currentWeekTotalSeconds: Long = 0L,
    val previousWeekTotalSeconds: Long = 0L,
    val deltaPercent: Int? = null,
    val daysUnderLimit: Int = 0,
    val totalBlockingEvents: Int = 0,
    val peakDayLabel: String = "None yet",
    val peakDaySeconds: Long = 0L,
    val mostUsedPlatform: Platform? = null,
    val dailyBreakdown: List<DailyChartPoint> = emptyList(),
    val insightMessage: String = "Start tracking to unlock personalized weekly insights."
)

data class AnalyticsUiState(
    val todayPlatformPoints: List<PlatformComparisonItem> = emptyList(),
    val weeklyChartPoints: List<DailyChartPoint> = emptyList(),
    val monthlyOverview: MonthlyOverview = MonthlyOverview(),
    val platformComparisons: List<PlatformComparisonItem> = emptyList(),
    val averageDailySeconds: Long = 0L,
    val mostUsedPlatform: Platform? = null,
    val historicalRecords: List<HistoricalUsageRow> = emptyList(),
    val weeklyReport: WeeklyReportSummary = WeeklyReportSummary(),
    val totalVerifiedSecondsAllTime: Long = 0L,
    val totalFallbackSecondsAllTime: Long = 0L,
    val isLoading: Boolean = true
)
