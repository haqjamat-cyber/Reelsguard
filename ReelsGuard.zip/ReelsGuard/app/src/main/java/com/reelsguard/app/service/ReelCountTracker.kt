package com.reelsguard.app.service

import com.reelsguard.app.model.Platform

class ReelCountTracker(
    private val swipeDebounceMs: Long = DEFAULT_SWIPE_DEBOUNCE_MS,
    private val reentryGraceMs: Long = DEFAULT_REENTRY_GRACE_MS
) {
    private var activePlatform: Platform? = null
    private var inShortForm: Boolean = false
    private var lastExitPlatform: Platform? = null
    private var lastExitTimeMs: Long = 0L
    private var lastCountedTimeMs: Long = 0L

    @Synchronized
    fun onSignal(
        platform: Platform,
        isShortFormSection: Boolean,
        isVerticalScrollEvent: Boolean,
        nowMs: Long
    ): Boolean {
        val platformChanged = activePlatform != platform
        if (platformChanged) {
            if (inShortForm && activePlatform != null) {
                lastExitPlatform = activePlatform
                lastExitTimeMs = nowMs
            }
            activePlatform = platform
            inShortForm = false
        }

        if (!isShortFormSection) {
            if (inShortForm) {
                inShortForm = false
                lastExitPlatform = platform
                lastExitTimeMs = nowMs
            }
            return false
        }

        if (!inShortForm) {
            inShortForm = true
            val isQuickFlickerReturn = lastExitPlatform == platform &&
                (nowMs - lastExitTimeMs) < reentryGraceMs
            if (!isQuickFlickerReturn && (nowMs - lastCountedTimeMs) >= swipeDebounceMs) {
                lastCountedTimeMs = nowMs
                return true
            }
            return false
        }

        if (isVerticalScrollEvent && (nowMs - lastCountedTimeMs) >= swipeDebounceMs) {
            lastCountedTimeMs = nowMs
            return true
        }

        return false
    }

    @Synchronized
    fun onLeftMonitoredApps(nowMs: Long) {
        if (inShortForm && activePlatform != null) {
            lastExitPlatform = activePlatform
            lastExitTimeMs = nowMs
        }
        activePlatform = null
        inShortForm = false
    }

    companion object {
        const val DEFAULT_SWIPE_DEBOUNCE_MS = 1_800L
        const val DEFAULT_REENTRY_GRACE_MS = 3_000L
    }
}
