package com.reelsguard.app.service

import com.reelsguard.app.model.Platform

/**
 * Strict full-video completion tracker for Instagram Reels, YouTube Shorts, and Facebook Reels.
 *
 * Accuracy Guarantees:
 * 1. Never counts immediately when opening Reels/Shorts or when scrolling quickly.
 * 2. Half-watched or skipped videos are NEVER counted.
 * 3. A video counts (+1) ONLY when:
 *    - Its exposed SeekBar/ProgressBar advances and reaches >= 90% completion (or loops from >= 80% back to <= 18%)
 *      after at least 4 seconds of real active watch time; OR
 *    - When no live progress bar is exposed by the third-party app, the user actively watches
 *      the same unpaused video for >= 15 seconds continuously.
 * 4. Once counted, [currentVideoCounted] locks that video so looping or repeated events NEVER double-count.
 * 5. New videos are detected cleanly via vertical scroll, scroll index changes, or stable video fingerprint changes.
 */
class ReelCountTracker(
    private val fullWatchFallbackMs: Long = DEFAULT_FULL_WATCH_FALLBACK_MS,
    private val minProgressWatchMs: Long = DEFAULT_MIN_PROGRESS_WATCH_MS,
    private val swipeResetDebounceMs: Long = DEFAULT_SWIPE_RESET_DEBOUNCE_MS,
    private val reentryGraceMs: Long = DEFAULT_REENTRY_GRACE_MS,
    private val fingerprintConfirmMs: Long = DEFAULT_FINGERPRINT_CONFIRM_MS
) {
    private var activePlatform: Platform? = null
    private var inShortForm: Boolean = false
    private var lastUpdateMs: Long = 0L

    private var activeWatchMs: Long = 0L
    private var currentVideoCounted: Boolean = false

    private var firstProgressSeen: Float? = null
    private var lastProgressSeen: Float? = null
    private var maxProgressSeen: Float = 0f
    private var sawMovingProgressBar: Boolean = false
    private var sawProgressLoopCompletion: Boolean = false

    private var currentFingerprint: String = ""
    private var pendingFingerprint: String = ""
    private var pendingFingerprintSinceMs: Long = 0L

    private var lastScrollIndexKey: String = ""
    private var lastSwipeResetMs: Long = 0L

    private var lastExitPlatform: Platform? = null
    private var lastExitTimeMs: Long = 0L

    /**
     * Evaluates an accessibility event or 1-second ticker sample.
     * Returns `true` ONLY at the exact moment a single video is verified as fully watched.
     */
    @Synchronized
    fun onObservation(
        platform: Platform,
        isShortFormSection: Boolean,
        nowMs: Long,
        playbackProgressFraction: Float? = null,
        isVideoPaused: Boolean = false,
        videoFingerprint: String = "",
        isVerticalScrollEvent: Boolean = false,
        scrollIndexKey: String = ""
    ): Boolean {
        // Switching monitored app resets current video session cleanly
        if (activePlatform != platform) {
            if (inShortForm && activePlatform != null) {
                lastExitPlatform = activePlatform
                lastExitTimeMs = nowMs
            }
            activePlatform = platform
            inShortForm = false
            resetCurrentVideoState(nowMs, newFingerprint = "")
            lastScrollIndexKey = ""
        }

        // Outside Reels/Shorts -> pause tracking (with brief grace for volume/overlay flickers)
        if (!isShortFormSection) {
            if (inShortForm) {
                inShortForm = false
                lastExitPlatform = platform
                lastExitTimeMs = nowMs
            }
            lastUpdateMs = nowMs
            return false
        }

        // Entering Reels/Shorts
        if (!inShortForm) {
            inShortForm = true
            val isQuickFlickerReturn = lastExitPlatform == platform &&
                (nowMs - lastExitTimeMs) in 0L until reentryGraceMs
            if (!isQuickFlickerReturn) {
                resetCurrentVideoState(nowMs, newFingerprint = videoFingerprint)
                lastScrollIndexKey = scrollIndexKey
            } else {
                lastUpdateMs = nowMs
            }
            // Never count immediately upon entering
            updateProgressMetrics(playbackProgressFraction)
            return false
        }

        // Accumulate active watch time since previous observation (clamped to avoid huge jumps after sleep)
        val deltaMs = (nowMs - lastUpdateMs).coerceIn(0L, MAX_TICK_STEP_MS)
        lastUpdateMs = nowMs
        if (!isVideoPaused) {
            activeWatchMs += deltaMs
        }

        // Determine whether user switched to a NEW video
        val indexChanged = scrollIndexKey.isNotEmpty() &&
            lastScrollIndexKey.isNotEmpty() &&
            scrollIndexKey != lastScrollIndexKey
        if (scrollIndexKey.isNotEmpty()) {
            lastScrollIndexKey = scrollIndexKey
        }

        val swipeDetected = (isVerticalScrollEvent || indexChanged) &&
            (nowMs - lastSwipeResetMs) >= swipeResetDebounceMs

        val fingerprintTransitioned = detectStableFingerprintChange(videoFingerprint, nowMs)

        if (swipeDetected || fingerprintTransitioned) {
            // Before discarding the outgoing video, check if it just crossed completion right at swipe time
            val outgoingJustCompleted = !currentVideoCounted && isCurrentVideoComplete()
            lastSwipeResetMs = nowMs
            resetCurrentVideoState(nowMs, newFingerprint = videoFingerprint)
            updateProgressMetrics(playbackProgressFraction)
            return outgoingJustCompleted
        }

        // Still on the SAME video -> update progress bar & check completion
        updateProgressMetrics(playbackProgressFraction)

        if (!currentVideoCounted && isCurrentVideoComplete()) {
            currentVideoCounted = true
            return true
        }

        return false
    }

    @Synchronized
    fun onLeftMonitoredApps(nowMs: Long) {
        if (inShortForm && activePlatform != null) {
            lastExitPlatform = activePlatform
            lastExitTimeMs = nowMs
        }
        activePlatform = null
        inShortForm = false
        resetCurrentVideoState(nowMs, newFingerprint = "")
        lastScrollIndexKey = ""
    }

    private fun updateProgressMetrics(progress: Float?) {
        if (progress == null || progress.isNaN()) return
        val clamped = progress.coerceIn(0f, 1f)

        val prev = lastProgressSeen
        if (firstProgressSeen == null) {
            firstProgressSeen = clamped
        } else if (prev != null) {
            // Detect genuine playback movement (rules out static decorative progress bars)
            if (clamped - prev >= 0.02f || (clamped > 0.05f && clamped < 0.98f && clamped != firstProgressSeen)) {
                sawMovingProgressBar = true
            }
            // Detect loop wrap-around (e.g., reached >= 80% then wrapped back to <= 18%)
            if (prev >= LOOP_PREV_MIN_PROGRESS && clamped <= LOOP_NEXT_MAX_PROGRESS) {
                sawMovingProgressBar = true
                sawProgressLoopCompletion = true
            }
        }

        if (clamped > maxProgressSeen) {
            maxProgressSeen = clamped
        }
        lastProgressSeen = clamped
    }

    private fun isCurrentVideoComplete(): Boolean {
        if (sawMovingProgressBar) {
            val reachedEnd = maxProgressSeen >= PROGRESS_COMPLETION_THRESHOLD || sawProgressLoopCompletion
            return reachedEnd && activeWatchMs >= minProgressWatchMs
        }
        return activeWatchMs >= fullWatchFallbackMs
    }

    private fun detectStableFingerprintChange(newFp: String, nowMs: Long): Boolean {
        if (newFp.isBlank()) return false
        if (currentFingerprint.isBlank()) {
            currentFingerprint = newFp
            pendingFingerprint = ""
            pendingFingerprintSinceMs = 0L
            return false
        }
        if (newFp == currentFingerprint) {
            pendingFingerprint = ""
            pendingFingerprintSinceMs = 0L
            return false
        }
        if (pendingFingerprint != newFp) {
            pendingFingerprint = newFp
            pendingFingerprintSinceMs = nowMs
            return false
        }
        return (nowMs - pendingFingerprintSinceMs) >= fingerprintConfirmMs
    }

    private fun resetCurrentVideoState(nowMs: Long, newFingerprint: String) {
        lastUpdateMs = nowMs
        activeWatchMs = 0L
        currentVideoCounted = false
        firstProgressSeen = null
        lastProgressSeen = null
        maxProgressSeen = 0f
        sawMovingProgressBar = false
        sawProgressLoopCompletion = false
        currentFingerprint = newFingerprint
        pendingFingerprint = ""
        pendingFingerprintSinceMs = 0L
    }

    companion object {
        const val DEFAULT_FULL_WATCH_FALLBACK_MS = 15_000L
        const val DEFAULT_MIN_PROGRESS_WATCH_MS = 4_000L
        const val DEFAULT_SWIPE_RESET_DEBOUNCE_MS = 900L
        const val DEFAULT_REENTRY_GRACE_MS = 2_500L
        const val DEFAULT_FINGERPRINT_CONFIRM_MS = 1_000L
        private const val MAX_TICK_STEP_MS = 2_500L
        private const val PROGRESS_COMPLETION_THRESHOLD = 0.90f
        private const val LOOP_PREV_MIN_PROGRESS = 0.80f
        private const val LOOP_NEXT_MAX_PROGRESS = 0.18f
    }
}
