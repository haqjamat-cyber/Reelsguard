package com.reelsguard.app.ui.limits

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.reelsguard.app.components.GlassCard
import com.reelsguard.app.components.PremiumBackground
import com.reelsguard.app.components.ScreenTopHeader
import com.reelsguard.app.components.iconVector
import com.reelsguard.app.database.entity.PlatformLimitEntity
import com.reelsguard.app.ui.theme.ReelsGuardTheme

@Composable
fun DailyLimitScreen(
    viewModel: DailyLimitViewModel,
    onBack: () -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val extra = ReelsGuardTheme.colors

    var totalInput by remember { mutableStateOf("") }
    var totalStatus by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(state.totalDailyVideoLimit, state.isTotalDailyLimitEnabled) {
        totalInput = if (state.isTotalDailyLimitEnabled && state.totalDailyVideoLimit > 0) {
            state.totalDailyVideoLimit.toString()
        } else {
            ""
        }
    }

    PremiumBackground {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                ScreenTopHeader(
                    title = "Daily Video Targets",
                    subtitle = "Type how many full videos before blocking",
                    onBack = onBack
                )
            }

            // Combined Total Daily Video Target (Starts BLANK until user types a target)
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    highlightAccent = if (state.isTotalDailyLimitEnabled && state.totalDailyVideoLimit > 0) {
                        extra.accentPurple
                    } else {
                        null
                    }
                ) {
                    Text(
                        text = "Total Daily Video Target",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (state.isTotalDailyLimitEnabled && state.totalDailyVideoLimit > 0) {
                            "Active: blocks after ${state.totalDailyVideoLimit} full videos across all apps"
                        } else {
                            "Combined cap across Instagram, YouTube & Facebook (not set)"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = totalInput,
                        onValueChange = { raw ->
                            totalInput = raw.filter { it.isDigit() }.take(4)
                            totalStatus = null
                        },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        label = { Text("Total full videos target") },
                        placeholder = { Text("Type video count") }
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                val parsed = totalInput.toIntOrNull() ?: 0
                                if (parsed > 0) {
                                    viewModel.updateTotalVideoLimit(parsed, enabled = true)
                                    totalStatus = "Saved: $parsed full videos"
                                } else {
                                    totalStatus = "Type a number greater than 0"
                                }
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Save Target")
                        }
                        if (state.isTotalDailyLimitEnabled && state.totalDailyVideoLimit > 0) {
                            OutlinedButton(
                                onClick = {
                                    totalInput = ""
                                    viewModel.updateTotalVideoLimit(0, enabled = false)
                                    totalStatus = "Cleared"
                                },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Clear")
                            }
                        }
                    }

                    if (totalStatus != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = totalStatus.orEmpty(),
                            style = MaterialTheme.typography.labelSmall,
                            color = extra.success
                        )
                    }
                }
            }

            // Per-platform video count inputs (Blank by default — NO pre-filled number!)
            items(state.platformLimits, key = { it.platform.name }) { limit ->
                PlatformVideoTargetCard(
                    limit = limit,
                    onSave = { count ->
                        viewModel.updatePlatformVideoLimit(limit.platform, count, enabled = true)
                    },
                    onClear = {
                        viewModel.updatePlatformVideoLimit(limit.platform, 0, enabled = false)
                    }
                )
            }
        }
    }
}

@Composable
private fun PlatformVideoTargetCard(
    limit: PlatformLimitEntity,
    onSave: (Int) -> Unit,
    onClear: () -> Unit
) {
    val extra = ReelsGuardTheme.colors
    val accent = Color(limit.platform.accentHex)
    var inputText by remember(limit.platform) { mutableStateOf("") }
    var statusText by remember(limit.platform) { mutableStateOf<String?>(null) }

    LaunchedEffect(limit.dailyVideoLimit, limit.isLimitEnabled) {
        inputText = if (limit.isLimitEnabled && limit.dailyVideoLimit > 0) {
            limit.dailyVideoLimit.toString()
        } else {
            ""
        }
    }

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        highlightAccent = if (limit.isLimitEnabled && limit.dailyVideoLimit > 0) accent else null
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = limit.platform.iconVector(),
                contentDescription = limit.platform.displayName,
                tint = accent
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = limit.platform.shortFormLabel,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = if (limit.isLimitEnabled && limit.dailyVideoLimit > 0) {
                        "Target: ${limit.dailyVideoLimit} full videos"
                    } else {
                        "No target set"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = inputText,
            onValueChange = { raw ->
                inputText = raw.filter { it.isDigit() }.take(4)
                statusText = null
            },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            label = { Text("${limit.platform.shortFormLabel} target") },
            placeholder = { Text("Type video count") }
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = {
                    val parsed = inputText.toIntOrNull() ?: 0
                    if (parsed > 0) {
                        onSave(parsed)
                        statusText = "Saved: $parsed full videos"
                    } else {
                        statusText = "Type a number greater than 0"
                    }
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Save Target")
            }
            if (limit.isLimitEnabled && limit.dailyVideoLimit > 0) {
                OutlinedButton(
                    onClick = {
                        inputText = ""
                        onClear()
                        statusText = "Cleared"
                    },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Clear")
                }
            }
        }

        if (statusText != null) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = statusText.orEmpty(),
                style = MaterialTheme.typography.labelSmall,
                color = extra.success
            )
        }
    }
}
