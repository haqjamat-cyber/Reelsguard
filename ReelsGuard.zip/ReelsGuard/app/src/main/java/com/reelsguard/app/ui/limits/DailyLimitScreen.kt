package com.reelsguard.app.ui.limits

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.reelsguard.app.components.GlassCard
import com.reelsguard.app.components.PremiumBackground
import com.reelsguard.app.components.ScreenTopHeader
import com.reelsguard.app.components.iconVector
import com.reelsguard.app.ui.theme.ReelsGuardTheme
import com.reelsguard.app.utils.TimeFormatter
import kotlin.math.roundToInt

private val platformPresets = listOf(5, 10, 15, 20, 30, 45, 60)
private val totalPresets = listOf(15, 30, 45, 60, 90, 120)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DailyLimitScreen(
    viewModel: DailyLimitViewModel,
    onBack: () -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val extra = ReelsGuardTheme.colors

    PremiumBackground {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                ScreenTopHeader(
                    title = "Daily Usage Limits",
                    subtitle = "Set combined and platform-specific caps",
                    onBack = onBack
                )
            }

            // Combined Total Daily Cap
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    highlightAccent = if (state.isTotalDailyLimitEnabled) extra.accentPurple else null
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Total Daily Short-Form Limit",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Combined cap across Instagram, YouTube & Facebook",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = state.isTotalDailyLimitEnabled,
                            onCheckedChange = { enabled ->
                                viewModel.updateTotalLimit(state.totalDailyLimitMinutes, enabled)
                            }
                        )
                    }

                    if (state.isTotalDailyLimitEnabled) {
                        Spacer(modifier = Modifier.height(14.dp))
                        LimitStepperRow(
                            minutes = state.totalDailyLimitMinutes,
                            minMinutes = 5,
                            maxMinutes = 240,
                            onChange = { newVal -> viewModel.updateTotalLimit(newVal, true) }
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            totalPresets.forEach { preset ->
                                FilterChip(
                                    selected = state.totalDailyLimitMinutes == preset,
                                    onClick = { viewModel.updateTotalLimit(preset, true) },
                                    label = { Text(TimeFormatter.formatMinutesReadable(preset)) }
                                )
                            }
                        }
                    }
                }
            }

            // Per-platform limits
            items(state.platformLimits, key = { it.platform.name }) { limit ->
                val accent = Color(limit.platform.accentHex)
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    highlightAccent = if (limit.isLimitEnabled) accent else null
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = limit.platform.iconVector(),
                                contentDescription = limit.platform.displayName,
                                tint = accent
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = limit.platform.shortFormLabel,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (limit.isLimitEnabled) {
                                        "Limit: ${TimeFormatter.formatMinutesReadable(limit.dailyLimitMinutes)}"
                                    } else {
                                        "Individual cap disabled"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Switch(
                            checked = limit.isLimitEnabled,
                            onCheckedChange = { enabled ->
                                viewModel.updatePlatformLimit(
                                    platform = limit.platform,
                                    minutes = limit.dailyLimitMinutes,
                                    enabled = enabled
                                )
                            }
                        )
                    }

                    if (limit.isLimitEnabled) {
                        Spacer(modifier = Modifier.height(12.dp))
                        LimitStepperRow(
                            minutes = limit.dailyLimitMinutes,
                            minMinutes = 1,
                            maxMinutes = 180,
                            onChange = { newMinutes ->
                                viewModel.updatePlatformLimit(limit.platform, newMinutes, true)
                            }
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            platformPresets.forEach { preset ->
                                FilterChip(
                                    selected = limit.dailyLimitMinutes == preset,
                                    onClick = {
                                        viewModel.updatePlatformLimit(limit.platform, preset, true)
                                    },
                                    label = { Text("${preset}m") }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LimitStepperRow(
    minutes: Int,
    minMinutes: Int,
    maxMinutes: Int,
    onChange: (Int) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            FilledTonalIconButton(
                onClick = { onChange((minutes - 5).coerceAtLeast(minMinutes)) }
            ) {
                Icon(imageVector = Icons.Rounded.Remove, contentDescription = "Decrease 5 minutes")
            }
            Text(
                text = TimeFormatter.formatMinutesReadable(minutes),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            FilledTonalIconButton(
                onClick = { onChange((minutes + 5).coerceAtMost(maxMinutes)) }
            ) {
                Icon(imageVector = Icons.Rounded.Add, contentDescription = "Increase 5 minutes")
            }
        }
        Slider(
            value = minutes.toFloat(),
            onValueChange = { onChange(it.roundToInt().coerceIn(minMinutes, maxMinutes)) },
            valueRange = minMinutes.toFloat()..maxMinutes.toFloat(),
            modifier = Modifier.fillMaxWidth()
        )
    }
}
