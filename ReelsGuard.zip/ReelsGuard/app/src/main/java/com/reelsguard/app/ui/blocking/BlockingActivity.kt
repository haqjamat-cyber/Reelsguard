package com.reelsguard.app.ui.blocking

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.reelsguard.app.MainActivity
import com.reelsguard.app.ReelsGuardApplication
import com.reelsguard.app.data.UserPreferences
import com.reelsguard.app.model.BlockMode
import com.reelsguard.app.model.Platform
import com.reelsguard.app.ui.theme.ReelsGuardTheme

class BlockingActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val platform = runCatching {
            Platform.valueOf(intent.getStringExtra(EXTRA_PLATFORM) ?: Platform.INSTAGRAM.name)
        }.getOrDefault(Platform.INSTAGRAM)

        val usedSeconds = intent.getLongExtra(EXTRA_USED_SECONDS, 0L)
        val limitMinutes = intent.getIntExtra(EXTRA_LIMIT_MINUTES, platform.defaultLimitMinutes)
        val blockMode = runCatching {
            BlockMode.valueOf(intent.getStringExtra(EXTRA_BLOCK_MODE) ?: BlockMode.SECTION_ONLY.name)
        }.getOrDefault(BlockMode.SECTION_ONLY)
        val reason = intent.getStringExtra(EXTRA_REASON).orEmpty()
        val isPreview = intent.getBooleanExtra(EXTRA_IS_PREVIEW, false)

        val app = application as ReelsGuardApplication

        setContent {
            val prefs by app.container.preferencesRepository.preferencesFlow
                .collectAsStateWithLifecycle(initialValue = UserPreferences())

            ReelsGuardTheme(themeMode = prefs.themeMode) {
                BlockingScreen(
                    platform = platform,
                    usedSeconds = usedSeconds,
                    limitMinutes = limitMinutes,
                    blockMode = blockMode,
                    reason = reason,
                    resetHour = prefs.resetHour,
                    resetMinute = prefs.resetMinute,
                    isPreview = isPreview,
                    onGoHome = {
                        if (isPreview) {
                            finish()
                        } else {
                            val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                                addCategory(Intent.CATEGORY_HOME)
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            }
                            startActivity(homeIntent)
                            finish()
                        }
                    },
                    onOpenReelsGuard = {
                        val mainIntent = Intent(this, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                        }
                        startActivity(mainIntent)
                        finish()
                    }
                )
            }
        }
    }

    companion object {
        const val EXTRA_PLATFORM = "extra_platform"
        const val EXTRA_USED_SECONDS = "extra_used_seconds"
        const val EXTRA_LIMIT_MINUTES = "extra_limit_minutes"
        const val EXTRA_BLOCK_MODE = "extra_block_mode"
        const val EXTRA_REASON = "extra_reason"
        const val EXTRA_IS_PREVIEW = "extra_is_preview"
    }
}
