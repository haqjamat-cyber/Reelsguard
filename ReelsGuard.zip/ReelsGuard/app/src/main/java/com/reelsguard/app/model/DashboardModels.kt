package com.reelsguard.app.model

data class PermissionStatusSnapshot(
    val isAccessibilityEnabled: Boolean = false,
    val isUsageAccessGranted: Boolean = false,
    val isOverlayGranted: Boolean = false,
    val isNotificationGranted: Boolean = true
) {
    val canBlockAutomatically: Boolean
        get() = isAccessibilityEnabled

    val canTrackReelsSection: Boolean
        get() = isAccessibilityEnabled

    val canTrackFallbackAppUsage: Boolean
        get() = isUsageAccessGranted

    val hasAnyTrackingPermission: Boolean
        get() = isAccessibilityEnabled || isUsageAccessGranted
}

data class PlatformUsageSummary(
    val platform: Platform,
    val isTrackingEnabled: Boolean,
    val isLimitEnabled: Boolean,
    val dailyVideoLimit: Int,
    val blockMode: BlockMode,
    val verifiedReelsSeconds: Long,
    val fallbackAppSeconds: Long,
    val activeConfidence: TrackingConfidence,
    val isCurrentlyBlocked: Boolean,
    val watchedReelsCount: Int = 0
) {
    val hasActiveVideoTarget: Boolean
        get() = isLimitEnabled && dailyVideoLimit > 0

    val remainingVideos: Int
        get() = if (!hasActiveVideoTarget) 0 else (dailyVideoLimit - watchedReelsCount).coerceAtLeast(0)

    val progressFraction: Float
        get() = if (!hasActiveVideoTarget) {
            0f
        } else {
            (watchedReelsCount.toFloat() / dailyVideoLimit.toFloat()).coerceIn(0f, 1f)
        }
}

data class DashboardUiState(
    val currentDateKey: String = "",
    val totalVerifiedReelsSeconds: Long = 0L,
    val totalFallbackAppSeconds: Long = 0L,
    val totalWatchedReelsCount: Int = 0,
    val totalDailyVideoLimit: Int = 0,
    val isTotalDailyLimitEnabled: Boolean = false,
    val remainingVideos: Int = 0,
    val primaryTrackingConfidence: TrackingConfidence = TrackingConfidence.UNTRACKED,
    val progressFraction: Float = 0f,
    val nextResetFormatted: String = "12:00 AM",
    val timeUntilResetFormatted: String = "",
    val blockingGuardState: BlockingGuardState = BlockingGuardState.PERMISSION_MISSING,
    val disciplineStatus: DisciplineStatus = DisciplineStatus.SETUP_REQUIRED,
    val currentStreakDays: Int = 0,
    val platforms: List<PlatformUsageSummary> = emptyList(),
    val permissions: PermissionStatusSnapshot = PermissionStatusSnapshot(),
    val todayBlockEventsCount: Int = 0,
    val isLoading: Boolean = true
)
