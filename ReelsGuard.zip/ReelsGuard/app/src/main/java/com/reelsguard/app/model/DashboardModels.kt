package com.reelsguard.app.model

data class PermissionStatusSnapshot(
    val isAccessibilityEnabled: Boolean = false,
    val isUsageAccessGranted: Boolean = false,
    val isOverlayGranted: Boolean = false,
    val isNotificationGranted: Boolean = true
) {
    val canBlockAutomatically: Boolean
        get() = isAccessibilityEnabled

    val canTrackReelsSection: Boolean
        get() = isAccessibilityEnabled

    val canTrackFallbackAppUsage: Boolean
        get() = isUsageAccessGranted

    val hasAnyTrackingPermission: Boolean
        get() = isAccessibilityEnabled || isUsageAccessGranted
}

data class PlatformUsageSummary(
    val platform: Platform,
    val isTrackingEnabled: Boolean,
    val isLimitEnabled: Boolean,
    val dailyLimitMinutes: Int,
    val blockMode: BlockMode,
    val verifiedReelsSeconds: Long,
    val fallbackAppSeconds: Long,
    val activeConfidence: TrackingConfidence,
    val isCurrentlyBlocked: Boolean
) {
    /**
     * Effective seconds evaluated against the limit based on the active confidence mode.
     * Note: UI always displays the confidence tag clearly so fallback time is never disguised as Reels time.
     */
    val effectiveSecondsForLimit: Long
        get() = when (activeConfidence) {
            TrackingConfidence.VERIFIED_SECTION -> verifiedReelsSeconds
            TrackingConfidence.APP_WIDE_FALLBACK -> fallbackAppSeconds
            TrackingConfidence.UNTRACKED -> 0L
        }

    val limitSeconds: Long
        get() = dailyLimitMinutes.coerceAtLeast(1) * 60L

    val remainingSeconds: Long
        get() = if (!isLimitEnabled) Long.MAX_VALUE else (limitSeconds - effectiveSecondsForLimit).coerceAtLeast(0L)

    val progressFraction: Float
        get() = if (!isLimitEnabled || limitSeconds <= 0L) {
            0f
        } else {
            (effectiveSecondsForLimit.toFloat() / limitSeconds.toFloat()).coerceIn(0f, 1f)
        }
}

data class DashboardUiState(
    val currentDateKey: String = "",
    val totalVerifiedReelsSeconds: Long = 0L,
    val totalFallbackAppSeconds: Long = 0L,
    val primaryTrackingConfidence: TrackingConfidence = TrackingConfidence.UNTRACKED,
    val totalDailyLimitMinutes: Int = 45,
    val isTotalDailyLimitEnabled: Boolean = true,
    val remainingTotalSeconds: Long = 45 * 60L,
    val progressFraction: Float = 0f,
    val nextResetFormatted: String = "12:00 AM",
    val timeUntilResetFormatted: String = "",
    val blockingGuardState: BlockingGuardState = BlockingGuardState.PERMISSION_MISSING,
    val disciplineStatus: DisciplineStatus = DisciplineStatus.SETUP_REQUIRED,
    val currentStreakDays: Int = 0,
    val platforms: List<PlatformUsageSummary> = emptyList(),
    val permissions: PermissionStatusSnapshot = PermissionStatusSnapshot(),
    val todayBlockEventsCount: Int = 0,
    val isLoading: Boolean = true
)
