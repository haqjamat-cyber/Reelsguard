package com.reelsguard.app.repository

import com.reelsguard.app.data.UserPreferencesRepository
import com.reelsguard.app.database.dao.BlockingEventDao
import com.reelsguard.app.database.dao.DailySummaryDao
import com.reelsguard.app.database.dao.DailyUsageDao
import com.reelsguard.app.database.entity.BlockingEventEntity
import com.reelsguard.app.database.entity.DailySummaryEntity
import com.reelsguard.app.database.entity.DailyUsageEntity
import com.reelsguard.app.model.AnalyticsUiState
import com.reelsguard.app.model.DailyChartPoint
import com.reelsguard.app.model.HistoricalUsageRow
import com.reelsguard.app.model.MonthlyOverview
import com.reelsguard.app.model.Platform
import com.reelsguard.app.model.PlatformComparisonItem
import com.reelsguard.app.model.WeeklyReportSummary
import com.reelsguard.app.utils.ResetScheduleCalculator
import com.reelsguard.app.utils.TimeFormatter
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import java.time.ZonedDateTime

class AnalyticsRepository(
    private val dailyUsageDao: DailyUsageDao,
    private val dailySummaryDao: DailySummaryDao,
    private val blockingEventDao: BlockingEventDao,
    private val preferencesRepository: UserPreferencesRepository
) {

    fun observeAnalytics(): Flow<AnalyticsUiState> {
        val thirtyDaysAgoKey = ResetScheduleCalculator.recentDateKeys(days = 30).firstOrNull().orEmpty()
        return combine(
            dailyUsageDao.observeAllUsage(),
            dailySummaryDao.observeAllSummaries(),
            blockingEventDao.observeEventsFromDate(thirtyDaysAgoKey),
            preferencesRepository.preferencesFlow
        ) { allUsage, summaries, recentBlocks, prefs ->
            buildAnalyticsState(
                allUsage = allUsage,
                summaries = summaries,
                recentBlocks = recentBlocks,
                resetHour = prefs.resetHour,
                resetMinute = prefs.resetMinute,
                totalDailyLimitMinutes = prefs.totalDailyLimitMinutes
            )
        }
    }

    private fun buildAnalyticsState(
        allUsage: List<DailyUsageEntity>,
        summaries: List<DailySummaryEntity>,
        recentBlocks: List<BlockingEventEntity>,
        resetHour: Int,
        resetMinute: Int,
        totalDailyLimitMinutes: Int
    ): AnalyticsUiState {
        val now = ZonedDateTime.now()
        val todayKey = ResetScheduleCalculator.getCurrentCycleDateKey(now, resetHour, resetMinute)
        val last7Keys = ResetScheduleCalculator.recentDateKeys(7, now, resetHour, resetMinute)
        val last14Keys = ResetScheduleCalculator.recentDateKeys(14, now, resetHour, resetMinute)
        val prev7Keys = last14Keys.take(7)
        val last30Keys = ResetScheduleCalculator.recentDateKeys(30, now, resetHour, resetMinute)

        val usageByDate = allUsage.groupBy { it.dateKey }
        val summaryByDate = summaries.associateBy { it.dateKey }

        fun effectiveSeconds(entity: DailyUsageEntity): Long {
            return if (entity.verifiedReelsSeconds > 0L) entity.verifiedReelsSeconds else entity.fallbackAppSeconds
        }

        fun buildPoint(dateKey: String): DailyChartPoint {
            val rows = usageByDate[dateKey].orEmpty()
            val verifiedSec = rows.sumOf { it.verifiedReelsSeconds }
            val fallbackSec = rows.sumOf { it.fallbackAppSeconds }
            val effectiveSec = if (verifiedSec > 0L) verifiedSec else fallbackSec
            val summary = summaryByDate[dateKey]
            val goalMet = summary?.goalMet ?: (effectiveSec <= totalDailyLimitMinutes * 60L)
            return DailyChartPoint(
                dateKey = dateKey,
                shortLabel = ResetScheduleCalculator.formatDateKeyShortDay(dateKey),
                verifiedMinutes = verifiedSec / 60f,
                fallbackMinutes = fallbackSec / 60f,
                totalMinutes = effectiveSec / 60f,
                goalMet = goalMet
            )
        }

        val weeklyPoints = last7Keys.map { buildPoint(it) }
        val monthlyPoints = last30Keys.map { buildPoint(it) }

        // Today per-platform comparison
        val todayRows = usageByDate[todayKey].orEmpty()
        val todayGrandTotal = todayRows.sumOf { effectiveSeconds(it) }.coerceAtLeast(1L)
        val todayPlatformItems = Platform.entries.map { platform ->
            val entity = todayRows.firstOrNull { it.platform == platform }
            val verified = entity?.verifiedReelsSeconds ?: 0L
            val fallback = entity?.fallbackAppSeconds ?: 0L
            val eff = if (verified > 0L) verified else fallback
            PlatformComparisonItem(
                platform = platform,
                verifiedSeconds = verified,
                fallbackSeconds = fallback,
                shareFraction = (eff.toFloat() / todayGrandTotal.toFloat()).coerceIn(0f, 1f)
            )
        }

        // 30-day platform comparison
        val last30Set = last30Keys.toSet()
        val last30Rows = allUsage.filter { it.dateKey in last30Set }
        val platformTotals = Platform.entries.map { platform ->
            val pRows = last30Rows.filter { it.platform == platform }
            val verified = pRows.sumOf { it.verifiedReelsSeconds }
            val fallback = pRows.sumOf { it.fallbackAppSeconds }
            Triple(platform, verified, fallback)
        }
        val grandPlatformEff = platformTotals.sumOf { (_, v, f) -> if (v > 0L) v else f }.coerceAtLeast(1L)
        val platformComparisons = platformTotals.map { (platform, verified, fallback) ->
            val eff = if (verified > 0L) verified else fallback
            PlatformComparisonItem(
                platform = platform,
                verifiedSeconds = verified,
                fallbackSeconds = fallback,
                shareFraction = (eff.toFloat() / grandPlatformEff.toFloat()).coerceIn(0f, 1f)
            )
        }.sortedByDescending { if (it.verifiedSeconds > 0L) it.verifiedSeconds else it.fallbackSeconds }

        val mostUsedPlatform = platformComparisons.firstOrNull {
            it.verifiedSeconds > 0L || it.fallbackSeconds > 0L
        }?.platform

        // Monthly overview stats
        val activeMonthDays = monthlyPoints.filter { it.totalMinutes > 0f }
        val totalMonthSeconds = monthlyPoints.sumOf { (it.totalMinutes * 60f).toLong() }
        val avgDailySeconds = if (activeMonthDays.isNotEmpty()) {
            totalMonthSeconds / activeMonthDays.size
        } else {
            0L
        }

        val monthlyOverview = MonthlyOverview(
            daysTracked = activeMonthDays.size,
            daysGoalMet = monthlyPoints.count { it.goalMet && (it.dateKey in summaryByDate || it.dateKey == todayKey) },
            totalTrackedSeconds = totalMonthSeconds,
            averageDailySeconds = avgDailySeconds,
            dailyPoints = monthlyPoints
        )

        // Weekly report (current 7d vs previous 7d)
        val currentWeekSeconds = weeklyPoints.sumOf { (it.totalMinutes * 60f).toLong() }
        val prevWeekSeconds = prev7Keys.map { buildPoint(it) }.sumOf { (it.totalMinutes * 60f).toLong() }
        val deltaPercent = if (prevWeekSeconds > 0L) {
            (((currentWeekSeconds - prevWeekSeconds).toDouble() / prevWeekSeconds.toDouble()) * 100.0).toInt()
        } else {
            null
        }
        val last7Set = last7Keys.toSet()
        val weekBlocksCount = recentBlocks.count { it.dateKey in last7Set }
        val peakDay = weeklyPoints.maxByOrNull { it.totalMinutes }?.takeIf { it.totalMinutes > 0f }
        val daysUnderLimit = weeklyPoints.count {
            it.goalMet && (it.totalMinutes > 0f || it.dateKey in summaryByDate)
        }

        val weekInsight = when {
            currentWeekSeconds == 0L ->
                "No short-form sessions recorded this week yet. Your weekly report updates automatically as you use supported apps."
            deltaPercent != null && deltaPercent < -10 ->
                "You reduced short-form viewing by ${-deltaPercent}% compared to last week. Steady progress!"
            deltaPercent != null && deltaPercent > 15 ->
                "Usage rose by $deltaPercent% vs last week. Consider tightening your busiest platform's limit by 5 minutes."
            else ->
                "Consistent rhythm this week with an average of ${TimeFormatter.formatDurationCompact(currentWeekSeconds / 7)} per day."
        }

        val weekLabel = if (last7Keys.size >= 2) {
            val startLabel = ResetScheduleCalculator.formatDateKeyReadable(last7Keys.first()).take(6)
            val endLabel = ResetScheduleCalculator.formatDateKeyReadable(last7Keys.last()).take(6)
            "$startLabel - $endLabel"
        } else {
            "This Week"
        }

        val weeklyReport = WeeklyReportSummary(
            weekLabel = weekLabel,
            currentWeekTotalSeconds = currentWeekSeconds,
            previousWeekTotalSeconds = prevWeekSeconds,
            deltaPercent = deltaPercent,
            daysUnderLimit = daysUnderLimit,
            totalBlockingEvents = weekBlocksCount,
            peakDayLabel = peakDay?.let { ResetScheduleCalculator.formatDateKeyReadable(it.dateKey) } ?: "No data yet",
            peakDaySeconds = peakDay?.let { (it.totalMinutes * 60f).toLong() } ?: 0L,
            mostUsedPlatform = mostUsedPlatform,
            dailyBreakdown = weeklyPoints,
            insightMessage = weekInsight
        )

        // Historical daily rows (most recent first)
        val historicalRows = usageByDate.entries
            .sortedByDescending { it.key }
            .take(30)
            .map { (dateKey, rows) ->
                val ig = rows.firstOrNull { it.platform == Platform.INSTAGRAM }?.let { effectiveSeconds(it) } ?: 0L
                val yt = rows.firstOrNull { it.platform == Platform.YOUTUBE }?.let { effectiveSeconds(it) } ?: 0L
                val fb = rows.firstOrNull { it.platform == Platform.FACEBOOK }?.let { effectiveSeconds(it) } ?: 0L
                val verified = rows.sumOf { it.verifiedReelsSeconds }
                val fallback = rows.sumOf { it.fallbackAppSeconds }
                val effective = if (verified > 0L) verified else fallback
                val goalMet = summaryByDate[dateKey]?.goalMet ?: (effective <= totalDailyLimitMinutes * 60L)
                HistoricalUsageRow(
                    dateKey = dateKey,
                    formattedDate = ResetScheduleCalculator.formatDateKeyReadable(dateKey),
                    instagramSeconds = ig,
                    youtubeSeconds = yt,
                    facebookSeconds = fb,
                    verifiedTotalSeconds = verified,
                    fallbackTotalSeconds = fallback,
                    goalMet = goalMet
                )
            }

        return AnalyticsUiState(
            todayPlatformPoints = todayPlatformItems,
            weeklyChartPoints = weeklyPoints,
            monthlyOverview = monthlyOverview,
            platformComparisons = platformComparisons,
            averageDailySeconds = avgDailySeconds,
            mostUsedPlatform = mostUsedPlatform,
            historicalRecords = historicalRows,
            weeklyReport = weeklyReport,
            totalVerifiedSecondsAllTime = allUsage.sumOf { it.verifiedReelsSeconds },
            totalFallbackSecondsAllTime = allUsage.sumOf { it.fallbackAppSeconds },
            isLoading = false
        )
    }
}
