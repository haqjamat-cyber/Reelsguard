package com.reelsguard.app.service

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import com.reelsguard.app.model.Platform
import com.reelsguard.app.utils.PermissionHelper

/**
 * Reads application-level usage via Android's UsageStatsManager.queryEvents() strictly
 * as a clearly labeled Full-App Fallback source.
 *
 * IMPORTANT:
 * Android's UsageStatsManager only reports whole-app foreground intervals and CANNOT distinguish
 * Instagram Reels from Instagram Messages or Feed. Values returned here are ALWAYS stored under
 * `fallbackAppSeconds` and NEVER labeled as verified Reels/Shorts viewing time.
 */
class UsageStatsSyncManager(private val context: Context) {

    fun queryAppWideUsageSeconds(
        cycleStartEpochMs: Long,
        nowEpochMs: Long = System.currentTimeMillis()
    ): Map<Platform, Long> {
        if (!PermissionHelper.isUsageStatsPermissionGranted(context)) {
            return emptyMap()
        }
        if (nowEpochMs <= cycleStartEpochMs) {
            return emptyMap()
        }

        val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            ?: return emptyMap()

        val events = runCatching {
            usageStatsManager.queryEvents(cycleStartEpochMs, nowEpochMs)
        }.getOrNull() ?: return emptyMap()

        val activeStartPerPlatform = mutableMapOf<Platform, Long>()
        val accumulatedMillis = mutableMapOf<Platform, Long>()
        val event = UsageEvents.Event()

        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            val platform = Platform.fromPackageName(event.packageName) ?: continue

            val isForegroundEvent = isMoveToForeground(event.eventType)
            val isBackgroundEvent = isMoveToBackground(event.eventType)

            when {
                isForegroundEvent -> {
                    if (!activeStartPerPlatform.containsKey(platform)) {
                        activeStartPerPlatform[platform] = event.timeStamp.coerceAtLeast(cycleStartEpochMs)
                    }
                }
                isBackgroundEvent -> {
                    val startTs = activeStartPerPlatform.remove(platform)
                    if (startTs != null && event.timeStamp > startTs) {
                        accumulatedMillis[platform] = (accumulatedMillis[platform] ?: 0L) +
                            (event.timeStamp - startTs)
                    }
                }
            }
        }

        // Close any currently foreground session at `nowEpochMs`
        for ((platform, startTs) in activeStartPerPlatform) {
            if (nowEpochMs > startTs) {
                accumulatedMillis[platform] = (accumulatedMillis[platform] ?: 0L) +
                    (nowEpochMs - startTs)
            }
        }

        return Platform.entries.associateWith { platform ->
            ((accumulatedMillis[platform] ?: 0L) / 1000L).coerceAtLeast(0L)
        }
    }

    @Suppress("DEPRECATION")
    private fun isMoveToForeground(eventType: Int): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            eventType == UsageEvents.Event.ACTIVITY_RESUMED ||
                eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
        } else {
            eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
        }
    }

    @Suppress("DEPRECATION")
    private fun isMoveToBackground(eventType: Int): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            eventType == UsageEvents.Event.ACTIVITY_PAUSED ||
                eventType == UsageEvents.Event.ACTIVITY_STOPPED ||
                eventType == UsageEvents.Event.MOVE_TO_BACKGROUND
        } else {
            eventType == UsageEvents.Event.MOVE_TO_BACKGROUND
        }
    }
}
