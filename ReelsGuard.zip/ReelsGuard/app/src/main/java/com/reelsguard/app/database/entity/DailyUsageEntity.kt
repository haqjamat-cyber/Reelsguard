package com.reelsguard.app.database.entity

import androidx.room.Entity
import com.reelsguard.app.model.Platform
import com.reelsguard.app.model.TrackingConfidence

@Entity(
    tableName = "daily_usage",
    primaryKeys = ["dateKey", "platform"]
)
data class DailyUsageEntity(
    val dateKey: String,
    val platform: Platform,
    val verifiedReelsSeconds: Long = 0L,
    val fallbackAppSeconds: Long = 0L,
    val watchedReelsCount: Int = 0,
    val lastConfidence: TrackingConfidence = TrackingConfidence.UNTRACKED,
    val limitMinutesSnapshot: Int = platform.defaultLimitMinutes,
    val wasBlockedToday: Boolean = false,
    val lastUpdatedEpochMs: Long = System.currentTimeMillis()
)
