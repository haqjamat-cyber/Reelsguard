package com.reelsguard.app.database.entity

import androidx.room.Entity
import com.reelsguard.app.model.Platform
import com.reelsguard.app.model.TrackingConfidence

/**
 * Stores daily usage per platform with strict separation between:
 * - [verifiedReelsSeconds]: tracked via AccessibilityService on detected Reels/Shorts screens.
 * - [fallbackAppSeconds]: tracked via UsageStatsManager for the entire app package when fallback is used.
 */
@Entity(
    tableName = "daily_usage",
    primaryKeys = ["dateKey", "platform"]
)
data class DailyUsageEntity(
    val dateKey: String,
    val platform: Platform,
    val verifiedReelsSeconds: Long = 0L,
    val fallbackAppSeconds: Long = 0L,
    val lastConfidence: TrackingConfidence = TrackingConfidence.UNTRACKED,
    val limitMinutesSnapshot: Int = platform.defaultLimitMinutes,
    val wasBlockedToday: Boolean = false,
    val lastUpdatedEpochMs: Long = System.currentTimeMillis()
)
