package com.reelsguard.app.analytics

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Assessment
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.reelsguard.app.components.GlassCard
import com.reelsguard.app.components.MonthlyDisciplineHeatmap
import com.reelsguard.app.components.MonthlyTrendLineChart
import com.reelsguard.app.components.PlatformComparisonBars
import com.reelsguard.app.components.PremiumBackground
import com.reelsguard.app.components.ScreenTopHeader
import com.reelsguard.app.components.StatusPill
import com.reelsguard.app.components.WeeklyUsageBarChart
import com.reelsguard.app.ui.theme.ReelsGuardTheme
import com.reelsguard.app.utils.TimeFormatter

@Composable
fun AnalyticsScreen(
    viewModel: AnalyticsViewModel,
    onOpenWeeklyReports: () -> Unit,
    contentBottomPadding: PaddingValues = PaddingValues(bottom = 92.dp)
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val extra = ReelsGuardTheme.colors
    var selectedRangeTab by remember { mutableIntStateOf(1) } // 0 = Today, 1 = 7 Days, 2 = 30 Days

    LaunchedEffect(Unit) {
        viewModel.refreshFallbackStats()
    }

    PremiumBackground {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding(),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = 12.dp,
                bottom = contentBottomPadding.calculateBottomPadding() + 16.dp
            ),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                ScreenTopHeader(
                    title = "Analytics",
                    subtitle = "Local insights across daily, weekly & monthly habits"
                )
            }

            // Quick KPI summary row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    GlassCard(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "AVG DAILY",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = TimeFormatter.formatDurationCompact(state.averageDailySeconds),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${state.monthlyOverview.daysTracked} active days",
                            style = MaterialTheme.typography.labelSmall,
                            color = extra.accentBlue
                        )
                    }
                    GlassCard(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "TOP PLATFORM",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = state.mostUsedPlatform?.displayName ?: "None yet",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = state.mostUsedPlatform?.shortFormLabel ?: "Start tracking",
                            style = MaterialTheme.typography.labelSmall,
                            color = extra.accentPurple
                        )
                    }
                }
            }

            // Link to dedicated Weekly Reports screen
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    highlightAccent = extra.accentBlue,
                    onClick = onOpenWeeklyReports
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Assessment,
                                contentDescription = null,
                                tint = extra.accentBlue
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Weekly Report (${state.weeklyReport.weekLabel})",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "View week-over-week delta, blocks & peak day",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.Rounded.ChevronRight,
                            contentDescription = "Open Weekly Report",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Range Selector Tabs
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Daily", "Weekly", "Monthly").forEachIndexed { idx, label ->
                        FilterChip(
                            selected = selectedRangeTab == idx,
                            onClick = { selectedRangeTab = idx },
                            label = { Text(label) }
                        )
                    }
                }
            }

            // Interactive Vico / Compose Chart Card based on active range
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    when (selectedRangeTab) {
                        0 -> {
                            Text(
                                text = "Today's Platform Breakdown",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Verified Reels/Shorts and Full-App Fallback are always labeled separately.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            PlatformComparisonBars(items = state.todayPlatformPoints)
                        }
                        1 -> {
                            Text(
                                text = "7-Day Usage Chart (Minutes)",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Daily short-form minutes across the past 7 days",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            WeeklyUsageBarChart(points = state.weeklyChartPoints)
                        }
                        else -> {
                            Text(
                                text = "30-Day Monthly Overview",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Total: ${TimeFormatter.formatDurationCompact(state.monthlyOverview.totalTrackedSeconds)} • Goal met ${state.monthlyOverview.daysGoalMet} days",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            MonthlyTrendLineChart(points = state.monthlyOverview.dailyPoints)
                            Spacer(modifier = Modifier.height(16.dp))
                            MonthlyDisciplineHeatmap(points = state.monthlyOverview.dailyPoints)
                        }
                    }
                }
            }

            // Platform-wise 30-Day Comparison
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Platform-Wise Comparison (30 Days)",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    PlatformComparisonBars(items = state.platformComparisons)
                }
            }

            // Measurement Transparency Card
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Data Integrity Summary",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Verified Reels/Shorts",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = TimeFormatter.formatDurationCompact(state.totalVerifiedSecondsAllTime),
                                style = MaterialTheme.typography.titleMedium,
                                color = extra.success
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Full-App Fallback",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = TimeFormatter.formatDurationCompact(state.totalFallbackSecondsAllTime),
                                style = MaterialTheme.typography.titleMedium,
                                color = extra.accentBlue
                            )
                        }
                    }
                }
            }

            // Historical Usage Records
            item {
                Text(
                    text = "Historical Records",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            if (state.historicalRecords.isEmpty()) {
                item {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "No usage history recorded yet.",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "ReelsGuard never injects fake sample numbers. Once tracking is active, your real daily records appear here automatically.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                items(state.historicalRecords, key = { it.dateKey }) { row ->
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = row.formattedDate,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (row.verifiedTotalSeconds > 0L) "Verified Reels/Shorts" else "Full-App Fallback",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            StatusPill(
                                text = if (row.goalMet) "Goal Met" else "Over Limit",
                                tint = if (row.goalMet) extra.success else extra.danger,
                                icon = if (row.goalMet) Icons.Rounded.CheckCircle else Icons.Rounded.Warning
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "IG: ${TimeFormatter.formatDurationCompact(row.instagramSeconds)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "YT: ${TimeFormatter.formatDurationCompact(row.youtubeSeconds)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "FB: ${TimeFormatter.formatDurationCompact(row.facebookSeconds)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = TimeFormatter.formatDurationCompact(row.combinedSeconds),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}
