package com.reelsguard.app

import android.app.Application
import com.reelsguard.app.service.DailyResetScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class ReelsGuardApplication : Application() {

    lateinit var container: AppContainer
        private set

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)

        appScope.launch {
            container.usageRepository.initializeDefaults()
            val prefs = container.preferencesRepository.currentPreferences()
            DailyResetScheduler.scheduleNextExactReset(
                context = this@ReelsGuardApplication,
                resetHour = prefs.resetHour,
                resetMinute = prefs.resetMinute
            )
            DailyResetScheduler.ensurePeriodicSafetyCheck(this@ReelsGuardApplication)
        }
    }
}
