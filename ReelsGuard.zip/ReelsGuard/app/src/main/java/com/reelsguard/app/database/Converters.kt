package com.reelsguard.app.database

import androidx.room.TypeConverter
import com.reelsguard.app.model.BlockMode
import com.reelsguard.app.model.Platform
import com.reelsguard.app.model.TrackingConfidence

class Converters {

    @TypeConverter
    fun fromPlatform(platform: Platform): String = platform.name

    @TypeConverter
    fun toPlatform(value: String): Platform =
        runCatching { Platform.valueOf(value) }.getOrDefault(Platform.INSTAGRAM)

    @TypeConverter
    fun fromBlockMode(mode: BlockMode): String = mode.name

    @TypeConverter
    fun toBlockMode(value: String): BlockMode =
        runCatching { BlockMode.valueOf(value) }.getOrDefault(BlockMode.SECTION_ONLY)

    @TypeConverter
    fun fromTrackingConfidence(confidence: TrackingConfidence): String = confidence.name

    @TypeConverter
    fun toTrackingConfidence(value: String): TrackingConfidence =
        runCatching { TrackingConfidence.valueOf(value) }.getOrDefault(TrackingConfidence.UNTRACKED)
}
