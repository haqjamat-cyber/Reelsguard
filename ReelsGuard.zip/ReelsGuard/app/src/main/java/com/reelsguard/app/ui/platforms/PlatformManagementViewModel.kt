package com.reelsguard.app.ui.platforms

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.reelsguard.app.database.entity.PlatformLimitEntity
import com.reelsguard.app.model.BlockMode
import com.reelsguard.app.model.PermissionStatusSnapshot
import com.reelsguard.app.model.Platform
import com.reelsguard.app.repository.UsageRepository
import com.reelsguard.app.utils.PermissionHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class PlatformManagementUiState(
    val configs: List<PlatformLimitEntity> = Platform.entries.map { PlatformLimitEntity(platform = it) },
    val permissions: PermissionStatusSnapshot = PermissionStatusSnapshot()
)

class PlatformManagementViewModel(
    private val appContext: Context,
    private val usageRepository: UsageRepository
) : ViewModel() {

    private val permissionsFlow = MutableStateFlow(PermissionHelper.getPermissionSnapshot(appContext))

    val uiState: StateFlow<PlatformManagementUiState> = combine(
        usageRepository.observeLimits(),
        permissionsFlow
    ) { limits, perms ->
        val map = limits.associateBy { it.platform }
        PlatformManagementUiState(
            configs = Platform.entries.map { map[it] ?: PlatformLimitEntity(platform = it) },
            permissions = perms
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = PlatformManagementUiState()
    )

    fun refreshPermissions() {
        permissionsFlow.value = PermissionHelper.getPermissionSnapshot(appContext)
    }

    fun setTrackingEnabled(platform: Platform, enabled: Boolean) {
        viewModelScope.launch {
            usageRepository.updatePlatformTrackingEnabled(platform, enabled)
        }
    }

    fun setBlockMode(platform: Platform, mode: BlockMode) {
        viewModelScope.launch {
            usageRepository.updatePlatformBlockMode(platform, mode)
        }
    }
}
