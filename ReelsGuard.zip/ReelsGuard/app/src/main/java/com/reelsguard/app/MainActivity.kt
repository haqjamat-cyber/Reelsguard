package com.reelsguard.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.reelsguard.app.data.UserPreferences
import com.reelsguard.app.navigation.ReelsGuardNavHost
import com.reelsguard.app.ui.theme.ReelsGuardTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as ReelsGuardApplication

        setContent {
            val prefs by app.container.preferencesRepository.preferencesFlow
                .collectAsStateWithLifecycle(initialValue = UserPreferences())

            ReelsGuardTheme(themeMode = prefs.themeMode) {
                ReelsGuardNavHost(container = app.container)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val app = application as ReelsGuardApplication
        lifecycleScope.launch {
            app.container.usageRepository.ensureDailyResetIfNeeded()
            app.container.usageRepository.syncFallbackUsageStatsIfPermitted()
        }
    }
}
