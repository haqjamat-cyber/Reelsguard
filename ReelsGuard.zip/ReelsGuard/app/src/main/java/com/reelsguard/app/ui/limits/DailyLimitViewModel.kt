package com.reelsguard.app.ui.limits

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.reelsguard.app.data.UserPreferencesRepository
import com.reelsguard.app.database.entity.PlatformLimitEntity
import com.reelsguard.app.model.Platform
import com.reelsguard.app.repository.UsageRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DailyLimitUiState(
    val totalDailyVideoLimit: Int = 0,
    val isTotalDailyLimitEnabled: Boolean = false,
    val platformLimits: List<PlatformLimitEntity> = Platform.entries.map { PlatformLimitEntity(platform = it) }
)

class DailyLimitViewModel(
    private val usageRepository: UsageRepository,
    private val preferencesRepository: UserPreferencesRepository
) : ViewModel() {

    val uiState: StateFlow<DailyLimitUiState> = combine(
        preferencesRepository.preferencesFlow,
        usageRepository.observeLimits()
    ) { prefs, limits ->
        val byPlatform = limits.associateBy { it.platform }
        DailyLimitUiState(
            totalDailyVideoLimit = prefs.totalDailyVideoLimit,
            isTotalDailyLimitEnabled = prefs.isTotalDailyLimitEnabled,
            platformLimits = Platform.entries.map { byPlatform[it] ?: PlatformLimitEntity(platform = it) }
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = DailyLimitUiState()
    )

    fun updateTotalVideoLimit(videoCount: Int, enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setTotalDailyVideoLimit(videoCount, enabled)
        }
    }

    fun updatePlatformVideoLimit(platform: Platform, videoCount: Int, enabled: Boolean) {
        viewModelScope.launch {
            usageRepository.updatePlatformVideoLimit(platform, videoCount, enabled)
        }
    }
}
