package com.reelsguard.app.analytics

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.reelsguard.app.model.AnalyticsUiState
import com.reelsguard.app.repository.AnalyticsRepository
import com.reelsguard.app.repository.UsageRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AnalyticsViewModel(
    analyticsRepository: AnalyticsRepository,
    private val usageRepository: UsageRepository
) : ViewModel() {

    val uiState: StateFlow<AnalyticsUiState> = analyticsRepository.observeAnalytics()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000L),
            initialValue = AnalyticsUiState(isLoading = true)
        )

    fun refreshFallbackStats() {
        viewModelScope.launch {
            usageRepository.ensureDailyResetIfNeeded()
            usageRepository.syncFallbackUsageStatsIfPermitted()
        }
    }
}
