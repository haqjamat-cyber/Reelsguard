package com.reelsguard.app.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.reelsguard.app.model.BlockMode
import com.reelsguard.app.model.Platform

@Entity(tableName = "blocking_events")
data class BlockingEventEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val dateKey: String,
    val platform: Platform,
    val timestampEpochMs: Long = System.currentTimeMillis(),
    val blockModeUsed: BlockMode,
    val usageSecondsAtBlock: Long,
    val limitMinutesAtBlock: Int,
    val reason: String
)
