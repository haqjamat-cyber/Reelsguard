package com.reelsguard.app.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.reelsguard.app.database.entity.PlatformLimitEntity
import com.reelsguard.app.model.Platform
import kotlinx.coroutines.flow.Flow

@Dao
interface PlatformLimitDao {

    @Query("SELECT * FROM platform_limits ORDER BY platform ASC")
    fun observeAllLimits(): Flow<List<PlatformLimitEntity>>

    @Query("SELECT * FROM platform_limits")
    suspend fun getAllLimits(): List<PlatformLimitEntity>

    @Query("SELECT * FROM platform_limits WHERE platform = :platform LIMIT 1")
    suspend fun getLimit(platform: Platform): PlatformLimitEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: PlatformLimitEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertDefaultsIfMissing(entities: List<PlatformLimitEntity>)
}
