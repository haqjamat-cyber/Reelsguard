package com.reelsguard.app.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String) {
    data object Splash : Screen("splash")
    data object Onboarding : Screen("onboarding")
    data object Permissions : Screen("permissions/{fromOnboarding}") {
        fun createRoute(fromOnboarding: Boolean): String = "permissions/$fromOnboarding"
    }
    data object Dashboard : Screen("dashboard")
    data object Platforms : Screen("platforms")
    data object DailyLimits : Screen("daily_limits")
    data object Analytics : Screen("analytics")
    data object WeeklyReports : Screen("weekly_reports")
    data object Achievements : Screen("achievements")
    data object Settings : Screen("settings")
    data object About : Screen("about")
}

data class BottomNavDestination(
    val route: String,
    val label: String,
    val icon: ImageVector
)

val primaryBottomNavDestinations = listOf(
    BottomNavDestination(Screen.Dashboard.route, "Home", Icons.Rounded.Dashboard),
    BottomNavDestination(Screen.Platforms.route, "Apps", Icons.Rounded.Apps),
    BottomNavDestination(Screen.Analytics.route, "Stats", Icons.Rounded.BarChart),
    BottomNavDestination(Screen.Achievements.route, "Badges", Icons.Rounded.EmojiEvents),
    BottomNavDestination(Screen.Settings.route, "Settings", Icons.Rounded.Settings)
)
