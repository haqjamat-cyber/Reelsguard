package com.reelsguard.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.reelsguard.app.model.ThemeMode
import com.reelsguard.app.utils.ResetScheduleCalculator
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.reelsGuardDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "reelsguard_preferences"
)

data class UserPreferences(
    val onboardingCompleted: Boolean = false,
    val themeMode: ThemeMode = ThemeMode.DARK,
    val resetHour: Int = 0,
    val resetMinute: Int = 0,
    val totalDailyLimitMinutes: Int = 45,
    val isTotalDailyLimitEnabled: Boolean = true,
    val allowFullAppFallbackTracking: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val accessibilityDisclosureAccepted: Boolean = false,
    val usageAccessDisclosureAccepted: Boolean = false,
    val lastProcessedDateKey: String = "",
    val lastTimezoneId: String = ""
)

class UserPreferencesRepository(context: Context) {

    private val dataStore = context.applicationContext.reelsGuardDataStore

    private object Keys {
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val RESET_HOUR = intPreferencesKey("reset_hour")
        val RESET_MINUTE = intPreferencesKey("reset_minute")
        val TOTAL_DAILY_LIMIT_MINUTES = intPreferencesKey("total_daily_limit_minutes")
        val TOTAL_DAILY_LIMIT_ENABLED = booleanPreferencesKey("total_daily_limit_enabled")
        val ALLOW_FULL_APP_FALLBACK = booleanPreferencesKey("allow_full_app_fallback")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val ACCESSIBILITY_DISCLOSURE_ACCEPTED = booleanPreferencesKey("accessibility_disclosure_accepted")
        val USAGE_ACCESS_DISCLOSURE_ACCEPTED = booleanPreferencesKey("usage_access_disclosure_accepted")
        val LAST_PROCESSED_DATE_KEY = stringPreferencesKey("last_processed_date_key")
        val LAST_TIMEZONE_ID = stringPreferencesKey("last_timezone_id")
    }

    val preferencesFlow: Flow<UserPreferences> = dataStore.data.map { prefs ->
        val themeName = prefs[Keys.THEME_MODE] ?: ThemeMode.DARK.name
        UserPreferences(
            onboardingCompleted = prefs[Keys.ONBOARDING_COMPLETED] ?: false,
            themeMode = runCatching { ThemeMode.valueOf(themeName) }.getOrDefault(ThemeMode.DARK),
            resetHour = (prefs[Keys.RESET_HOUR] ?: 0).coerceIn(0, 23),
            resetMinute = (prefs[Keys.RESET_MINUTE] ?: 0).coerceIn(0, 59),
            totalDailyLimitMinutes = (prefs[Keys.TOTAL_DAILY_LIMIT_MINUTES] ?: 45).coerceIn(5, 360),
            isTotalDailyLimitEnabled = prefs[Keys.TOTAL_DAILY_LIMIT_ENABLED] ?: true,
            allowFullAppFallbackTracking = prefs[Keys.ALLOW_FULL_APP_FALLBACK] ?: true,
            notificationsEnabled = prefs[Keys.NOTIFICATIONS_ENABLED] ?: true,
            accessibilityDisclosureAccepted = prefs[Keys.ACCESSIBILITY_DISCLOSURE_ACCEPTED] ?: false,
            usageAccessDisclosureAccepted = prefs[Keys.USAGE_ACCESS_DISCLOSURE_ACCEPTED] ?: false,
            lastProcessedDateKey = prefs[Keys.LAST_PROCESSED_DATE_KEY] ?: "",
            lastTimezoneId = prefs[Keys.LAST_TIMEZONE_ID] ?: ResetScheduleCalculator.currentTimezoneId()
        )
    }

    suspend fun currentPreferences(): UserPreferences = preferencesFlow.first()

    suspend fun setOnboardingCompleted(completed: Boolean) {
        dataStore.edit { it[Keys.ONBOARDING_COMPLETED] = completed }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setResetTime(hour: Int, minute: Int) {
        dataStore.edit {
            it[Keys.RESET_HOUR] = hour.coerceIn(0, 23)
            it[Keys.RESET_MINUTE] = minute.coerceIn(0, 59)
        }
    }

    suspend fun setTotalDailyLimit(minutes: Int, enabled: Boolean) {
        dataStore.edit {
            it[Keys.TOTAL_DAILY_LIMIT_MINUTES] = minutes.coerceIn(5, 360)
            it[Keys.TOTAL_DAILY_LIMIT_ENABLED] = enabled
        }
    }

    suspend fun setTotalDailyLimitEnabled(enabled: Boolean) {
        dataStore.edit { it[Keys.TOTAL_DAILY_LIMIT_ENABLED] = enabled }
    }

    suspend fun setAllowFullAppFallbackTracking(allowed: Boolean) {
        dataStore.edit { it[Keys.ALLOW_FULL_APP_FALLBACK] = allowed }
    }

    suspend fun setNotificationsEnabled(enabled: Boolean) {
        dataStore.edit { it[Keys.NOTIFICATIONS_ENABLED] = enabled }
    }

    suspend fun setAccessibilityDisclosureAccepted(accepted: Boolean) {
        dataStore.edit { it[Keys.ACCESSIBILITY_DISCLOSURE_ACCEPTED] = accepted }
    }

    suspend fun setUsageAccessDisclosureAccepted(accepted: Boolean) {
        dataStore.edit { it[Keys.USAGE_ACCESS_DISCLOSURE_ACCEPTED] = accepted }
    }

    suspend fun updateResetTrackingState(dateKey: String, timezoneId: String) {
        dataStore.edit {
            it[Keys.LAST_PROCESSED_DATE_KEY] = dateKey
            it[Keys.LAST_TIMEZONE_ID] = timezoneId
        }
    }
}
