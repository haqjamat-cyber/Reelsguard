package com.reelsguard.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.reelsguard.app.ReelsGuardApplication
import com.reelsguard.app.service.DailyResetScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Handles device reboots, timezone changes, and system clock/date changes so daily reset
 * boundaries remain accurate and WorkManager schedules are restored.
 */
class BootAndTimeChangeReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        val relevant = action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_TIMEZONE_CHANGED ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_DATE_CHANGED

        if (!relevant) return

        val pendingResult = goAsync()
        val app = context.applicationContext as? ReelsGuardApplication
        if (app == null) {
            pendingResult.finish()
            return
        }

        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                app.container.usageRepository.ensureDailyResetIfNeeded()
                val prefs = app.container.preferencesRepository.currentPreferences()
                DailyResetScheduler.scheduleNextExactReset(
                    context = app,
                    resetHour = prefs.resetHour,
                    resetMinute = prefs.resetMinute
                )
                DailyResetScheduler.ensurePeriodicSafetyCheck(app)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
