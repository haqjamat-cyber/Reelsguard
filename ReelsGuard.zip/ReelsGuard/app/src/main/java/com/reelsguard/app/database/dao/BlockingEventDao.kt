package com.reelsguard.app.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.reelsguard.app.database.entity.BlockingEventEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BlockingEventDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(event: BlockingEventEntity)

    @Query("SELECT COUNT(*) FROM blocking_events WHERE dateKey = :dateKey")
    fun observeCountForDate(dateKey: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM blocking_events WHERE dateKey = :dateKey")
    suspend fun getCountForDate(dateKey: String): Int

    @Query("SELECT * FROM blocking_events WHERE dateKey >= :fromDateKey ORDER BY timestampEpochMs DESC")
    fun observeEventsFromDate(fromDateKey: String): Flow<List<BlockingEventEntity>>

    @Query("DELETE FROM blocking_events")
    suspend fun clearAll()
}
