package com.reelsguard.app.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_summaries")
data class DailySummaryEntity(
    @PrimaryKey
    val dateKey: String,
    val totalVerifiedSeconds: Long = 0L,
    val totalFallbackSeconds: Long = 0L,
    val totalLimitMinutes: Int = 45,
    val goalMet: Boolean = true,
    val blockEventsCount: Int = 0,
    val streakOnDay: Int = 0,
    val closedAtEpochMs: Long = System.currentTimeMillis()
)
