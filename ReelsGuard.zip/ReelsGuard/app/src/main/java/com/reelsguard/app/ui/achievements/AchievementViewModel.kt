package com.reelsguard.app.ui.achievements

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.reelsguard.app.repository.AchievementOverview
import com.reelsguard.app.repository.AchievementRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

class AchievementViewModel(
    achievementRepository: AchievementRepository
) : ViewModel() {

    val uiState: StateFlow<AchievementOverview> = achievementRepository.observeOverview()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000L),
            initialValue = AchievementOverview()
        )
}
