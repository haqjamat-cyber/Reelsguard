package com.reelsguard.app.ui.theme

import androidx.compose.ui.graphics.Color

// Core Obsidian & Dark Navy Surfaces
val DeepObsidian = Color(0xFF060811)
val DarkNavy = Color(0xFF0D1122)
val ElevatedNavy = Color(0xFF141A33)
val SurfaceNavyHigh = Color(0xFF1B2342)

// Electric Accents
val ElectricPurple = Color(0xFF7C4DFF)
val ElectricPurpleLight = Color(0xFFA78BFA)
val ElectricBlue = Color(0xFF3B82F6)
val CyanGlow = Color(0xFF22D3EE)

// Semantic Status Colors
val EmeraldSuccess = Color(0xFF10B981)
val AmberWarning = Color(0xFFF59E0B)
val CoralAlert = Color(0xFFF43F5E)

// Dark Mode Text
val InkWhite = Color(0xFFF8FAFC)
val InkSlateMuted = Color(0xFF94A3B8)

// Crisp Light Mode Surfaces & Ink
val PorcelainBg = Color(0xFFF4F6FC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEAEFF9)
val LightInkPrimary = Color(0xFF0E1325)
val LightInkSecondary = Color(0xFF4F5973)
val DeepPurpleLightMode = Color(0xFF5B35D5)
val DeepBlueLightMode = Color(0xFF2563EB)
