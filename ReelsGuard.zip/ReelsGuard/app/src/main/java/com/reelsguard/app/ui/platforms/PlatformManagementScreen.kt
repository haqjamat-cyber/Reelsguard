package com.reelsguard.app.ui.platforms

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.reelsguard.app.components.GlassCard
import com.reelsguard.app.components.PremiumBackground
import com.reelsguard.app.components.ScreenTopHeader
import com.reelsguard.app.components.iconVector
import com.reelsguard.app.model.BlockMode
import com.reelsguard.app.ui.theme.ReelsGuardTheme

@Composable
fun PlatformManagementScreen(
    viewModel: PlatformManagementViewModel,
    onOpenDailyLimits: () -> Unit,
    onOpenPermissions: () -> Unit,
    contentBottomPadding: PaddingValues = PaddingValues(bottom = 92.dp)
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val extra = ReelsGuardTheme.colors
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshPermissions()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    PremiumBackground {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding(),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = 12.dp,
                bottom = contentBottomPadding.calculateBottomPadding() + 16.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                ScreenTopHeader(
                    title = "Tracked Platforms",
                    subtitle = "Toggle monitoring and video-count blocking per app"
                )
            }

            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(
                            imageVector = Icons.Rounded.Info,
                            contentDescription = null,
                            tint = extra.accentBlue
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Full-Video Counting",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Only completed Reels/Shorts are counted. Videos skipped early are ignored so your target stays accurate.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            items(state.configs, key = { it.platform.name }) { config ->
                val accent = Color(config.platform.accentHex)
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    highlightAccent = if (config.isTrackingEnabled) accent else null
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = config.platform.iconVector(),
                                contentDescription = config.platform.displayName,
                                tint = accent
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = config.platform.shortFormLabel,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (config.isLimitEnabled && config.dailyVideoLimit > 0) {
                                        "Target: ${config.dailyVideoLimit} full videos"
                                    } else {
                                        "No target set"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Switch(
                            checked = config.isTrackingEnabled,
                            onCheckedChange = { enabled ->
                                viewModel.setTrackingEnabled(config.platform, enabled)
                            }
                        )
                    }

                    if (config.isTrackingEnabled) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Restriction Mode",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            BlockMode.entries.forEach { mode ->
                                FilterChip(
                                    selected = config.blockMode == mode,
                                    onClick = { viewModel.setBlockMode(config.platform, mode) },
                                    label = {
                                        Text(
                                            text = if (mode == BlockMode.SECTION_ONLY) "Reels Only" else "Full App Fallback",
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = config.blockMode.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onOpenDailyLimits,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Tune,
                            contentDescription = null
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Set Video Targets")
                    }
                    if (!state.permissions.isAccessibilityEnabled) {
                        OutlinedButton(
                            onClick = onOpenPermissions,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Enable Guard")
                        }
                    }
                }
            }
        }
    }
}
