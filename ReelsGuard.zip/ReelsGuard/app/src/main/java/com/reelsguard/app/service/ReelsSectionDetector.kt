package com.reelsguard.app.service

import android.view.accessibility.AccessibilityNodeInfo
import com.reelsguard.app.model.Platform
import java.util.ArrayDeque

/**
 * Lightweight snapshot extracted from an Accessibility window hierarchy.
 * Decoupled from Android framework types so detection heuristics can be unit tested directly.
 */
data class ScreenSignalSnapshot(
    val packageName: String,
    val className: String = "",
    val viewIds: List<String> = emptyList(),
    val contentDescriptions: List<String> = emptyList(),
    val textSnippets: List<String> = emptyList(),
    val playbackProgressFraction: Float? = null,
    val isVideoPaused: Boolean = false,
    val videoFingerprint: String = ""
)

data class SectionDetectionResult(
    val platform: Platform?,
    val isShortFormSection: Boolean,
    val confidenceScore: Int,
    val matchedSignal: String
)

object ReelsSectionDetector {

    private const val MAX_TRAVERSAL_NODES = 95

    private val genericUiLabels = setOf(
        "like", "dislike", "comment", "comments", "share", "remix", "more", "more options",
        "reels", "shorts", "subscribe", "subscribed", "follow", "following", "home",
        "search", "audio", "mute", "unmute", "pause", "play", "pause video", "play video",
        "pause reel", "play reel", "create", "camera", "add a comment", "send", "save",
        "back", "navigate up", "close", "captions", "cc", "original audio"
    )

    fun detect(snapshot: ScreenSignalSnapshot): SectionDetectionResult {
        val platform = Platform.fromPackageName(snapshot.packageName)
            ?: return SectionDetectionResult(
                platform = null,
                isShortFormSection = false,
                confidenceScore = 0,
                matchedSignal = "Non-monitored package"
            )

        return when (platform) {
            Platform.INSTAGRAM -> detectInstagramReels(snapshot)
            Platform.YOUTUBE -> detectYouTubeShorts(snapshot)
            Platform.FACEBOOK -> detectFacebookReels(snapshot)
        }
    }

    private fun detectInstagramReels(snapshot: ScreenSignalSnapshot): SectionDetectionResult {
        val ids = snapshot.viewIds.map { it.lowercase() }
        val descs = snapshot.contentDescriptions.map { it.lowercase() }
        val texts = snapshot.textSnippets.map { it.lowercase() }
        val cls = snapshot.className.lowercase()

        var score = 0
        val reasons = mutableListOf<String>()

        val strongViewIdSignals = listOf(
            "clips_viewer",
            "clips_video_container",
            "clips_ufi",
            "reel_viewer_root",
            "clips_author_info",
            "clips_media_info",
            "clips_swipe_refresh"
        )
        val matchedId = ids.firstOrNull { id -> strongViewIdSignals.any { id.contains(it) } }
        if (matchedId != null) {
            score += 70
            reasons += "viewId:$matchedId"
        }

        if (cls.contains("clips") || cls.contains("reels")) {
            score += 45
            reasons += "class:$cls"
        }

        val hasReelActionCue = descs.any {
            it.contains("reel") || it.contains("original audio") || it.contains("remix")
        }
        val hasVideoPlaybackCue = descs.any {
            it.contains("like") || it.contains("comment") || it.contains("share")
        } && (texts.any { it == "reels" || it.contains("original audio") } || ids.any { it.contains("clips") })

        if (hasReelActionCue) {
            score += 35
            reasons += "desc:reel_cue"
        }
        if (hasVideoPlaybackCue) {
            score += 35
            reasons += "ui:reels_player_actions"
        }

        val isClearlyNonReels = ids.any {
            it.contains("direct_inbox") || it.contains("direct_thread") || it.contains("message_composer")
        }
        if (isClearlyNonReels && matchedId == null) {
            score = 0
            reasons.clear()
            reasons += "excluded:direct_messages"
        }

        val detected = score >= 60
        return SectionDetectionResult(
            platform = Platform.INSTAGRAM,
            isShortFormSection = detected,
            confidenceScore = score.coerceAtMost(100),
            matchedSignal = reasons.joinToString(", ").ifEmpty { "no_reels_signal" }
        )
    }

    private fun detectYouTubeShorts(snapshot: ScreenSignalSnapshot): SectionDetectionResult {
        val ids = snapshot.viewIds.map { it.lowercase() }
        val descs = snapshot.contentDescriptions.map { it.lowercase() }
        val texts = snapshot.textSnippets.map { it.lowercase() }
        val cls = snapshot.className.lowercase()

        var score = 0
        val reasons = mutableListOf<String>()

        val strongViewIdSignals = listOf(
            "reel_recycler",
            "reel_watch_fragment",
            "reel_player_page",
            "reel_dyn_remix",
            "shorts_player",
            "reel_progress_bar",
            "reel_channel_bar"
        )
        val matchedId = ids.firstOrNull { id -> strongViewIdSignals.any { id.contains(it) } }
        if (matchedId != null) {
            score += 75
            reasons += "viewId:$matchedId"
        }

        if (cls.contains("reelwatch") || cls.contains("shorts")) {
            score += 50
            reasons += "class:$cls"
        }

        val hasShortsRemixOrSound = descs.any {
            it.contains("remix this short") ||
                it.contains("dislike this video") && descs.any { d -> d.contains("shorts") || d.contains("remix") } ||
                it.contains("sound used in this short")
        }
        if (hasShortsRemixOrSound) {
            score += 60
            reasons += "desc:shorts_controls"
        }

        val hasShortsHeaderAndPlayer = texts.any { it == "shorts" } &&
            descs.any { it.contains("remix") || it.contains("pause video") || it.contains("subscribe") } &&
            !ids.any { it.contains("watch_while_time_bar") }
        if (hasShortsHeaderAndPlayer) {
            score += 45
            reasons += "ui:shorts_overlay"
        }

        val isLongFormWatch = ids.any {
            it.contains("watch_while_time_bar") || it.contains("next_gen_watch_layout")
        } && matchedId == null
        if (isLongFormWatch) {
            score = 0
            reasons.clear()
            reasons += "excluded:long_form_watch"
        }

        val detected = score >= 60
        return SectionDetectionResult(
            platform = Platform.YOUTUBE,
            isShortFormSection = detected,
            confidenceScore = score.coerceAtMost(100),
            matchedSignal = reasons.joinToString(", ").ifEmpty { "no_shorts_signal" }
        )
    }

    private fun detectFacebookReels(snapshot: ScreenSignalSnapshot): SectionDetectionResult {
        val ids = snapshot.viewIds.map { it.lowercase() }
        val descs = snapshot.contentDescriptions.map { it.lowercase() }
        val texts = snapshot.textSnippets.map { it.lowercase() }
        val cls = snapshot.className.lowercase()

        var score = 0
        val reasons = mutableListOf<String>()

        val strongViewIdSignals = listOf(
            "fb_shorts",
            "reels_viewer",
            "short_form_video",
            "fb_reels"
        )
        val matchedId = ids.firstOrNull { id -> strongViewIdSignals.any { id.contains(it) } }
        if (matchedId != null) {
            score += 75
            reasons += "viewId:$matchedId"
        }

        if (cls.contains("fbshorts") || cls.contains("reels")) {
            score += 55
            reasons += "class:$cls"
        }

        val hasReelsUiLabels = (texts.any { it == "reels" || it.contains("add a comment") } ||
            descs.any { it.contains("reel") || it.contains("reels") }) &&
            descs.any { it.contains("like") || it.contains("comment") || it.contains("share") }

        if (hasReelsUiLabels) {
            score += 45
            reasons += "ui:fb_reels_overlay"
        }

        val hasDirectReelDesc = descs.any {
            it.contains("create reel") || it.contains("reel audio") || it.contains("pause reel")
        }
        if (hasDirectReelDesc) {
            score += 40
            reasons += "desc:fb_reel_action"
        }

        val detected = score >= 60
        return SectionDetectionResult(
            platform = Platform.FACEBOOK,
            isShortFormSection = detected,
            confidenceScore = score.coerceAtMost(100),
            matchedSignal = reasons.joinToString(", ").ifEmpty { "no_fb_reels_signal" }
        )
    }

    fun extractSnapshot(
        rootNode: AccessibilityNodeInfo?,
        packageName: String,
        eventClassName: String?
    ): ScreenSignalSnapshot {
        if (rootNode == null) {
            return ScreenSignalSnapshot(
                packageName = packageName,
                className = eventClassName.orEmpty()
            )
        }

        val viewIds = ArrayList<String>(36)
        val descriptions = ArrayList<String>(36)
        val texts = ArrayList<String>(28)
        val fingerprintTokens = LinkedHashSet<String>(12)

        var primaryProgressFraction: Float? = null
        var fallbackProgressFraction: Float? = null
        var sawPlayButton = false
        var sawPauseButton = false

        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(rootNode)
        var visited = 0

        while (queue.isNotEmpty() && visited < MAX_TRAVERSAL_NODES) {
            val node = queue.removeFirst()
            visited++

            runCatching {
                val viewId = node.viewIdResourceName?.takeIf { it.isNotBlank() }
                val nodeCls = node.className?.toString().orEmpty()
                val desc = node.contentDescription?.toString()?.takeIf { it.isNotBlank() && it.length <= 72 }
                val txt = node.text?.toString()?.takeIf { it.isNotBlank() && it.length <= 42 }

                if (viewId != null) viewIds.add(viewId)
                if (desc != null) descriptions.add(desc)
                if (txt != null && txt.length <= 28) texts.add(txt)

                // Extract SeekBar / ProgressBar RangeInfo for accurate video completion detection
                val range = node.rangeInfo
                if (range != null && range.max > range.min) {
                    val fraction = ((range.current - range.min) / (range.max - range.min)).coerceIn(0f, 1f)
                    val lowerId = viewId?.lowercase().orEmpty()
                    val lowerCls = nodeCls.lowercase()
                    val isVideoSeekBar = lowerId.contains("progress") ||
                        lowerId.contains("seek") ||
                        lowerId.contains("scrubber") ||
                        lowerId.contains("time_bar") ||
                        lowerCls.contains("seekbar") ||
                        lowerCls.contains("progressbar")
                    if (isVideoSeekBar) {
                        primaryProgressFraction = fraction
                    } else if (fallbackProgressFraction == null) {
                        fallbackProgressFraction = fraction
                    }
                }

                // Detect paused playback state so paused time does not count toward full video watch
                if (desc != null) {
                    val lowerDesc = desc.lowercase().trim()
                    if (lowerDesc == "play video" || lowerDesc == "play reel" ||
                        lowerDesc == "play" || lowerDesc == "resume video" || lowerDesc == "resume"
                    ) {
                        sawPlayButton = true
                    }
                    if (lowerDesc == "pause video" || lowerDesc == "pause reel" || lowerDesc == "pause") {
                        sawPauseButton = true
                    }
                }

                // Collect stable per-video identity tokens (creator handle, channel, audio label)
                val lowerId = viewId?.lowercase().orEmpty()
                val isIdentityNode = lowerId.contains("author") ||
                    lowerId.contains("channel") ||
                    lowerId.contains("username") ||
                    lowerId.contains("title") ||
                    lowerId.contains("audio") ||
                    lowerId.contains("music") ||
                    lowerId.contains("caption")

                if (isIdentityNode && txt != null) {
                    normalizeIdentityToken(txt)?.let { fingerprintTokens.add(it) }
                } else if (txt != null && txt.startsWith("@") && txt.length >= 3) {
                    normalizeIdentityToken(txt)?.let { fingerprintTokens.add(it) }
                } else if (desc != null) {
                    val lowerDesc = desc.lowercase()
                    if (lowerDesc.contains("sound used in this short") ||
                        lowerDesc.contains("original audio") ||
                        lowerDesc.contains("subscribe to") ||
                        lowerDesc.contains("go to channel")
                    ) {
                        normalizeIdentityToken(desc)?.let { fingerprintTokens.add(it) }
                    }
                }

                val childCount = node.childCount
                for (i in 0 until childCount) {
                    if (visited + queue.size >= MAX_TRAVERSAL_NODES) break
                    val child = node.getChild(i)
                    if (child != null) {
                        queue.addLast(child)
                    }
                }
            }

            if (node !== rootNode) {
                @Suppress("DEPRECATION")
                runCatching { node.recycle() }
            }
        }

        while (queue.isNotEmpty()) {
            val leftover = queue.removeFirst()
            if (leftover !== rootNode) {
                @Suppress("DEPRECATION")
                runCatching { leftover.recycle() }
            }
        }

        val fingerprint = if (fingerprintTokens.isEmpty()) {
            ""
        } else {
            fingerprintTokens.sorted().take(4).joinToString("|").hashCode().toString(16)
        }

        return ScreenSignalSnapshot(
            packageName = packageName,
            className = eventClassName.orEmpty(),
            viewIds = viewIds,
            contentDescriptions = descriptions,
            textSnippets = texts,
            playbackProgressFraction = primaryProgressFraction ?: fallbackProgressFraction,
            isVideoPaused = sawPlayButton && !sawPauseButton,
            videoFingerprint = fingerprint
        )
    }

    private fun normalizeIdentityToken(raw: String): String? {
        val cleaned = raw.trim().lowercase().replace(Regex("\s+"), " ")
        if (cleaned.length < 3 || cleaned in genericUiLabels) return null
        // Exclude pure numbers / compact counts like "12.4k", "0:14", "1,203"
        if (cleaned.matches(Regex("^[0-9.,:kmb%\s]+$"))) return null
        return cleaned.take(36)
    }
}
