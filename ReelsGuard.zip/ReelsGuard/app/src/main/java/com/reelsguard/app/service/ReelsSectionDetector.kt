package com.reelsguard.app.service

import android.view.accessibility.AccessibilityNodeInfo
import com.reelsguard.app.model.Platform
import java.util.ArrayDeque

/**
 * Lightweight snapshot extracted from an Accessibility window hierarchy.
 * Decoupled from Android framework types so detection heuristics can be unit tested directly.
 */
data class ScreenSignalSnapshot(
    val packageName: String,
    val className: String = "",
    val viewIds: List<String> = emptyList(),
    val contentDescriptions: List<String> = emptyList(),
    val textSnippets: List<String> = emptyList()
)

data class SectionDetectionResult(
    val platform: Platform?,
    val isShortFormSection: Boolean,
    val confidenceScore: Int,
    val matchedSignal: String
)

/**
 * Cautious, multi-signal heuristic detector for Instagram Reels, YouTube Shorts, and Facebook Reels.
 *
 * IMPORTANT ANDROID LIMITATION:
 * Third-party apps (Instagram, YouTube, Facebook) frequently obfuscate or update their internal
 * view resource IDs and layouts. Therefore, this detector:
 * 1. Never relies on a single brittle resource ID.
 * 2. Combines multiple UI signals (view ID substrings, accessibility content descriptions, class names).
 * 3. Defaults to `isShortFormSection = false` when uncertain, avoiding false positives on regular feeds
 *    or DMs. Users can enable Full-App Fallback mode per platform if a future app update alters layouts.
 */
object ReelsSectionDetector {

    private const val MAX_TRAVERSAL_NODES = 85

    fun detect(snapshot: ScreenSignalSnapshot): SectionDetectionResult {
        val platform = Platform.fromPackageName(snapshot.packageName)
            ?: return SectionDetectionResult(
                platform = null,
                isShortFormSection = false,
                confidenceScore = 0,
                matchedSignal = "Non-monitored package"
            )

        return when (platform) {
            Platform.INSTAGRAM -> detectInstagramReels(snapshot)
            Platform.YOUTUBE -> detectYouTubeShorts(snapshot)
            Platform.FACEBOOK -> detectFacebookReels(snapshot)
        }
    }

    private fun detectInstagramReels(snapshot: ScreenSignalSnapshot): SectionDetectionResult {
        val ids = snapshot.viewIds.map { it.lowercase() }
        val descs = snapshot.contentDescriptions.map { it.lowercase() }
        val texts = snapshot.textSnippets.map { it.lowercase() }
        val cls = snapshot.className.lowercase()

        var score = 0
        val reasons = mutableListOf<String>()

        val strongViewIdSignals = listOf(
            "clips_viewer",
            "clips_video_container",
            "clips_ufi",
            "reel_viewer_root",
            "clips_author_info",
            "clips_media_info",
            "clips_swipe_refresh"
        )
        val matchedId = ids.firstOrNull { id -> strongViewIdSignals.any { id.contains(it) } }
        if (matchedId != null) {
            score += 70
            reasons += "viewId:$matchedId"
        }

        if (cls.contains("clips") || cls.contains("reels")) {
            score += 45
            reasons += "class:$cls"
        }

        val hasReelActionCue = descs.any {
            it.contains("reel") || it.contains("original audio") || it.contains("remix")
        }
        val hasVideoPlaybackCue = descs.any {
            it.contains("like") || it.contains("comment") || it.contains("share")
        } && (texts.any { it == "reels" || it.contains("original audio") } || ids.any { it.contains("clips") })

        if (hasReelActionCue) {
            score += 35
            reasons += "desc:reel_cue"
        }
        if (hasVideoPlaybackCue) {
            score += 35
            reasons += "ui:reels_player_actions"
        }

        // Guard against false positive when user is simply in Direct Messages or Search tab
        val isClearlyNonReels = ids.any {
            it.contains("direct_inbox") || it.contains("direct_thread") || it.contains("message_composer")
        }
        if (isClearlyNonReels && matchedId == null) {
            score = 0
            reasons.clear()
            reasons += "excluded:direct_messages"
        }

        val detected = score >= 60
        return SectionDetectionResult(
            platform = Platform.INSTAGRAM,
            isShortFormSection = detected,
            confidenceScore = score.coerceAtMost(100),
            matchedSignal = reasons.joinToString(", ").ifEmpty { "no_reels_signal" }
        )
    }

    private fun detectYouTubeShorts(snapshot: ScreenSignalSnapshot): SectionDetectionResult {
        val ids = snapshot.viewIds.map { it.lowercase() }
        val descs = snapshot.contentDescriptions.map { it.lowercase() }
        val texts = snapshot.textSnippets.map { it.lowercase() }
        val cls = snapshot.className.lowercase()

        var score = 0
        val reasons = mutableListOf<String>()

        val strongViewIdSignals = listOf(
            "reel_recycler",
            "reel_watch_fragment",
            "reel_player_page",
            "reel_dyn_remix",
            "shorts_player",
            "reel_progress_bar",
            "reel_channel_bar"
        )
        val matchedId = ids.firstOrNull { id -> strongViewIdSignals.any { id.contains(it) } }
        if (matchedId != null) {
            score += 75
            reasons += "viewId:$matchedId"
        }

        if (cls.contains("reelwatch") || cls.contains("shorts")) {
            score += 50
            reasons += "class:$cls"
        }

        val hasShortsRemixOrSound = descs.any {
            it.contains("remix this short") ||
                it.contains("dislike this video") && descs.any { d -> d.contains("shorts") || d.contains("remix") } ||
                it.contains("sound used in this short")
        }
        if (hasShortsRemixOrSound) {
            score += 60
            reasons += "desc:shorts_controls"
        }

        val hasShortsHeaderAndPlayer = texts.any { it == "shorts" } &&
            descs.any { it.contains("remix") || it.contains("pause video") || it.contains("subscribe") } &&
            !ids.any { it.contains("watch_while_time_bar") }
        if (hasShortsHeaderAndPlayer) {
            score += 45
            reasons += "ui:shorts_overlay"
        }

        // Guard against standard long-form YouTube watch page
        val isLongFormWatch = ids.any {
            it.contains("watch_while_time_bar") || it.contains("next_gen_watch_layout")
        } && matchedId == null
        if (isLongFormWatch) {
            score = 0
            reasons.clear()
            reasons += "excluded:long_form_watch"
        }

        val detected = score >= 60
        return SectionDetectionResult(
            platform = Platform.YOUTUBE,
            isShortFormSection = detected,
            confidenceScore = score.coerceAtMost(100),
            matchedSignal = reasons.joinToString(", ").ifEmpty { "no_shorts_signal" }
        )
    }

    private fun detectFacebookReels(snapshot: ScreenSignalSnapshot): SectionDetectionResult {
        val ids = snapshot.viewIds.map { it.lowercase() }
        val descs = snapshot.contentDescriptions.map { it.lowercase() }
        val texts = snapshot.textSnippets.map { it.lowercase() }
        val cls = snapshot.className.lowercase()

        var score = 0
        val reasons = mutableListOf<String>()

        val strongViewIdSignals = listOf(
            "fb_shorts",
            "reels_viewer",
            "short_form_video",
            "fb_reels"
        )
        val matchedId = ids.firstOrNull { id -> strongViewIdSignals.any { id.contains(it) } }
        if (matchedId != null) {
            score += 75
            reasons += "viewId:$matchedId"
        }

        if (cls.contains("fbshorts") || cls.contains("reels")) {
            score += 55
            reasons += "class:$cls"
        }

        val hasReelsUiLabels = (texts.any { it == "reels" || it.contains("add a comment") } ||
            descs.any { it.contains("reel") || it.contains("reels") }) &&
            descs.any { it.contains("like") || it.contains("comment") || it.contains("share") }

        if (hasReelsUiLabels) {
            score += 45
            reasons += "ui:fb_reels_overlay"
        }

        val hasDirectReelDesc = descs.any {
            it.contains("create reel") || it.contains("reel audio") || it.contains("pause reel")
        }
        if (hasDirectReelDesc) {
            score += 40
            reasons += "desc:fb_reel_action"
        }

        val detected = score >= 60
        return SectionDetectionResult(
            platform = Platform.FACEBOOK,
            isShortFormSection = detected,
            confidenceScore = score.coerceAtMost(100),
            matchedSignal = reasons.joinToString(", ").ifEmpty { "no_fb_reels_signal" }
        )
    }

    /**
     * Safely traverses a bounded subset of the active window's AccessibilityNodeInfo tree
     * without storing any user-typed content or personal messages.
     */
    fun extractSnapshot(
        rootNode: AccessibilityNodeInfo?,
        packageName: String,
        eventClassName: String?
    ): ScreenSignalSnapshot {
        if (rootNode == null) {
            return ScreenSignalSnapshot(
                packageName = packageName,
                className = eventClassName.orEmpty()
            )
        }

        val viewIds = ArrayList<String>(32)
        val descriptions = ArrayList<String>(32)
        val texts = ArrayList<String>(24)

        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(rootNode)
        var visited = 0

        while (queue.isNotEmpty() && visited < MAX_TRAVERSAL_NODES) {
            val node = queue.removeFirst()
            visited++

            runCatching {
                node.viewIdResourceName?.takeIf { it.isNotBlank() }?.let { viewIds.add(it) }
                node.contentDescription?.toString()?.takeIf { it.isNotBlank() && it.length <= 64 }
                    ?.let { descriptions.add(it) }
                // Only inspect short structural labels (e.g., tab/header labels <= 28 chars), never long user text
                node.text?.toString()?.takeIf { it.isNotBlank() && it.length <= 28 }
                    ?.let { texts.add(it) }

                val childCount = node.childCount
                for (i in 0 until childCount) {
                    if (visited + queue.size >= MAX_TRAVERSAL_NODES) break
                    val child = node.getChild(i)
                    if (child != null) {
                        queue.addLast(child)
                    }
                }
            }

            if (node !== rootNode) {
                @Suppress("DEPRECATION")
                runCatching { node.recycle() }
            }
        }

        while (queue.isNotEmpty()) {
            val leftover = queue.removeFirst()
            if (leftover !== rootNode) {
                @Suppress("DEPRECATION")
                runCatching { leftover.recycle() }
            }
        }

        return ScreenSignalSnapshot(
            packageName = packageName,
            className = eventClassName.orEmpty(),
            viewIds = viewIds,
            contentDescriptions = descriptions,
            textSnippets = texts
        )
    }
}
