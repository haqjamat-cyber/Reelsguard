package com.reelsguard.app.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.SmartDisplay
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.reelsguard.app.model.Platform
import com.reelsguard.app.model.PlatformUsageSummary
import com.reelsguard.app.model.TrackingConfidence
import com.reelsguard.app.ui.theme.ReelsGuardTheme
import com.reelsguard.app.utils.TimeFormatter

fun Platform.iconVector(): ImageVector = when (this) {
    Platform.INSTAGRAM -> Icons.Rounded.VideoLibrary
    Platform.YOUTUBE -> Icons.Rounded.SmartDisplay
    Platform.FACEBOOK -> Icons.Rounded.PlayCircle
}

@Composable
fun PlatformUsageCard(
    summary: PlatformUsageSummary,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val extra = ReelsGuardTheme.colors
    val accent = Color(summary.platform.accentHex)
    val secondary = Color(summary.platform.secondaryAccentHex)
    val animatedBar by animateFloatAsState(
        targetValue = summary.progressFraction,
        animationSpec = tween(600),
        label = "platform_bar_${summary.platform.name}"
    )

    val unitWord = if (summary.platform == Platform.YOUTUBE) {
        if (summary.watchedReelsCount == 1) "Short" else "Shorts"
    } else {
        if (summary.watchedReelsCount == 1) "Reel" else "Reels"
    }
    val watchedSuffix = if (summary.watchedReelsCount > 0) {
        " • ${summary.watchedReelsCount} $unitWord"
    } else {
        ""
    }

    GlassCard(
        modifier = modifier.fillMaxWidth(),
        highlightAccent = if (summary.isCurrentlyBlocked) extra.danger else null,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Brush.linearGradient(listOf(accent.copy(alpha = 0.25f), secondary.copy(alpha = 0.18f)))),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = summary.platform.iconVector(),
                    contentDescription = summary.platform.displayName,
                    tint = accent,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = summary.platform.shortFormLabel,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (summary.isCurrentlyBlocked) {
                        StatusPill(
                            text = "Blocked",
                            tint = extra.danger,
                            icon = Icons.Rounded.Block
                        )
                    } else if (!summary.isTrackingEnabled) {
                        StatusPill(text = "Paused", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = when (summary.activeConfidence) {
                        TrackingConfidence.VERIFIED_SECTION ->
                            "Limit ${TimeFormatter.formatMinutesReadable(summary.dailyLimitMinutes)}$watchedSuffix"
                        TrackingConfidence.APP_WIDE_FALLBACK ->
                            "Full-App Fallback • Limit ${TimeFormatter.formatMinutesReadable(summary.dailyLimitMinutes)}$watchedSuffix"
                        TrackingConfidence.UNTRACKED ->
                            if (summary.isTrackingEnabled) "Awaiting permission or activity" else "Tracking disabled"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = TimeFormatter.formatDurationCompact(summary.effectiveSecondsForLimit),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (summary.isCurrentlyBlocked) extra.danger else MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = if (summary.isLimitEnabled) {
                        TimeFormatter.formatRemainingLabel(summary.remainingSeconds)
                    } else {
                        "Limit off"
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = if (summary.isCurrentlyBlocked) extra.danger else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(7.dp)
                .clip(CircleShape)
                .background(extra.subtleTrack)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(animatedBar.coerceIn(0f, 1f))
                    .height(7.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.horizontalGradient(
                            if (summary.isCurrentlyBlocked) listOf(extra.danger, extra.warning)
                            else listOf(accent, secondary)
                        )
                    )
            )
        }
    }
}
