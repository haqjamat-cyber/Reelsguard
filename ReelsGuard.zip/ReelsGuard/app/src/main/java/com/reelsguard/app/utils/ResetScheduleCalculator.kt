package com.reelsguard.app.utils

import java.time.Duration
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Pure date/time calculator for ReelsGuard's configurable daily reset cycle.
 *
 * Example: If the user sets daily reset at 04:00 AM, then 02:30 AM on Nov 25 still belongs to
 * the "2026-11-24" usage cycle until 04:00 AM arrives. Properly respects timezone & DST transitions.
 */
object ResetScheduleCalculator {

    private val dateKeyFormatter: DateTimeFormatter = DateTimeFormatter.ISO_LOCAL_DATE
    private val displayTimeFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern("h:mm a", Locale.getDefault())
    private val shortDayFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern("EEE", Locale.getDefault())
    private val displayDateFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.getDefault())

    /**
     * Returns the logical cycle date key (YYYY-MM-DD) for [now] given the user's reset time.
     */
    fun getCurrentCycleDateKey(
        now: ZonedDateTime = ZonedDateTime.now(),
        resetHour: Int = 0,
        resetMinute: Int = 0
    ): String {
        val safeHour = resetHour.coerceIn(0, 23)
        val safeMinute = resetMinute.coerceIn(0, 59)
        val resetTime = LocalTime.of(safeHour, safeMinute)
        val cycleDate = if (now.toLocalTime().isBefore(resetTime)) {
            now.toLocalDate().minusDays(1)
        } else {
            now.toLocalDate()
        }
        return cycleDate.format(dateKeyFormatter)
    }

    /**
     * Returns the exact start instant (epoch millis) of the current logical usage cycle.
     */
    fun getCurrentCycleStart(
        now: ZonedDateTime = ZonedDateTime.now(),
        resetHour: Int = 0,
        resetMinute: Int = 0
    ): ZonedDateTime {
        val safeHour = resetHour.coerceIn(0, 23)
        val safeMinute = resetMinute.coerceIn(0, 59)
        val resetTime = LocalTime.of(safeHour, safeMinute)
        val cycleDate = if (now.toLocalTime().isBefore(resetTime)) {
            now.toLocalDate().minusDays(1)
        } else {
            now.toLocalDate()
        }
        return ZonedDateTime.of(cycleDate, resetTime, now.zone)
    }

    /**
     * Returns the next upcoming daily reset timestamp strictly after [now].
     */
    fun getNextResetDateTime(
        now: ZonedDateTime = ZonedDateTime.now(),
        resetHour: Int = 0,
        resetMinute: Int = 0
    ): ZonedDateTime {
        val safeHour = resetHour.coerceIn(0, 23)
        val safeMinute = resetMinute.coerceIn(0, 59)
        val resetTime = LocalTime.of(safeHour, safeMinute)
        val todayReset = ZonedDateTime.of(now.toLocalDate(), resetTime, now.zone)
        return if (now.isBefore(todayReset)) {
            todayReset
        } else {
            ZonedDateTime.of(now.toLocalDate().plusDays(1), resetTime, now.zone)
        }
    }

    /**
     * Delay in milliseconds until the next daily reset (minimum 1 second to avoid zero-delay loops).
     */
    fun millisUntilNextReset(
        now: ZonedDateTime = ZonedDateTime.now(),
        resetHour: Int = 0,
        resetMinute: Int = 0
    ): Long {
        val nextReset = getNextResetDateTime(now, resetHour, resetMinute)
        return Duration.between(now, nextReset).toMillis().coerceAtLeast(1_000L)
    }

    fun formatResetTime(resetHour: Int, resetMinute: Int): String {
        val safeTime = LocalTime.of(resetHour.coerceIn(0, 23), resetMinute.coerceIn(0, 59))
        return safeTime.format(displayTimeFormatter)
    }

    fun formatDateKeyShortDay(dateKey: String): String {
        return runCatching {
            LocalDate.parse(dateKey, dateKeyFormatter).format(shortDayFormatter)
        }.getOrDefault(dateKey.takeLast(2))
    }

    fun formatDateKeyReadable(dateKey: String): String {
        return runCatching {
            LocalDate.parse(dateKey, dateKeyFormatter).format(displayDateFormatter)
        }.getOrDefault(dateKey)
    }

    fun recentDateKeys(
        days: Int,
        now: ZonedDateTime = ZonedDateTime.now(),
        resetHour: Int = 0,
        resetMinute: Int = 0
    ): List<String> {
        val currentKey = getCurrentCycleDateKey(now, resetHour, resetMinute)
        val today = LocalDate.parse(currentKey, dateKeyFormatter)
        return (days - 1 downTo 0).map { offset ->
            today.minusDays(offset.toLong()).format(dateKeyFormatter)
        }
    }

    fun currentTimezoneId(): String = ZoneId.systemDefault().id
}
