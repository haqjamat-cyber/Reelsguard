package com.reelsguard.app.settings

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PlayCircleOutline
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.reelsguard.app.components.GlassCard
import com.reelsguard.app.components.PremiumBackground
import com.reelsguard.app.components.ScreenTopHeader
import com.reelsguard.app.model.BlockMode
import com.reelsguard.app.model.Platform
import com.reelsguard.app.model.ThemeMode
import com.reelsguard.app.ui.blocking.BlockingActivity
import com.reelsguard.app.ui.theme.ReelsGuardTheme

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onOpenPermissions: () -> Unit,
    onOpenDailyLimits: () -> Unit,
    onOpenAbout: () -> Unit,
    contentBottomPadding: PaddingValues = PaddingValues(bottom = 92.dp)
) {
    val prefs by viewModel.preferences.collectAsStateWithLifecycle()
    val extra = ReelsGuardTheme.colors
    val context = LocalContext.current

    var showClearConfirm by remember { mutableStateOf(false) }

    // Starts BLANK when no target is saved; displays saved target once user types & saves one
    var videoTargetInput by remember { mutableStateOf("") }
    var feedbackMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(prefs.totalDailyVideoLimit, prefs.isTotalDailyLimitEnabled) {
        videoTargetInput = if (prefs.isTotalDailyLimitEnabled && prefs.totalDailyVideoLimit > 0) {
            prefs.totalDailyVideoLimit.toString()
        } else {
            ""
        }
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text("Clear Local Usage History?") },
            text = {
                Text("This permanently deletes local daily logs, blocking records, and unlocked badge progress from this device. Your configured video targets remain intact.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearAllLocalData()
                        showClearConfirm = false
                    }
                ) {
                    Text("Clear Data")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    PremiumBackground {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding(),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = 12.dp,
                bottom = contentBottomPadding.calculateBottomPadding() + 16.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                ScreenTopHeader(
                    title = "Settings",
                    subtitle = "Video count targets, appearance & local controls"
                )
            }

            // Daily Video Count Target (User-typed, NO pre-filled number, NO time picker)
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    highlightAccent = if (prefs.isTotalDailyLimitEnabled && prefs.totalDailyVideoLimit > 0) {
                        extra.accentPurple
                    } else {
                        null
                    }
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.PlayCircleOutline,
                            contentDescription = null,
                            tint = extra.accentPurple
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Daily Video Count Target",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (prefs.isTotalDailyLimitEnabled && prefs.totalDailyVideoLimit > 0) {
                                    "Blocks Reels & Shorts after ${prefs.totalDailyVideoLimit} full videos"
                                } else {
                                    "No target set — type how many full videos before blocking"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = videoTargetInput,
                        onValueChange = { raw ->
                            val digitsOnly = raw.filter { it.isDigit() }.take(4)
                            videoTargetInput = digitsOnly
                            feedbackMessage = null
                        },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        label = { Text("Video target (Reels / Shorts)") },
                        placeholder = { Text("Type number of videos") }
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                val parsed = videoTargetInput.toIntOrNull() ?: 0
                                if (parsed > 0) {
                                    viewModel.setTotalDailyVideoLimit(parsed, enabled = true)
                                    feedbackMessage = "Target saved: $parsed full videos"
                                } else {
                                    feedbackMessage = "Please type a valid video count (1 or more)"
                                }
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Save Target")
                        }
                        if (prefs.isTotalDailyLimitEnabled && prefs.totalDailyVideoLimit > 0) {
                            OutlinedButton(
                                onClick = {
                                    videoTargetInput = ""
                                    viewModel.setTotalDailyVideoLimit(0, enabled = false)
                                    feedbackMessage = "Target cleared"
                                },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Clear")
                            }
                        }
                    }

                    if (feedbackMessage != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = feedbackMessage.orEmpty(),
                            style = MaterialTheme.typography.labelSmall,
                            color = extra.success
                        )
                    }
                }
            }

            // Theme selector
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Palette,
                            contentDescription = null,
                            tint = extra.accentPurple
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Appearance",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ThemeMode.entries.forEach { mode ->
                            FilterChip(
                                selected = prefs.themeMode == mode,
                                onClick = { viewModel.setThemeMode(mode) },
                                label = {
                                    Text(
                                        text = when (mode) {
                                            ThemeMode.DARK -> "Dark"
                                            ThemeMode.LIGHT -> "Light"
                                            ThemeMode.SYSTEM -> "System"
                                        }
                                    )
                                }
                            )
                        }
                    }
                }
            }

            // Tracking, Dynamic Island & Notification switches
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Dynamic Island Reel Counter",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Show live completed video count at the top while using Instagram, YouTube, or Facebook.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Switch(
                            checked = prefs.showDynamicIslandCounter,
                            onCheckedChange = { viewModel.setShowDynamicIslandCounter(it) }
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Full-App Fallback Tracking",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Use UsageStatsManager for whole-app activity stats when section detection is unavailable.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Switch(
                            checked = prefs.allowFullAppFallbackTracking,
                            onCheckedChange = { viewModel.setAllowFullAppFallback(it) }
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Mindful Notifications",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Gentle milestone and daily reset reminders.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Switch(
                            checked = prefs.notificationsEnabled,
                            onCheckedChange = { viewModel.setNotificationsEnabled(it) }
                        )
                    }
                }
            }

            item {
                SettingsNavigationRow(
                    icon = Icons.Rounded.Tune,
                    title = "Per-App Video Targets",
                    subtitle = "Type custom video counts for Instagram, YouTube & Facebook",
                    onClick = onOpenDailyLimits
                )
            }

            item {
                SettingsNavigationRow(
                    icon = Icons.Rounded.Security,
                    title = "Permissions & System Guard",
                    subtitle = "Manage Accessibility, Usage Access & Overlay",
                    onClick = onOpenPermissions
                )
            }

            item {
                SettingsNavigationRow(
                    icon = Icons.Rounded.Shield,
                    title = "Preview Blocking Screen",
                    subtitle = "Inspect the calm pause interface shown when video target is reached",
                    onClick = {
                        val target = prefs.totalDailyVideoLimit.takeIf { it > 0 } ?: 10
                        val previewIntent = Intent(context, BlockingActivity::class.java).apply {
                            putExtra(BlockingActivity.EXTRA_PLATFORM, Platform.INSTAGRAM.name)
                            putExtra(BlockingActivity.EXTRA_WATCHED_VIDEOS, target)
                            putExtra(BlockingActivity.EXTRA_LIMIT_VIDEOS, target)
                            putExtra(BlockingActivity.EXTRA_BLOCK_MODE, BlockMode.SECTION_ONLY.name)
                            putExtra(
                                BlockingActivity.EXTRA_REASON,
                                "Preview mode — this is how ReelsGuard pauses short-form feeds after reaching your video count target."
                            )
                            putExtra(BlockingActivity.EXTRA_IS_PREVIEW, true)
                        }
                        context.startActivity(previewIntent)
                    }
                )
            }

            item {
                SettingsNavigationRow(
                    icon = Icons.Rounded.Info,
                    title = "About ReelsGuard",
                    subtitle = "Privacy architecture, Android limitations & version",
                    onClick = onOpenAbout
                )
            }

            item {
                SettingsNavigationRow(
                    icon = Icons.Rounded.DeleteForever,
                    title = "Clear Local History",
                    subtitle = "Delete stored daily logs and reset badges",
                    isDestructive = true,
                    onClick = { showClearConfirm = true }
                )
            }
        }
    }
}

@Composable
private fun SettingsNavigationRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    isDestructive: Boolean = false,
    onClick: () -> Unit
) {
    val extra = ReelsGuardTheme.colors
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        highlightAccent = if (isDestructive) extra.danger else null,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isDestructive) extra.danger else extra.accentBlue
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        color = if (isDestructive) extra.danger else MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Icon(
                imageVector = Icons.Rounded.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
