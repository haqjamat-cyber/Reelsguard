package com.reelsguard.app.settings

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessTime
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.reelsguard.app.components.GlassCard
import com.reelsguard.app.components.PremiumBackground
import com.reelsguard.app.components.ScreenTopHeader
import com.reelsguard.app.model.BlockMode
import com.reelsguard.app.model.Platform
import com.reelsguard.app.model.ThemeMode
import com.reelsguard.app.ui.blocking.BlockingActivity
import com.reelsguard.app.ui.theme.ReelsGuardTheme
import com.reelsguard.app.utils.ResetScheduleCalculator

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onOpenPermissions: () -> Unit,
    onOpenDailyLimits: () -> Unit,
    onOpenAbout: () -> Unit,
    contentBottomPadding: PaddingValues = PaddingValues(bottom = 92.dp)
) {
    val prefs by viewModel.preferences.collectAsStateWithLifecycle()
    val extra = ReelsGuardTheme.colors
    val context = LocalContext.current

    var showTimePicker by remember { mutableStateOf(false) }
    var showClearConfirm by remember { mutableStateOf(false) }

    if (showTimePicker) {
        val pickerState = rememberTimePickerState(
            initialHour = prefs.resetHour,
            initialMinute = prefs.resetMinute,
            is24Hour = false
        )
        AlertDialog(
            onDismissRequest = { showTimePicker = false },
            title = { Text("Custom Daily Reset Time") },
            text = { TimePicker(state = pickerState) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.setResetTime(pickerState.hour, pickerState.minute)
                        showTimePicker = false
                    }
                ) {
                    Text("Save Reset Time")
                }
            },
            dismissButton = {
                TextButton(onClick = { showTimePicker = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text("Clear Local Usage History?") },
            text = {
                Text("This permanently deletes local daily logs, blocking records, and unlocked badge progress from this device. Your configured daily limits remain intact.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearAllLocalData()
                        showClearConfirm = false
                    }
                ) {
                    Text("Clear Data")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    PremiumBackground {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding(),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = 12.dp,
                bottom = contentBottomPadding.calculateBottomPadding() + 16.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                ScreenTopHeader(
                    title = "Settings",
                    subtitle = "Appearance, reset schedule & local controls"
                )
            }

            // Theme selector
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Palette,
                            contentDescription = null,
                            tint = extra.accentPurple
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Appearance",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ThemeMode.entries.forEach { mode ->
                            FilterChip(
                                selected = prefs.themeMode == mode,
                                onClick = { viewModel.setThemeMode(mode) },
                                label = {
                                    Text(
                                        text = when (mode) {
                                            ThemeMode.DARK -> "Dark"
                                            ThemeMode.LIGHT -> "Light"
                                            ThemeMode.SYSTEM -> "System"
                                        }
                                    )
                                }
                            )
                        }
                    }
                }
            }

            // Daily Reset Schedule
            item {
                val isMidnight = prefs.resetHour == 0 && prefs.resetMinute == 0
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.AccessTime,
                            contentDescription = null,
                            tint = extra.accentBlue
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Daily Reset Schedule",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Resets at ${ResetScheduleCalculator.formatResetTime(prefs.resetHour, prefs.resetMinute)} (${ResetScheduleCalculator.currentTimezoneId()})",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = isMidnight,
                            onClick = { viewModel.setResetTime(0, 0) },
                            label = { Text("Midnight (12:00 AM)") }
                        )
                        FilterChip(
                            selected = !isMidnight,
                            onClick = { showTimePicker = true },
                            label = { Text("Custom Time") }
                        )
                    }
                }
            }

            // Tracking & Notification switches
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Full-App Fallback Tracking",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Use UsageStatsManager when Reels-only section detection is unavailable. Always labeled transparently.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Switch(
                            checked = prefs.allowFullAppFallbackTracking,
                            onCheckedChange = { viewModel.setAllowFullAppFallback(it) }
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Mindful Notifications",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Gentle milestone and daily reset reminders.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Switch(
                            checked = prefs.notificationsEnabled,
                            onCheckedChange = { viewModel.setNotificationsEnabled(it) }
                        )
                    }
                }
            }

            // Navigation items
            item {
                SettingsNavigationRow(
                    icon = Icons.Rounded.Tune,
                    title = "Daily Limits",
                    subtitle = "Edit individual & combined daily limits",
                    onClick = onOpenDailyLimits
                )
            }

            item {
                SettingsNavigationRow(
                    icon = Icons.Rounded.Security,
                    title = "Permissions & System Guard",
                    subtitle = "Manage Accessibility, Usage Access & Overlay",
                    onClick = onOpenPermissions
                )
            }

            item {
                SettingsNavigationRow(
                    icon = Icons.Rounded.Shield,
                    title = "Preview Blocking Screen",
                    subtitle = "Inspect the calm pause interface shown at limits",
                    onClick = {
                        val previewIntent = Intent(context, BlockingActivity::class.java).apply {
                            putExtra(BlockingActivity.EXTRA_PLATFORM, Platform.INSTAGRAM.name)
                            putExtra(BlockingActivity.EXTRA_USED_SECONDS, 20L * 60L)
                            putExtra(BlockingActivity.EXTRA_LIMIT_MINUTES, 20)
                            putExtra(BlockingActivity.EXTRA_BLOCK_MODE, BlockMode.SECTION_ONLY.name)
                            putExtra(
                                BlockingActivity.EXTRA_REASON,
                                "Preview mode — this is how ReelsGuard gently pauses short-form feeds when your limit is reached."
                            )
                            putExtra(BlockingActivity.EXTRA_IS_PREVIEW, true)
                        }
                        context.startActivity(previewIntent)
                    }
                )
            }

            item {
                SettingsNavigationRow(
                    icon = Icons.Rounded.Info,
                    title = "About ReelsGuard",
                    subtitle = "Privacy architecture, Android limitations & version",
                    onClick = onOpenAbout
                )
            }

            item {
                SettingsNavigationRow(
                    icon = Icons.Rounded.DeleteForever,
                    title = "Clear Local History",
                    subtitle = "Delete stored daily logs and reset badges",
                    isDestructive = true,
                    onClick = { showClearConfirm = true }
                )
            }
        }
    }
}

@Composable
private fun SettingsNavigationRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    isDestructive: Boolean = false,
    onClick: () -> Unit
) {
    val extra = ReelsGuardTheme.colors
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        highlightAccent = if (isDestructive) extra.danger else null,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isDestructive) extra.danger else extra.accentBlue
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        color = if (isDestructive) extra.danger else MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Icon(
                imageVector = Icons.Rounded.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
