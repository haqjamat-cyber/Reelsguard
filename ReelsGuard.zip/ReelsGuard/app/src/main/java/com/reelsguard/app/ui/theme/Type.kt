package com.reelsguard.app.ui.theme

import android.content.Context
import android.graphics.Typeface
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private const val POPPINS_DIR = "fonts"
private const val POPPINS_REGULAR = "fonts/Poppins-Regular.ttf"
private const val POPPINS_MEDIUM = "fonts/Poppins-Medium.ttf"
private const val POPPINS_SEMIBOLD = "fonts/Poppins-SemiBold.ttf"
private const val POPPINS_BOLD = "fonts/Poppins-Bold.ttf"

fun loadPoppinsFontFamily(context: Context): FontFamily {
    val assetManager = context.assets
    val available = runCatching { assetManager.list(POPPINS_DIR)?.toSet().orEmpty() }
        .getOrDefault(emptySet())

    if ("Poppins-Regular.ttf" !in available) {
        return FontFamily.SansSerif
    }

    return runCatching {
        val fonts = buildList {
            add(Font(POPPINS_REGULAR, assetManager, FontWeight.Normal))
            if ("Poppins-Medium.ttf" in available) {
                add(Font(POPPINS_MEDIUM, assetManager, FontWeight.Medium))
            }
            if ("Poppins-SemiBold.ttf" in available) {
                add(Font(POPPINS_SEMIBOLD, assetManager, FontWeight.SemiBold))
            }
            if ("Poppins-Bold.ttf" in available) {
                add(Font(POPPINS_BOLD, assetManager, FontWeight.Bold))
            }
        }
        FontFamily(fonts)
    }.getOrDefault(FontFamily.SansSerif)
}

fun loadPoppinsTypeface(context: Context, semiBold: Boolean = true): Typeface {
    val preferred = if (semiBold) POPPINS_SEMIBOLD else POPPINS_REGULAR
    return runCatching {
        Typeface.createFromAsset(context.assets, preferred)
    }.recoverCatching {
        Typeface.createFromAsset(context.assets, POPPINS_REGULAR)
    }.getOrElse {
        if (semiBold) Typeface.create("sans-serif-medium", Typeface.BOLD) else Typeface.SANS_SERIF
    }
}

@Composable
fun rememberPoppinsFontFamily(): FontFamily {
    val context = LocalContext.current
    return remember(context) { loadPoppinsFontFamily(context) }
}

fun buildReelsGuardTypography(fontFamily: FontFamily): Typography = Typography(
    displayLarge = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 38.sp,
        lineHeight = 46.sp,
        letterSpacing = (-0.6).sp,
        fontFeatureSettings = "tnum"
    ),
    displayMedium = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 30.sp,
        lineHeight = 38.sp,
        letterSpacing = (-0.4).sp,
        fontFeatureSettings = "tnum"
    ),
    headlineLarge = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 25.sp,
        lineHeight = 32.sp,
        letterSpacing = (-0.25).sp
    ),
    headlineMedium = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 20.sp,
        lineHeight = 27.sp,
        letterSpacing = (-0.15).sp
    ),
    titleLarge = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp,
        lineHeight = 24.sp
    ),
    titleMedium = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        lineHeight = 21.sp,
        letterSpacing = 0.05.sp
    ),
    titleSmall = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        letterSpacing = 0.1.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 19.sp
    ),
    bodySmall = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 17.sp
    ),
    labelLarge = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        letterSpacing = 0.15.sp
    ),
    labelMedium = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 15.sp,
        letterSpacing = 0.3.sp
    ),
    labelSmall = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 10.sp,
        lineHeight = 14.sp,
        letterSpacing = 0.35.sp
    )
)

val ReelsGuardTypography = buildReelsGuardTypography(FontFamily.SansSerif)
