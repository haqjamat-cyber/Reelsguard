package com.reelsguard.app.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.reelsguard.app.database.dao.AchievementDao
import com.reelsguard.app.database.dao.BlockingEventDao
import com.reelsguard.app.database.dao.DailySummaryDao
import com.reelsguard.app.database.dao.DailyUsageDao
import com.reelsguard.app.database.dao.PlatformLimitDao
import com.reelsguard.app.database.entity.AchievementEntity
import com.reelsguard.app.database.entity.BlockingEventEntity
import com.reelsguard.app.database.entity.DailySummaryEntity
import com.reelsguard.app.database.entity.DailyUsageEntity
import com.reelsguard.app.database.entity.PlatformLimitEntity

@Database(
    entities = [
        DailyUsageEntity::class,
        PlatformLimitEntity::class,
        BlockingEventEntity::class,
        AchievementEntity::class,
        DailySummaryEntity::class
    ],
    version = 3,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class ReelsGuardDatabase : RoomDatabase() {

    abstract fun dailyUsageDao(): DailyUsageDao
    abstract fun platformLimitDao(): PlatformLimitDao
    abstract fun blockingEventDao(): BlockingEventDao
    abstract fun achievementDao(): AchievementDao
    abstract fun dailySummaryDao(): DailySummaryDao

    companion object {
        private const val DATABASE_NAME = "reelsguard_local.db"

        @Volatile
        private var instance: ReelsGuardDatabase? = null

        fun getInstance(context: Context): ReelsGuardDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    ReelsGuardDatabase::class.java,
                    DATABASE_NAME
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { instance = it }
            }
        }
    }
}
