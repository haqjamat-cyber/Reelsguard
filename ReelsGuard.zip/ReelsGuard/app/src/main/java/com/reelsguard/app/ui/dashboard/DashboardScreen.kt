package com.reelsguard.app.ui.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.reelsguard.app.components.CircularUsageRing
import com.reelsguard.app.components.GlassCard
import com.reelsguard.app.components.PlatformUsageCard
import com.reelsguard.app.components.PremiumBackground
import com.reelsguard.app.components.StatusPill
import com.reelsguard.app.model.BlockingGuardState
import com.reelsguard.app.model.DisciplineStatus
import com.reelsguard.app.model.TrackingConfidence
import com.reelsguard.app.ui.theme.ReelsGuardTheme
import com.reelsguard.app.utils.TimeFormatter

@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    onOpenSettings: () -> Unit,
    onOpenPermissions: () -> Unit,
    onOpenDailyLimits: () -> Unit,
    onOpenPlatforms: () -> Unit,
    contentBottomPadding: PaddingValues = PaddingValues(bottom = 92.dp)
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val extra = ReelsGuardTheme.colors
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshSystemState()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    PremiumBackground {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding(),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = 12.dp,
                bottom = contentBottomPadding.calculateBottomPadding() + 16.dp
            ),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Top bar
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "ReelsGuard",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Resets at ${state.nextResetFormatted} • in ${state.timeUntilResetFormatted}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onOpenDailyLimits) {
                            Icon(
                                imageVector = Icons.Rounded.Tune,
                                contentDescription = "Configure Limits",
                                tint = MaterialTheme.colorScheme.onBackground
                            )
                        }
                        IconButton(onClick = onOpenSettings) {
                            Icon(
                                imageVector = Icons.Rounded.Settings,
                                contentDescription = "Settings",
                                tint = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                }
            }

            // Permission notice banner if Accessibility or Usage Access missing
            if (!state.permissions.isAccessibilityEnabled) {
                item {
                    GlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        highlightAccent = extra.warning,
                        onClick = onOpenPermissions
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.WarningAmber,
                                contentDescription = null,
                                tint = extra.warning,
                                modifier = Modifier.size(26.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (state.permissions.isUsageAccessGranted) {
                                        "Fallback Mode Active • Enable Accessibility to Block"
                                    } else {
                                        "Permissions Required to Track & Block"
                                    },
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Tap to review transparent Accessibility & Usage Access controls.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // Hero Circular Usage Gauge Card
            item {
                val primarySeconds = when (state.primaryTrackingConfidence) {
                    TrackingConfidence.VERIFIED_SECTION -> state.totalVerifiedReelsSeconds
                    TrackingConfidence.APP_WIDE_FALLBACK -> state.totalFallbackAppSeconds
                    TrackingConfidence.UNTRACKED -> 0L
                }
                val guardTint = when (state.blockingGuardState) {
                    BlockingGuardState.ACTIVE_SECTION_GUARD -> extra.success
                    BlockingGuardState.ACTIVE_FALLBACK_GUARD -> extra.accentBlue
                    BlockingGuardState.PERMISSION_MISSING -> extra.warning
                    BlockingGuardState.PAUSED_BY_USER -> MaterialTheme.colorScheme.onSurfaceVariant
                }

                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatusPill(
                            text = state.blockingGuardState.label,
                            tint = guardTint,
                            icon = Icons.Rounded.Shield
                        )
                        StatusPill(
                            text = state.primaryTrackingConfidence.shortTag,
                            tint = extra.accentPurple
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularUsageRing(
                            progress = state.progressFraction,
                            primaryValueText = TimeFormatter.formatDurationCompact(primarySeconds),
                            secondaryLabel = when (state.primaryTrackingConfidence) {
                                TrackingConfidence.VERIFIED_SECTION -> "TODAY'S REELS & SHORTS"
                                TrackingConfidence.APP_WIDE_FALLBACK -> "TODAY'S FULL-APP FALLBACK"
                                TrackingConfidence.UNTRACKED -> "TODAY'S USAGE"
                            },
                            subtitleText = if (state.remainingTotalSeconds > 0L) {
                                "${TimeFormatter.formatDurationCompact(state.remainingTotalSeconds)} remaining"
                            } else {
                                "Daily limit reached"
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // 3 compact metric tiles inside Hero Card
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        HeroMetricItem(
                            label = "Daily Limit",
                            value = TimeFormatter.formatMinutesReadable(state.totalDailyLimitMinutes),
                            modifier = Modifier.weight(1f)
                        )
                        HeroMetricItem(
                            label = "Remaining",
                            value = TimeFormatter.formatDurationCompact(state.remainingTotalSeconds),
                            modifier = Modifier.weight(1f)
                        )
                        HeroMetricItem(
                            label = "Blocks Today",
                            value = "${state.todayBlockEventsCount}",
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Daily Discipline Status Card
            item {
                val disciplineTint = when (state.disciplineStatus) {
                    DisciplineStatus.EXCELLENT -> extra.success
                    DisciplineStatus.APPROACHING_LIMIT -> extra.warning
                    DisciplineStatus.LIMIT_REACHED -> extra.danger
                    DisciplineStatus.SETUP_REQUIRED -> extra.accentBlue
                }
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = state.disciplineStatus.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = disciplineTint
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = state.disciplineStatus.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        StatusPill(
                            text = "${state.currentStreakDays}d streak",
                            tint = extra.accentPurple,
                            icon = Icons.Rounded.LocalFireDepartment
                        )
                    }
                }
            }

            // Individual Platforms Section Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Platforms",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    TextButton(onClick = onOpenDailyLimits) {
                        Text(text = "Edit Limits", color = extra.accentBlue)
                    }
                }
            }

            // Individual Platform Cards (Instagram, YouTube, Facebook)
            items(state.platforms, key = { it.platform.name }) { platformSummary ->
                PlatformUsageCard(
                    summary = platformSummary,
                    onClick = onOpenPlatforms
                )
            }
        }
    }
}

@Composable
private fun HeroMetricItem(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
