package com.reelsguard.app.settings

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.reelsguard.app.data.UserPreferences
import com.reelsguard.app.data.UserPreferencesRepository
import com.reelsguard.app.model.ThemeMode
import com.reelsguard.app.repository.UsageRepository
import com.reelsguard.app.service.DailyResetScheduler
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val appContext: Context,
    private val preferencesRepository: UserPreferencesRepository,
    private val usageRepository: UsageRepository
) : ViewModel() {

    val preferences: StateFlow<UserPreferences> = preferencesRepository.preferencesFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000L),
            initialValue = UserPreferences()
        )

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            preferencesRepository.setThemeMode(mode)
        }
    }

    fun setResetTime(hour: Int, minute: Int) {
        viewModelScope.launch {
            preferencesRepository.setResetTime(hour, minute)
            DailyResetScheduler.scheduleNextExactReset(appContext, hour, minute)
            usageRepository.ensureDailyResetIfNeeded()
        }
    }

    fun setAllowFullAppFallback(allowed: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setAllowFullAppFallbackTracking(allowed)
        }
    }

    fun setShowDynamicIslandCounter(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setShowDynamicIslandCounter(enabled)
        }
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setNotificationsEnabled(enabled)
        }
    }

    fun clearAllLocalData() {
        viewModelScope.launch {
            usageRepository.clearAllLocalHistory()
        }
    }
}
