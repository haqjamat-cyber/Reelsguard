package com.reelsguard.app.ui.dashboard

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.reelsguard.app.data.UserPreferences
import com.reelsguard.app.data.UserPreferencesRepository
import com.reelsguard.app.database.entity.DailyUsageEntity
import com.reelsguard.app.database.entity.PlatformLimitEntity
import com.reelsguard.app.model.BlockMode
import com.reelsguard.app.model.BlockingGuardState
import com.reelsguard.app.model.DashboardUiState
import com.reelsguard.app.model.DisciplineStatus
import com.reelsguard.app.model.PermissionStatusSnapshot
import com.reelsguard.app.model.Platform
import com.reelsguard.app.model.PlatformUsageSummary
import com.reelsguard.app.model.TrackingConfidence
import com.reelsguard.app.repository.AchievementOverview
import com.reelsguard.app.repository.AchievementRepository
import com.reelsguard.app.repository.UsageRepository
import com.reelsguard.app.utils.PermissionHelper
import com.reelsguard.app.utils.ResetScheduleCalculator
import com.reelsguard.app.utils.TimeFormatter
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class DashboardViewModel(
    private val appContext: Context,
    private val usageRepository: UsageRepository,
    private val preferencesRepository: UserPreferencesRepository,
    private val achievementRepository: AchievementRepository
) : ViewModel() {

    private val permissionsFlow = MutableStateFlow(PermissionHelper.getPermissionSnapshot(appContext))
    private val tickFlow = MutableStateFlow(System.currentTimeMillis())

    init {
        refreshSystemState()
        viewModelScope.launch {
            while (isActive) {
                delay(30_000L)
                tickFlow.value = System.currentTimeMillis()
                usageRepository.ensureDailyResetIfNeeded()
                usageRepository.syncFallbackUsageStatsIfPermitted()
            }
        }
    }

    private data class CoreDashboardInputs(
        val prefs: UserPreferences,
        val limits: List<PlatformLimitEntity>,
        val usage: List<DailyUsageEntity>,
        val blockCount: Int,
        val achievement: AchievementOverview
    )

    val uiState: StateFlow<DashboardUiState> = preferencesRepository.preferencesFlow
        .flatMapLatest { prefs ->
            val dateKey = ResetScheduleCalculator.getCurrentCycleDateKey(
                resetHour = prefs.resetHour,
                resetMinute = prefs.resetMinute
            )
            combine(
                usageRepository.observeLimits(),
                usageRepository.observeUsageForDate(dateKey),
                usageRepository.observeBlockingCountForDate(dateKey),
                achievementRepository.observeOverview()
            ) { limits, usage, blockCount, achievement ->
                CoreDashboardInputs(
                    prefs = prefs,
                    limits = limits,
                    usage = usage,
                    blockCount = blockCount,
                    achievement = achievement
                )
            }
        }
        .combine(permissionsFlow) { core, perms -> core to perms }
        .combine(tickFlow) { (core, perms), _ ->
            mapToUiState(core, perms)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000L),
            initialValue = DashboardUiState(isLoading = true)
        )

    fun refreshSystemState() {
        permissionsFlow.value = PermissionHelper.getPermissionSnapshot(appContext)
        tickFlow.value = System.currentTimeMillis()
        viewModelScope.launch {
            usageRepository.ensureDailyResetIfNeeded()
            usageRepository.syncFallbackUsageStatsIfPermitted()
        }
    }

    private fun mapToUiState(
        core: CoreDashboardInputs,
        perms: PermissionStatusSnapshot
    ): DashboardUiState {
        val prefs = core.prefs
        val dateKey = ResetScheduleCalculator.getCurrentCycleDateKey(
            resetHour = prefs.resetHour,
            resetMinute = prefs.resetMinute
        )
        val limitsMap = core.limits.associateBy { it.platform }
        val usageMap = core.usage.associateBy { it.platform }

        val platformSummaries = Platform.entries.map { platform ->
            val limit = limitsMap[platform] ?: PlatformLimitEntity(platform = platform)
            val usage = usageMap[platform]
            val verifiedSec = usage?.verifiedReelsSeconds ?: 0L
            val fallbackSec = usage?.fallbackAppSeconds ?: 0L
            val watchedCount = usage?.watchedReelsCount ?: 0

            val confidence = when {
                !limit.isTrackingEnabled -> TrackingConfidence.UNTRACKED
                perms.isAccessibilityEnabled && limit.blockMode == BlockMode.SECTION_ONLY ->
                    TrackingConfidence.VERIFIED_SECTION
                verifiedSec > 0L -> TrackingConfidence.VERIFIED_SECTION
                perms.isUsageAccessGranted && prefs.allowFullAppFallbackTracking ->
                    TrackingConfidence.APP_WIDE_FALLBACK
                perms.isAccessibilityEnabled -> TrackingConfidence.VERIFIED_SECTION
                else -> TrackingConfidence.UNTRACKED
            }

            val effectiveSec = when (confidence) {
                TrackingConfidence.VERIFIED_SECTION -> verifiedSec
                TrackingConfidence.APP_WIDE_FALLBACK -> fallbackSec
                TrackingConfidence.UNTRACKED -> 0L
            }

            val limitSec = limit.dailyLimitMinutes * 60L
            val isBlocked = perms.canBlockAutomatically &&
                limit.isTrackingEnabled &&
                limit.isLimitEnabled &&
                effectiveSec >= limitSec

            PlatformUsageSummary(
                platform = platform,
                isTrackingEnabled = limit.isTrackingEnabled,
                isLimitEnabled = limit.isLimitEnabled,
                dailyLimitMinutes = limit.dailyLimitMinutes,
                blockMode = limit.blockMode,
                verifiedReelsSeconds = verifiedSec,
                fallbackAppSeconds = fallbackSec,
                activeConfidence = confidence,
                isCurrentlyBlocked = isBlocked,
                watchedReelsCount = watchedCount
            )
        }

        val totalVerified = platformSummaries.sumOf { it.verifiedReelsSeconds }
        val totalFallback = platformSummaries.sumOf { it.fallbackAppSeconds }
        val totalWatchedCount = platformSummaries.sumOf { it.watchedReelsCount }

        val primaryConfidence = when {
            perms.isAccessibilityEnabled -> TrackingConfidence.VERIFIED_SECTION
            perms.isUsageAccessGranted && prefs.allowFullAppFallbackTracking -> TrackingConfidence.APP_WIDE_FALLBACK
            else -> TrackingConfidence.UNTRACKED
        }

        val effectiveTotalSeconds = when (primaryConfidence) {
            TrackingConfidence.VERIFIED_SECTION -> totalVerified
            TrackingConfidence.APP_WIDE_FALLBACK -> totalFallback
            TrackingConfidence.UNTRACKED -> 0L
        }

        val totalLimitMinutes = if (prefs.isTotalDailyLimitEnabled) {
            prefs.totalDailyLimitMinutes
        } else {
            platformSummaries.filter { it.isTrackingEnabled && it.isLimitEnabled }
                .sumOf { it.dailyLimitMinutes }
                .coerceAtLeast(1)
        }
        val totalLimitSeconds = totalLimitMinutes * 60L
        val remainingSeconds = (totalLimitSeconds - effectiveTotalSeconds).coerceAtLeast(0L)
        val progress = (effectiveTotalSeconds.toFloat() / totalLimitSeconds.toFloat()).coerceIn(0f, 1f)

        val anyTracked = platformSummaries.any { it.isTrackingEnabled }
        val anyFullAppMode = platformSummaries.any { it.blockMode == BlockMode.FULL_APP_FALLBACK }
        val blockingGuardState = when {
            !anyTracked -> BlockingGuardState.PAUSED_BY_USER
            !perms.canBlockAutomatically -> BlockingGuardState.PERMISSION_MISSING
            anyFullAppMode -> BlockingGuardState.ACTIVE_FALLBACK_GUARD
            else -> BlockingGuardState.ACTIVE_SECTION_GUARD
        }

        val disciplineStatus = when {
            !perms.hasAnyTrackingPermission -> DisciplineStatus.SETUP_REQUIRED
            progress >= 1f || platformSummaries.any { it.isCurrentlyBlocked } -> DisciplineStatus.LIMIT_REACHED
            progress >= 0.78f -> DisciplineStatus.APPROACHING_LIMIT
            else -> DisciplineStatus.EXCELLENT
        }

        val millisLeft = ResetScheduleCalculator.millisUntilNextReset(
            resetHour = prefs.resetHour,
            resetMinute = prefs.resetMinute
        )

        return DashboardUiState(
            currentDateKey = dateKey,
            totalVerifiedReelsSeconds = totalVerified,
            totalFallbackAppSeconds = totalFallback,
            totalWatchedReelsCount = totalWatchedCount,
            primaryTrackingConfidence = primaryConfidence,
            totalDailyLimitMinutes = totalLimitMinutes,
            isTotalDailyLimitEnabled = prefs.isTotalDailyLimitEnabled,
            remainingTotalSeconds = remainingSeconds,
            progressFraction = progress,
            nextResetFormatted = ResetScheduleCalculator.formatResetTime(prefs.resetHour, prefs.resetMinute),
            timeUntilResetFormatted = TimeFormatter.formatDurationCompact(millisLeft / 1000L),
            blockingGuardState = blockingGuardState,
            disciplineStatus = disciplineStatus,
            currentStreakDays = core.achievement.currentStreak,
            platforms = platformSummaries,
            permissions = perms,
            todayBlockEventsCount = core.blockCount,
            isLoading = false
        )
    }
}
