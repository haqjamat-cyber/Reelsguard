package com.reelsguard.app.repository

import com.reelsguard.app.database.entity.AchievementEntity
import com.reelsguard.app.database.entity.DailySummaryEntity
import com.reelsguard.app.model.BadgeType
import java.time.LocalDate

data class DisciplineProgressSnapshot(
    val currentStreak: Int,
    val bestStreak: Int,
    val weeklyGoalMetCount: Int,
    val totalGoalMetDays: Int,
    val selfPacedZeroBlockDays: Int,
    val motivationalMessage: String
)

/**
 * Pure discipline & achievement evaluation logic for ReelsGuard.
 * Designed to stay warm, constructive, and encouraging rather than guilt-inducing.
 */
object AchievementEvaluator {

    fun calculateProgress(
        summaries: List<DailySummaryEntity>,
        existingAchievements: Map<String, AchievementEntity> = emptyMap(),
        nowEpochMs: Long = System.currentTimeMillis()
    ): Pair<DisciplineProgressSnapshot, List<AchievementEntity>> {
        val sortedAsc = summaries.sortedBy { it.dateKey }
        val sortedDesc = sortedAsc.reversed()

        // Current consecutive streak from the most recent archived day backward
        var currentStreak = 0
        var expectedDate: LocalDate? = null
        for (summary in sortedDesc) {
            val parsedDate = runCatching { LocalDate.parse(summary.dateKey) }.getOrNull() ?: continue
            if (!summary.goalMet) break
            if (expectedDate == null || parsedDate == expectedDate) {
                currentStreak++
                expectedDate = parsedDate.minusDays(1)
            } else {
                break
            }
        }

        // Best consecutive streak across all recorded history
        var bestStreak = 0
        var running = 0
        var previousDate: LocalDate? = null
        for (summary in sortedAsc) {
            val parsedDate = runCatching { LocalDate.parse(summary.dateKey) }.getOrNull() ?: continue
            if (summary.goalMet) {
                running = if (previousDate != null && parsedDate == previousDate.plusDays(1)) {
                    running + 1
                } else {
                    1
                }
                if (running > bestStreak) bestStreak = running
                previousDate = parsedDate
            } else {
                running = 0
                previousDate = parsedDate
            }
        }

        val last7Days = sortedDesc.take(7)
        val weeklyGoalMetCount = last7Days.count { it.goalMet }
        val totalGoalMetDays = sortedAsc.count { it.goalMet }
        val zeroBlockGoalDays = sortedAsc.count {
            it.goalMet && it.blockEventsCount == 0 && (it.totalVerifiedSeconds > 0L || it.totalFallbackSeconds > 0L)
        }

        val badges = BadgeType.entries.map { badge ->
            val progressValue = when (badge) {
                BadgeType.FIRST_MINDFUL_DAY -> totalGoalMetDays.coerceAtMost(badge.targetCount)
                BadgeType.STREAK_3,
                BadgeType.STREAK_7,
                BadgeType.STREAK_14,
                BadgeType.STREAK_30 -> bestStreak.coerceAtMost(badge.targetCount)
                BadgeType.WEEKLY_CHAMPION -> weeklyGoalMetCount.coerceAtMost(badge.targetCount)
                BadgeType.ZERO_BLOCK_DAY -> zeroBlockGoalDays.coerceAtMost(badge.targetCount)
            }
            val existing = existingAchievements[badge.id]
            val unlocked = (existing?.isUnlocked == true) || progressValue >= badge.targetCount
            AchievementEntity(
                badgeId = badge.id,
                title = badge.title,
                description = badge.description,
                progressCurrent = if (unlocked) badge.targetCount else progressValue,
                progressTarget = badge.targetCount,
                isUnlocked = unlocked,
                unlockedAtEpochMs = when {
                    existing?.unlockedAtEpochMs != null -> existing.unlockedAtEpochMs
                    unlocked -> nowEpochMs
                    else -> null
                }
            )
        }

        val message = pickEncouragingMessage(currentStreak, weeklyGoalMetCount, totalGoalMetDays)

        val snapshot = DisciplineProgressSnapshot(
            currentStreak = currentStreak,
            bestStreak = bestStreak,
            weeklyGoalMetCount = weeklyGoalMetCount,
            totalGoalMetDays = totalGoalMetDays,
            selfPacedZeroBlockDays = zeroBlockGoalDays,
            motivationalMessage = message
        )
        return snapshot to badges
    }

    fun pickEncouragingMessage(
        currentStreak: Int,
        weeklyGoalMetCount: Int,
        totalGoalMetDays: Int
    ): String {
        return when {
            currentStreak >= 14 -> "Remarkable steadiness — $currentStreak mindful days in a row. Your focus belongs to you."
            currentStreak >= 7 -> "A full week of intentional screen time! Notice how much calmer your evenings feel."
            currentStreak >= 3 -> "$currentStreak consecutive balanced days. Small pauses are turning into a lasting habit."
            weeklyGoalMetCount >= 4 -> "Strong week so far — you stayed within your goal $weeklyGoalMetCount times."
            totalGoalMetDays >= 1 -> "Every mindful pause counts. Tomorrow is another calm, fresh canvas."
            else -> "Welcome to intentional scrolling. Set gentle limits that feel sustainable for your day."
        }
    }
}
