package com.reelsguard.app.service

import com.reelsguard.app.database.entity.PlatformLimitEntity
import com.reelsguard.app.model.BlockMode
import com.reelsguard.app.model.Platform

sealed interface BlockingDecision {
    data class Allow(val reason: String) : BlockingDecision
    data class PermissionRequired(val reason: String) : BlockingDecision
    data class Block(
        val platform: Platform,
        val mode: BlockMode,
        val usedSeconds: Long,
        val limitMinutes: Int,
        val reason: String
    ) : BlockingDecision
}

/**
 * Pure decision engine determining whether ReelsGuard should allow or restrict access.
 *
 * Guarantees:
 * - Never claims blocking can succeed when Accessibility permission is missing.
 * - Honors per-platform tracking switches, per-platform limits, and optional total daily limit.
 * - Separates Section-Only restriction from Full-App Fallback restriction cleanly.
 */
object BlockingDecisionEngine {

    fun evaluate(
        hasAccessibilityPermission: Boolean,
        platform: Platform,
        limitConfig: PlatformLimitEntity,
        isShortFormSectionDetected: Boolean,
        platformUsedSeconds: Long,
        totalUsedSecondsAcrossPlatforms: Long,
        totalDailyLimitMinutes: Int,
        isTotalDailyLimitEnabled: Boolean
    ): BlockingDecision {
        if (!hasAccessibilityPermission) {
            return BlockingDecision.PermissionRequired(
                "Accessibility permission is not enabled; automatic blocking cannot execute."
            )
        }

        if (!limitConfig.isTrackingEnabled) {
            return BlockingDecision.Allow("Tracking is disabled for ${platform.displayName}.")
        }

        val shouldEvaluateScreen = when (limitConfig.blockMode) {
            BlockMode.SECTION_ONLY -> isShortFormSectionDetected
            BlockMode.FULL_APP_FALLBACK -> true
        }

        if (!shouldEvaluateScreen) {
            return BlockingDecision.Allow(
                "Current screen is outside ${platform.shortFormLabel} and Section-Only mode is active."
            )
        }

        val platformLimitSeconds = limitConfig.dailyLimitMinutes.coerceAtLeast(1) * 60L
        if (limitConfig.isLimitEnabled && platformUsedSeconds >= platformLimitSeconds) {
            return BlockingDecision.Block(
                platform = platform,
                mode = limitConfig.blockMode,
                usedSeconds = platformUsedSeconds,
                limitMinutes = limitConfig.dailyLimitMinutes,
                reason = "${platform.displayName} daily limit reached (${limitConfig.dailyLimitMinutes}m)."
            )
        }

        val totalLimitSeconds = totalDailyLimitMinutes.coerceAtLeast(1) * 60L
        if (isTotalDailyLimitEnabled && totalUsedSecondsAcrossPlatforms >= totalLimitSeconds) {
            return BlockingDecision.Block(
                platform = platform,
                mode = limitConfig.blockMode,
                usedSeconds = totalUsedSecondsAcrossPlatforms,
                limitMinutes = totalDailyLimitMinutes,
                reason = "Combined daily short-form limit reached (${totalDailyLimitMinutes}m)."
            )
        }

        return BlockingDecision.Allow("Within configured daily limits.")
    }
}
