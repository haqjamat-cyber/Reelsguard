package com.reelsguard.app.service

import com.reelsguard.app.database.entity.PlatformLimitEntity
import com.reelsguard.app.model.BlockMode
import com.reelsguard.app.model.Platform

sealed interface BlockingDecision {
    data class Allow(val reason: String) : BlockingDecision
    data class PermissionRequired(val reason: String) : BlockingDecision
    data class Block(
        val platform: Platform,
        val mode: BlockMode,
        val watchedVideos: Int,
        val limitVideos: Int,
        val reason: String
    ) : BlockingDecision
}

/**
 * Pure decision engine determining whether ReelsGuard should allow or block Reels/Shorts
 * based strictly on the user's typed video-count target.
 */
object BlockingDecisionEngine {

    fun evaluate(
        hasAccessibilityPermission: Boolean,
        platform: Platform,
        limitConfig: PlatformLimitEntity,
        isShortFormSectionDetected: Boolean,
        platformWatchedVideos: Int,
        totalWatchedVideosAcrossPlatforms: Int,
        totalDailyVideoLimit: Int,
        isTotalDailyLimitEnabled: Boolean
    ): BlockingDecision {
        if (!hasAccessibilityPermission) {
            return BlockingDecision.PermissionRequired(
                "Accessibility permission is not enabled; automatic blocking cannot execute."
            )
        }

        if (!limitConfig.isTrackingEnabled) {
            return BlockingDecision.Allow("Tracking is disabled for ${platform.displayName}.")
        }

        val shouldEvaluateScreen = when (limitConfig.blockMode) {
            BlockMode.SECTION_ONLY -> isShortFormSectionDetected
            BlockMode.FULL_APP_FALLBACK -> true
        }

        if (!shouldEvaluateScreen) {
            return BlockingDecision.Allow(
                "Current screen is outside ${platform.shortFormLabel} and Section-Only mode is active."
            )
        }

        if (limitConfig.isLimitEnabled &&
            limitConfig.dailyVideoLimit > 0 &&
            platformWatchedVideos >= limitConfig.dailyVideoLimit
        ) {
            return BlockingDecision.Block(
                platform = platform,
                mode = limitConfig.blockMode,
                watchedVideos = platformWatchedVideos,
                limitVideos = limitConfig.dailyVideoLimit,
                reason = "${platform.shortFormLabel} target reached (${limitConfig.dailyVideoLimit} videos)."
            )
        }

        if (isTotalDailyLimitEnabled &&
            totalDailyVideoLimit > 0 &&
            totalWatchedVideosAcrossPlatforms >= totalDailyVideoLimit
        ) {
            return BlockingDecision.Block(
                platform = platform,
                mode = limitConfig.blockMode,
                watchedVideos = totalWatchedVideosAcrossPlatforms,
                limitVideos = totalDailyVideoLimit,
                reason = "Daily short-form target reached ($totalDailyVideoLimit videos)."
            )
        }

        return BlockingDecision.Allow("Within configured daily video target.")
    }
}
