package com.reelsguard.app.repository

import android.content.Context
import com.reelsguard.app.data.UserPreferences
import com.reelsguard.app.data.UserPreferencesRepository
import com.reelsguard.app.database.dao.AchievementDao
import com.reelsguard.app.database.dao.BlockingEventDao
import com.reelsguard.app.database.dao.DailySummaryDao
import com.reelsguard.app.database.dao.DailyUsageDao
import com.reelsguard.app.database.dao.PlatformLimitDao
import com.reelsguard.app.database.entity.BlockingEventEntity
import com.reelsguard.app.database.entity.DailySummaryEntity
import com.reelsguard.app.database.entity.DailyUsageEntity
import com.reelsguard.app.database.entity.PlatformLimitEntity
import com.reelsguard.app.model.BlockMode
import com.reelsguard.app.model.Platform
import com.reelsguard.app.model.TrackingConfidence
import com.reelsguard.app.service.UsageStatsSyncManager
import com.reelsguard.app.utils.PermissionHelper
import com.reelsguard.app.utils.ResetScheduleCalculator
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.ZonedDateTime

class UsageRepository(
    private val context: Context,
    private val dailyUsageDao: DailyUsageDao,
    private val platformLimitDao: PlatformLimitDao,
    private val blockingEventDao: BlockingEventDao,
    private val dailySummaryDao: DailySummaryDao,
    private val achievementDao: AchievementDao,
    private val preferencesRepository: UserPreferencesRepository,
    private val usageStatsSyncManager: UsageStatsSyncManager,
    private val achievementRepository: AchievementRepository
) {
    private val resetMutex = Mutex()
    private val usageWriteMutex = Mutex()

    suspend fun initializeDefaults() {
        val defaultLimits = Platform.entries.map { platform ->
            PlatformLimitEntity(
                platform = platform,
                isTrackingEnabled = true,
                isLimitEnabled = true,
                dailyLimitMinutes = platform.defaultLimitMinutes,
                blockMode = BlockMode.SECTION_ONLY
            )
        }
        platformLimitDao.insertDefaultsIfMissing(defaultLimits)
        achievementRepository.ensureDefaultBadgesExist()
        ensureDailyResetIfNeeded()
    }

    fun observeLimits(): Flow<List<PlatformLimitEntity>> = platformLimitDao.observeAllLimits()

    fun observeUsageForDate(dateKey: String): Flow<List<DailyUsageEntity>> =
        dailyUsageDao.observeUsageForDate(dateKey)

    fun observeBlockingCountForDate(dateKey: String): Flow<Int> =
        blockingEventDao.observeCountForDate(dateKey)

    suspend fun getAllLimits(): List<PlatformLimitEntity> = platformLimitDao.getAllLimits()

    suspend fun getLimitForPlatform(platform: Platform): PlatformLimitEntity {
        return platformLimitDao.getLimit(platform) ?: PlatformLimitEntity(platform = platform)
    }

    suspend fun getTodayUsage(dateKey: String): List<DailyUsageEntity> =
        dailyUsageDao.getUsageForDate(dateKey)

    suspend fun updatePlatformTrackingEnabled(platform: Platform, enabled: Boolean) {
        val current = getLimitForPlatform(platform)
        platformLimitDao.upsert(
            current.copy(
                isTrackingEnabled = enabled,
                updatedAtEpochMs = System.currentTimeMillis()
            )
        )
    }

    suspend fun updatePlatformLimit(
        platform: Platform,
        dailyLimitMinutes: Int,
        isLimitEnabled: Boolean
    ) {
        val current = getLimitForPlatform(platform)
        platformLimitDao.upsert(
            current.copy(
                dailyLimitMinutes = dailyLimitMinutes.coerceIn(1, 240),
                isLimitEnabled = isLimitEnabled,
                updatedAtEpochMs = System.currentTimeMillis()
            )
        )
    }

    suspend fun updatePlatformBlockMode(platform: Platform, blockMode: BlockMode) {
        val current = getLimitForPlatform(platform)
        platformLimitDao.upsert(
            current.copy(
                blockMode = blockMode,
                updatedAtEpochMs = System.currentTimeMillis()
            )
        )
    }

    /**
     * Checks whether the logical daily reset boundary (or timezone) has rolled over.
     * If so, archives the previous day's summary, recalculates discipline streaks/badges,
     * and advances the active date key. Safe to call on app launch, resume, boot, and worker runs.
     */
    suspend fun ensureDailyResetIfNeeded(now: ZonedDateTime = ZonedDateTime.now()): Boolean {
        return resetMutex.withLock {
            val prefs = preferencesRepository.currentPreferences()
            val currentDateKey = ResetScheduleCalculator.getCurrentCycleDateKey(
                now = now,
                resetHour = prefs.resetHour,
                resetMinute = prefs.resetMinute
            )
            val currentTz = now.zone.id

            if (prefs.lastProcessedDateKey.isBlank()) {
                preferencesRepository.updateResetTrackingState(currentDateKey, currentTz)
                return@withLock false
            }

            if (prefs.lastProcessedDateKey == currentDateKey) {
                if (prefs.lastTimezoneId != currentTz) {
                    preferencesRepository.updateResetTrackingState(currentDateKey, currentTz)
                }
                return@withLock false
            }

            // Previous cycle ended -> archive summary for the previous date key
            archiveDaySummary(previousDateKey = prefs.lastProcessedDateKey, prefs = prefs)
            preferencesRepository.updateResetTrackingState(currentDateKey, currentTz)
            achievementRepository.recalculateAndPersist()
            true
        }
    }

    private suspend fun archiveDaySummary(previousDateKey: String, prefs: UserPreferences) {
        val usages = dailyUsageDao.getUsageForDate(previousDateKey)
        val limits = platformLimitDao.getAllLimits().associateBy { it.platform }
        val blockCount = blockingEventDao.getCountForDate(previousDateKey)

        val totalVerified = usages.sumOf { it.verifiedReelsSeconds }
        val totalFallback = usages.sumOf { it.fallbackAppSeconds }

        val effectiveTotal = if (totalVerified > 0L) totalVerified else totalFallback
        val totalLimitSeconds = prefs.totalDailyLimitMinutes * 60L

        val perPlatformWithinLimit = usages.all { usage ->
            val limit = limits[usage.platform] ?: return@all true
            if (!limit.isLimitEnabled || !limit.isTrackingEnabled) return@all true
            val platformEffective = if (usage.verifiedReelsSeconds > 0L) {
                usage.verifiedReelsSeconds
            } else {
                usage.fallbackAppSeconds
            }
            platformEffective <= limit.dailyLimitMinutes * 60L
        }

        val totalWithinLimit = !prefs.isTotalDailyLimitEnabled || effectiveTotal <= totalLimitSeconds
        val goalMet = perPlatformWithinLimit && totalWithinLimit

        val existingSummaries = dailySummaryDao.getAllSummaries()
            .filterNot { it.dateKey == previousDateKey }
        val previousStreak = AchievementEvaluator.calculateProgress(existingSummaries).first.currentStreak
        val streakOnDay = if (goalMet) previousStreak + 1 else 0

        dailySummaryDao.upsert(
            DailySummaryEntity(
                dateKey = previousDateKey,
                totalVerifiedSeconds = totalVerified,
                totalFallbackSeconds = totalFallback,
                totalLimitMinutes = prefs.totalDailyLimitMinutes,
                goalMet = goalMet,
                blockEventsCount = blockCount,
                streakOnDay = streakOnDay,
                closedAtEpochMs = System.currentTimeMillis()
            )
        )
    }

    /**
     * Records verified Reels/Shorts screen viewing time observed by ReelsGuardAccessibilityService.
     */
    suspend fun addVerifiedReelsSeconds(platform: Platform, deltaSeconds: Long) {
        if (deltaSeconds <= 0L) return
        ensureDailyResetIfNeeded()
        val prefs = preferencesRepository.currentPreferences()
        val dateKey = ResetScheduleCalculator.getCurrentCycleDateKey(
            resetHour = prefs.resetHour,
            resetMinute = prefs.resetMinute
        )
        val limit = getLimitForPlatform(platform)

        usageWriteMutex.withLock {
            val existing = dailyUsageDao.getUsageForDateAndPlatform(dateKey, platform)
            val updated = (existing ?: DailyUsageEntity(
                dateKey = dateKey,
                platform = platform,
                limitMinutesSnapshot = limit.dailyLimitMinutes
            )).copy(
                verifiedReelsSeconds = (existing?.verifiedReelsSeconds ?: 0L) + deltaSeconds,
                lastConfidence = TrackingConfidence.VERIFIED_SECTION,
                limitMinutesSnapshot = limit.dailyLimitMinutes,
                lastUpdatedEpochMs = System.currentTimeMillis()
            )
            dailyUsageDao.upsert(updated)
        }
    }

    /**
     * Synchronizes whole-app fallback usage from Android UsageStatsManager into `fallbackAppSeconds`.
     * Never writes into `verifiedReelsSeconds`, preserving strict honesty about measurement scope.
     */
    suspend fun syncFallbackUsageStatsIfPermitted() {
        val prefs = preferencesRepository.currentPreferences()
        if (!prefs.allowFullAppFallbackTracking) return
        if (!PermissionHelper.isUsageStatsPermissionGranted(context)) return

        ensureDailyResetIfNeeded()
        val now = ZonedDateTime.now()
        val dateKey = ResetScheduleCalculator.getCurrentCycleDateKey(
            now = now,
            resetHour = prefs.resetHour,
            resetMinute = prefs.resetMinute
        )
        val cycleStartMs = ResetScheduleCalculator.getCurrentCycleStart(
            now = now,
            resetHour = prefs.resetHour,
            resetMinute = prefs.resetMinute
        ).toInstant().toEpochMilli()

        val queriedSeconds = usageStatsSyncManager.queryAppWideUsageSeconds(
            cycleStartEpochMs = cycleStartMs,
            nowEpochMs = now.toInstant().toEpochMilli()
        )
        if (queriedSeconds.isEmpty()) return

        val limits = platformLimitDao.getAllLimits().associateBy { it.platform }
        usageWriteMutex.withLock {
            for ((platform, appSeconds) in queriedSeconds) {
                val limit = limits[platform] ?: PlatformLimitEntity(platform = platform)
                if (!limit.isTrackingEnabled) continue

                val existing = dailyUsageDao.getUsageForDateAndPlatform(dateKey, platform)
                val nextConfidence = if ((existing?.verifiedReelsSeconds ?: 0L) > 0L) {
                    TrackingConfidence.VERIFIED_SECTION
                } else if (appSeconds > 0L) {
                    TrackingConfidence.APP_WIDE_FALLBACK
                } else {
                    existing?.lastConfidence ?: TrackingConfidence.APP_WIDE_FALLBACK
                }

                val updated = (existing ?: DailyUsageEntity(
                    dateKey = dateKey,
                    platform = platform,
                    limitMinutesSnapshot = limit.dailyLimitMinutes
                )).copy(
                    fallbackAppSeconds = maxOf(existing?.fallbackAppSeconds ?: 0L, appSeconds),
                    lastConfidence = nextConfidence,
                    limitMinutesSnapshot = limit.dailyLimitMinutes,
                    lastUpdatedEpochMs = System.currentTimeMillis()
                )
                dailyUsageDao.upsert(updated)
            }
        }
    }

    suspend fun recordBlockingEvent(
        platform: Platform,
        mode: BlockMode,
        usageSecondsAtBlock: Long,
        limitMinutesAtBlock: Int,
        reason: String
    ) {
        val prefs = preferencesRepository.currentPreferences()
        val dateKey = ResetScheduleCalculator.getCurrentCycleDateKey(
            resetHour = prefs.resetHour,
            resetMinute = prefs.resetMinute
        )
        blockingEventDao.insert(
            BlockingEventEntity(
                dateKey = dateKey,
                platform = platform,
                blockModeUsed = mode,
                usageSecondsAtBlock = usageSecondsAtBlock,
                limitMinutesAtBlock = limitMinutesAtBlock,
                reason = reason
            )
        )
        usageWriteMutex.withLock {
            val existing = dailyUsageDao.getUsageForDateAndPlatform(dateKey, platform)
            val updated = (existing ?: DailyUsageEntity(
                dateKey = dateKey,
                platform = platform,
                limitMinutesSnapshot = limitMinutesAtBlock
            )).copy(
                wasBlockedToday = true,
                lastUpdatedEpochMs = System.currentTimeMillis()
            )
            dailyUsageDao.upsert(updated)
        }
    }

    suspend fun clearAllLocalHistory() {
        dailyUsageDao.clearAll()
        blockingEventDao.clearAll()
        dailySummaryDao.clearAll()
        achievementDao.clearAll()
        achievementRepository.ensureDefaultBadgesExist()
    }
}
