package com.reelsguard.app.repository

import android.content.Context
import com.reelsguard.app.data.UserPreferences
import com.reelsguard.app.data.UserPreferencesRepository
import com.reelsguard.app.database.dao.AchievementDao
import com.reelsguard.app.database.dao.BlockingEventDao
import com.reelsguard.app.database.dao.DailySummaryDao
import com.reelsguard.app.database.dao.DailyUsageDao
import com.reelsguard.app.database.dao.PlatformLimitDao
import com.reelsguard.app.database.entity.BlockingEventEntity
import com.reelsguard.app.database.entity.DailySummaryEntity
import com.reelsguard.app.database.entity.DailyUsageEntity
import com.reelsguard.app.database.entity.PlatformLimitEntity
import com.reelsguard.app.model.BlockMode
import com.reelsguard.app.model.Platform
import com.reelsguard.app.model.TrackingConfidence
import com.reelsguard.app.service.UsageStatsSyncManager
import com.reelsguard.app.utils.PermissionHelper
import com.reelsguard.app.utils.ResetScheduleCalculator
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.ZonedDateTime

class UsageRepository(
    private val context: Context,
    private val dailyUsageDao: DailyUsageDao,
    private val platformLimitDao: PlatformLimitDao,
    private val blockingEventDao: BlockingEventDao,
    private val dailySummaryDao: DailySummaryDao,
    private val achievementDao: AchievementDao,
    private val preferencesRepository: UserPreferencesRepository,
    private val usageStatsSyncManager: UsageStatsSyncManager,
    private val achievementRepository: AchievementRepository
) {
    private val resetMutex = Mutex()
    private val usageWriteMutex = Mutex()

    suspend fun initializeDefaults() {
        // Default dailyVideoLimit = 0 and isLimitEnabled = false so NO number is pre-filled.
        val defaultLimits = Platform.entries.map { platform ->
            PlatformLimitEntity(
                platform = platform,
                isTrackingEnabled = true,
                isLimitEnabled = false,
                dailyVideoLimit = 0,
                blockMode = BlockMode.SECTION_ONLY
            )
        }
        platformLimitDao.insertDefaultsIfMissing(defaultLimits)
        achievementRepository.ensureDefaultBadgesExist()
        ensureDailyResetIfNeeded()
    }

    fun observeLimits(): Flow<List<PlatformLimitEntity>> = platformLimitDao.observeAllLimits()

    fun observeUsageForDate(dateKey: String): Flow<List<DailyUsageEntity>> =
        dailyUsageDao.observeUsageForDate(dateKey)

    fun observeBlockingCountForDate(dateKey: String): Flow<Int> =
        blockingEventDao.observeCountForDate(dateKey)

    suspend fun getAllLimits(): List<PlatformLimitEntity> = platformLimitDao.getAllLimits()

    suspend fun getLimitForPlatform(platform: Platform): PlatformLimitEntity {
        return platformLimitDao.getLimit(platform) ?: PlatformLimitEntity(platform = platform)
    }

    suspend fun getTodayUsage(dateKey: String): List<DailyUsageEntity> =
        dailyUsageDao.getUsageForDate(dateKey)

    suspend fun updatePlatformTrackingEnabled(platform: Platform, enabled: Boolean) {
        val current = getLimitForPlatform(platform)
        platformLimitDao.upsert(
            current.copy(
                isTrackingEnabled = enabled,
                updatedAtEpochMs = System.currentTimeMillis()
            )
        )
    }

    suspend fun updatePlatformVideoLimit(
        platform: Platform,
        dailyVideoLimit: Int,
        isLimitEnabled: Boolean
    ) {
        val current = getLimitForPlatform(platform)
        val sanitized = dailyVideoLimit.coerceIn(0, 9999)
        platformLimitDao.upsert(
            current.copy(
                dailyVideoLimit = sanitized,
                isLimitEnabled = isLimitEnabled && sanitized > 0,
                updatedAtEpochMs = System.currentTimeMillis()
            )
        )
    }

    suspend fun updatePlatformBlockMode(platform: Platform, blockMode: BlockMode) {
        val current = getLimitForPlatform(platform)
        platformLimitDao.upsert(
            current.copy(
                blockMode = blockMode,
                updatedAtEpochMs = System.currentTimeMillis()
            )
        )
    }

    suspend fun ensureDailyResetIfNeeded(now: ZonedDateTime = ZonedDateTime.now()): Boolean {
        return resetMutex.withLock {
            val prefs = preferencesRepository.currentPreferences()
            val currentDateKey = ResetScheduleCalculator.getCurrentCycleDateKey(
                now = now,
                resetHour = prefs.resetHour,
                resetMinute = prefs.resetMinute
            )
            val currentTz = now.zone.id

            if (prefs.lastProcessedDateKey.isBlank()) {
                preferencesRepository.updateResetTrackingState(currentDateKey, currentTz)
                return@withLock false
            }

            if (prefs.lastProcessedDateKey == currentDateKey) {
                if (prefs.lastTimezoneId != currentTz) {
                    preferencesRepository.updateResetTrackingState(currentDateKey, currentTz)
                }
                return@withLock false
            }

            archiveDaySummary(previousDateKey = prefs.lastProcessedDateKey, prefs = prefs)
            preferencesRepository.updateResetTrackingState(currentDateKey, currentTz)
            achievementRepository.recalculateAndPersist()
            true
        }
    }

    private suspend fun archiveDaySummary(previousDateKey: String, prefs: UserPreferences) {
        val usages = dailyUsageDao.getUsageForDate(previousDateKey)
        val limits = platformLimitDao.getAllLimits().associateBy { it.platform }
        val blockCount = blockingEventDao.getCountForDate(previousDateKey)

        val totalVerified = usages.sumOf { it.verifiedReelsSeconds }
        val totalFallback = usages.sumOf { it.fallbackAppSeconds }
        val totalWatchedVideos = usages.sumOf { it.watchedReelsCount }

        val perPlatformWithinLimit = usages.all { usage ->
            val limit = limits[usage.platform] ?: return@all true
            if (!limit.isLimitEnabled || !limit.isTrackingEnabled || limit.dailyVideoLimit <= 0) {
                return@all true
            }
            usage.watchedReelsCount <= limit.dailyVideoLimit
        }

        val totalWithinLimit = !prefs.isTotalDailyLimitEnabled ||
            prefs.totalDailyVideoLimit <= 0 ||
            totalWatchedVideos <= prefs.totalDailyVideoLimit
        val goalMet = perPlatformWithinLimit && totalWithinLimit

        val existingSummaries = dailySummaryDao.getAllSummaries()
            .filterNot { it.dateKey == previousDateKey }
        val previousStreak = AchievementEvaluator.calculateProgress(existingSummaries).first.currentStreak
        val streakOnDay = if (goalMet) previousStreak + 1 else 0

        dailySummaryDao.upsert(
            DailySummaryEntity(
                dateKey = previousDateKey,
                totalVerifiedSeconds = totalVerified,
                totalFallbackSeconds = totalFallback,
                totalLimitMinutes = prefs.totalDailyVideoLimit,
                goalMet = goalMet,
                blockEventsCount = blockCount,
                streakOnDay = streakOnDay,
                closedAtEpochMs = System.currentTimeMillis()
            )
        )
    }

    suspend fun addVerifiedReelsSeconds(platform: Platform, deltaSeconds: Long) {
        if (deltaSeconds <= 0L) return
        ensureDailyResetIfNeeded()
        val prefs = preferencesRepository.currentPreferences()
        val dateKey = ResetScheduleCalculator.getCurrentCycleDateKey(
            resetHour = prefs.resetHour,
            resetMinute = prefs.resetMinute
        )
        val limit = getLimitForPlatform(platform)

        usageWriteMutex.withLock {
            val existing = dailyUsageDao.getUsageForDateAndPlatform(dateKey, platform)
            val updated = (existing ?: DailyUsageEntity(
                dateKey = dateKey,
                platform = platform,
                limitVideosSnapshot = limit.dailyVideoLimit
            )).copy(
                verifiedReelsSeconds = (existing?.verifiedReelsSeconds ?: 0L) + deltaSeconds,
                lastConfidence = TrackingConfidence.VERIFIED_SECTION,
                limitVideosSnapshot = limit.dailyVideoLimit,
                lastUpdatedEpochMs = System.currentTimeMillis()
            )
            dailyUsageDao.upsert(updated)
        }
    }

    suspend fun incrementWatchedReelsCount(platform: Platform, delta: Int = 1): Int {
        if (delta <= 0) return getTodayWatchedReelsCount(platform)
        ensureDailyResetIfNeeded()
        val prefs = preferencesRepository.currentPreferences()
        val dateKey = ResetScheduleCalculator.getCurrentCycleDateKey(
            resetHour = prefs.resetHour,
            resetMinute = prefs.resetMinute
        )
        val limit = getLimitForPlatform(platform)

        return usageWriteMutex.withLock {
            val existing = dailyUsageDao.getUsageForDateAndPlatform(dateKey, platform)
            val nextCount = (existing?.watchedReelsCount ?: 0) + delta
            val updated = (existing ?: DailyUsageEntity(
                dateKey = dateKey,
                platform = platform,
                limitVideosSnapshot = limit.dailyVideoLimit
            )).copy(
                watchedReelsCount = nextCount,
                lastConfidence = TrackingConfidence.VERIFIED_SECTION,
                limitVideosSnapshot = limit.dailyVideoLimit,
                lastUpdatedEpochMs = System.currentTimeMillis()
            )
            dailyUsageDao.upsert(updated)
            nextCount
        }
    }

    suspend fun getTodayWatchedReelsCount(platform: Platform): Int {
        ensureDailyResetIfNeeded()
        val prefs = preferencesRepository.currentPreferences()
        val dateKey = ResetScheduleCalculator.getCurrentCycleDateKey(
            resetHour = prefs.resetHour,
            resetMinute = prefs.resetMinute
        )
        return dailyUsageDao.getUsageForDateAndPlatform(dateKey, platform)?.watchedReelsCount ?: 0
    }

    suspend fun syncFallbackUsageStatsIfPermitted() {
        val prefs = preferencesRepository.currentPreferences()
        if (!prefs.allowFullAppFallbackTracking) return
        if (!PermissionHelper.isUsageStatsPermissionGranted(context)) return

        ensureDailyResetIfNeeded()
        val now = ZonedDateTime.now()
        val dateKey = ResetScheduleCalculator.getCurrentCycleDateKey(
            now = now,
            resetHour = prefs.resetHour,
            resetMinute = prefs.resetMinute
        )
        val cycleStartMs = ResetScheduleCalculator.getCurrentCycleStart(
            now = now,
            resetHour = prefs.resetHour,
            resetMinute = prefs.resetMinute
        ).toInstant().toEpochMilli()

        val queriedSeconds = usageStatsSyncManager.queryAppWideUsageSeconds(
            cycleStartEpochMs = cycleStartMs,
            nowEpochMs = now.toInstant().toEpochMilli()
        )
        if (queriedSeconds.isEmpty()) return

        val limits = platformLimitDao.getAllLimits().associateBy { it.platform }
        usageWriteMutex.withLock {
            for ((platform, appSeconds) in queriedSeconds) {
                val limit = limits[platform] ?: PlatformLimitEntity(platform = platform)
                if (!limit.isTrackingEnabled) continue

                val existing = dailyUsageDao.getUsageForDateAndPlatform(dateKey, platform)
                val nextConfidence = if ((existing?.verifiedReelsSeconds ?: 0L) > 0L) {
                    TrackingConfidence.VERIFIED_SECTION
                } else if (appSeconds > 0L) {
                    TrackingConfidence.APP_WIDE_FALLBACK
                } else {
                    existing?.lastConfidence ?: TrackingConfidence.APP_WIDE_FALLBACK
                }

                val updated = (existing ?: DailyUsageEntity(
                    dateKey = dateKey,
                    platform = platform,
                    limitVideosSnapshot = limit.dailyVideoLimit
                )).copy(
                    fallbackAppSeconds = maxOf(existing?.fallbackAppSeconds ?: 0L, appSeconds),
                    lastConfidence = nextConfidence,
                    limitVideosSnapshot = limit.dailyVideoLimit,
                    lastUpdatedEpochMs = System.currentTimeMillis()
                )
                dailyUsageDao.upsert(updated)
            }
        }
    }

    suspend fun recordBlockingEvent(
        platform: Platform,
        mode: BlockMode,
        usageSecondsAtBlock: Long,
        limitMinutesAtBlock: Int,
        reason: String
    ) {
        val prefs = preferencesRepository.currentPreferences()
        val dateKey = ResetScheduleCalculator.getCurrentCycleDateKey(
            resetHour = prefs.resetHour,
            resetMinute = prefs.resetMinute
        )
        blockingEventDao.insert(
            BlockingEventEntity(
                dateKey = dateKey,
                platform = platform,
                blockModeUsed = mode,
                usageSecondsAtBlock = usageSecondsAtBlock,
                limitMinutesAtBlock = limitMinutesAtBlock,
                reason = reason
            )
        )
        usageWriteMutex.withLock {
            val existing = dailyUsageDao.getUsageForDateAndPlatform(dateKey, platform)
            val updated = (existing ?: DailyUsageEntity(
                dateKey = dateKey,
                platform = platform,
                limitVideosSnapshot = limitMinutesAtBlock
            )).copy(
                wasBlockedToday = true,
                lastUpdatedEpochMs = System.currentTimeMillis()
            )
            dailyUsageDao.upsert(updated)
        }
    }

    suspend fun clearAllLocalHistory() {
        dailyUsageDao.clearAll()
        blockingEventDao.clearAll()
        dailySummaryDao.clearAll()
        achievementDao.clearAll()
        achievementRepository.ensureDefaultBadgesExist()
    }
}
