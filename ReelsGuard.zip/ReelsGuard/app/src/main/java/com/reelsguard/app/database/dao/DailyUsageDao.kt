package com.reelsguard.app.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.reelsguard.app.database.entity.DailyUsageEntity
import com.reelsguard.app.model.Platform
import kotlinx.coroutines.flow.Flow

@Dao
interface DailyUsageDao {

    @Query("SELECT * FROM daily_usage WHERE dateKey = :dateKey")
    fun observeUsageForDate(dateKey: String): Flow<List<DailyUsageEntity>>

    @Query("SELECT * FROM daily_usage WHERE dateKey = :dateKey")
    suspend fun getUsageForDate(dateKey: String): List<DailyUsageEntity>

    @Query("SELECT * FROM daily_usage WHERE dateKey = :dateKey AND platform = :platform LIMIT 1")
    suspend fun getUsageForDateAndPlatform(dateKey: String, platform: Platform): DailyUsageEntity?

    @Query("SELECT * FROM daily_usage WHERE dateKey >= :fromDateKey ORDER BY dateKey ASC")
    fun observeUsageFromDate(fromDateKey: String): Flow<List<DailyUsageEntity>>

    @Query("SELECT * FROM daily_usage ORDER BY dateKey DESC")
    fun observeAllUsage(): Flow<List<DailyUsageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: DailyUsageEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entities: List<DailyUsageEntity>)

    @Query("DELETE FROM daily_usage")
    suspend fun clearAll()
}
