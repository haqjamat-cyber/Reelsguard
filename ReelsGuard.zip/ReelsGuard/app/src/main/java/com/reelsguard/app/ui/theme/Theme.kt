package com.reelsguard.app.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.reelsguard.app.model.ThemeMode

@Immutable
data class ReelsGuardExtraColors(
    val isDark: Boolean,
    val backgroundTop: Color,
    val backgroundBottom: Color,
    val glassSurface: Color,
    val glassBorderStart: Color,
    val glassBorderEnd: Color,
    val accentPurple: Color,
    val accentBlue: Color,
    val accentCyan: Color,
    val success: Color,
    val warning: Color,
    val danger: Color,
    val subtleTrack: Color
)

private val DarkExtraColors = ReelsGuardExtraColors(
    isDark = true,
    backgroundTop = DeepObsidian,
    backgroundBottom = DarkNavy,
    glassSurface = ElevatedNavy.copy(alpha = 0.78f),
    glassBorderStart = Color.White.copy(alpha = 0.14f),
    glassBorderEnd = ElectricPurple.copy(alpha = 0.22f),
    accentPurple = ElectricPurple,
    accentBlue = ElectricBlue,
    accentCyan = CyanGlow,
    success = EmeraldSuccess,
    warning = AmberWarning,
    danger = CoralAlert,
    subtleTrack = Color.White.copy(alpha = 0.08f)
)

private val LightExtraColors = ReelsGuardExtraColors(
    isDark = false,
    backgroundTop = PorcelainBg,
    backgroundBottom = Color(0xFFE9EEF9),
    glassSurface = LightSurface.copy(alpha = 0.92f),
    glassBorderStart = DeepPurpleLightMode.copy(alpha = 0.12f),
    glassBorderEnd = DeepBlueLightMode.copy(alpha = 0.14f),
    accentPurple = DeepPurpleLightMode,
    accentBlue = DeepBlueLightMode,
    accentCyan = Color(0xFF0891B2),
    success = Color(0xFF059669),
    warning = Color(0xFFD97706),
    danger = Color(0xFFE11D48),
    subtleTrack = Color(0xFF0E1325).copy(alpha = 0.08f)
)

val LocalReelsGuardColors = staticCompositionLocalOf { DarkExtraColors }

private val DarkColorScheme = darkColorScheme(
    primary = ElectricPurple,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF281D56),
    onPrimaryContainer = ElectricPurpleLight,
    secondary = ElectricBlue,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF17274E),
    onSecondaryContainer = Color(0xFF93C5FD),
    tertiary = CyanGlow,
    onTertiary = DeepObsidian,
    background = DeepObsidian,
    onBackground = InkWhite,
    surface = DarkNavy,
    onSurface = InkWhite,
    surfaceVariant = ElevatedNavy,
    onSurfaceVariant = InkSlateMuted,
    outline = Color(0xFF2A3459),
    error = CoralAlert,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = DeepPurpleLightMode,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFEDE9FE),
    onPrimaryContainer = Color(0xFF3B1FA6),
    secondary = DeepBlueLightMode,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFDBEAFE),
    onSecondaryContainer = Color(0xFF1E3A8A),
    tertiary = Color(0xFF0891B2),
    onTertiary = Color.White,
    background = PorcelainBg,
    onBackground = LightInkPrimary,
    surface = LightSurface,
    onSurface = LightInkPrimary,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightInkSecondary,
    outline = Color(0xFFCBD5E1),
    error = Color(0xFFE11D48),
    onError = Color.White
)

object ReelsGuardTheme {
    val colors: ReelsGuardExtraColors
        @Composable get() = LocalReelsGuardColors.current
}

@Composable
fun ReelsGuardTheme(
    themeMode: ThemeMode = ThemeMode.DARK,
    content: @Composable () -> Unit
) {
    val useDark = when (themeMode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val colorScheme = if (useDark) DarkColorScheme else LightColorScheme
    val extraColors = if (useDark) DarkExtraColors else LightExtraColors

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.getInsetsController(window, view).apply {
                    isAppearanceLightStatusBars = !useDark
                    isAppearanceLightNavigationBars = !useDark
                }
            }
        }
    }

    CompositionLocalProvider(LocalReelsGuardColors provides extraColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = ReelsGuardTypography,
            content = content
        )
    }
}
