package com.reelsguard.app.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.reelsguard.app.model.BlockMode
import com.reelsguard.app.model.Platform

/**
 * Per-platform configuration.
 * [dailyVideoLimit] defaults to 0 (not set) so no number is pre-filled;
 * the user types their own daily video target.
 */
@Entity(tableName = "platform_limits")
data class PlatformLimitEntity(
    @PrimaryKey
    val platform: Platform,
    val isTrackingEnabled: Boolean = true,
    val isLimitEnabled: Boolean = false,
    val dailyVideoLimit: Int = 0,
    val blockMode: BlockMode = BlockMode.SECTION_ONLY,
    val updatedAtEpochMs: Long = System.currentTimeMillis()
)
