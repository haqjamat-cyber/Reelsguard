package com.reelsguard.app.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.reelsguard.app.model.BlockMode
import com.reelsguard.app.model.Platform

@Entity(tableName = "platform_limits")
data class PlatformLimitEntity(
    @PrimaryKey
    val platform: Platform,
    val isTrackingEnabled: Boolean = true,
    val isLimitEnabled: Boolean = true,
    val dailyLimitMinutes: Int = platform.defaultLimitMinutes,
    val blockMode: BlockMode = BlockMode.SECTION_ONLY,
    val updatedAtEpochMs: Long = System.currentTimeMillis()
)
