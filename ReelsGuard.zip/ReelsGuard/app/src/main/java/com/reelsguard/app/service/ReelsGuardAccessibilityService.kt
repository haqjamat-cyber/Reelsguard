package com.reelsguard.app.service

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import android.view.accessibility.AccessibilityEvent
import com.reelsguard.app.ReelsGuardApplication
import com.reelsguard.app.model.BlockMode
import com.reelsguard.app.model.Platform
import com.reelsguard.app.ui.blocking.BlockingActivity
import com.reelsguard.app.utils.ResetScheduleCalculator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

/**
 * User-consented Android AccessibilityService for ReelsGuard.
 *
 * Google Play Accessibility API Compliance & Privacy Guarantees:
 * - Scoped strictly to Instagram, YouTube, and Facebook packages via `accessibility_service_config.xml`.
 * - Never reads passwords, messages, or personal user data; inspects only minimal UI structural cues
 *   to recognize Reels/Shorts viewing surfaces.
 * - All timing and enforcement occur 100% locally on the device; zero telemetry leaves the device.
 * - Cannot and does not modify third-party applications internally; uses standard Android navigation
 *   actions (`GLOBAL_ACTION_BACK` / `GLOBAL_ACTION_HOME`) and launches ReelsGuard's own BlockingActivity.
 */
class ReelsGuardAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    @Volatile
    private var activePlatform: Platform? = null

    @Volatile
    private var isActiveScreenShortForm: Boolean = false

    private var tickerJob: Job? = null
    private val lastBlockLaunchTimes = ConcurrentHashMap<Platform, Long>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        startTrackingTicker()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkgName = event.packageName?.toString() ?: return

        // Ignore our own UI or system overlays from resetting tracking abruptly unless user left target app
        if (pkgName == packageName) {
            activePlatform = null
            isActiveScreenShortForm = false
            return
        }

        val platform = Platform.fromPackageName(pkgName)
        if (platform == null) {
            activePlatform = null
            isActiveScreenShortForm = false
            return
        }

        val snapshot = ReelsSectionDetector.extractSnapshot(
            rootNode = rootInActiveWindow,
            packageName = pkgName,
            eventClassName = event.className?.toString()
        )
        val detection = ReelsSectionDetector.detect(snapshot)

        activePlatform = platform
        isActiveScreenShortForm = detection.isShortFormSection

        // Immediate enforcement check on screen transitions
        serviceScope.launch {
            evaluateAndEnforceIfNeeded(
                platform = platform,
                shortFormDetected = detection.isShortFormSection
            )
        }
    }

    override fun onInterrupt() {
        activePlatform = null
        isActiveScreenShortForm = false
    }

    override fun onDestroy() {
        tickerJob?.cancel()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun startTrackingTicker() {
        tickerJob?.cancel()
        tickerJob = serviceScope.launch {
            while (isActive) {
                delay(1_000L)
                val platform = activePlatform ?: continue
                if (!isDeviceInteractiveAndUnlocked()) continue

                val app = applicationContext as? ReelsGuardApplication ?: continue
                val repo = app.container.usageRepository
                val limit = repo.getLimitForPlatform(platform)
                if (!limit.isTrackingEnabled) continue

                if (isActiveScreenShortForm) {
                    repo.addVerifiedReelsSeconds(platform, 1L)
                }

                evaluateAndEnforceIfNeeded(
                    platform = platform,
                    shortFormDetected = isActiveScreenShortForm
                )
            }
        }
    }

    private suspend fun evaluateAndEnforceIfNeeded(
        platform: Platform,
        shortFormDetected: Boolean
    ) {
        val app = applicationContext as? ReelsGuardApplication ?: return
        val container = app.container
        val repo = container.usageRepository

        repo.ensureDailyResetIfNeeded()
        val prefs = container.preferencesRepository.currentPreferences()
        val dateKey = ResetScheduleCalculator.getCurrentCycleDateKey(
            resetHour = prefs.resetHour,
            resetMinute = prefs.resetMinute
        )

        val limitConfig = repo.getLimitForPlatform(platform)
        val todayRows = repo.getTodayUsage(dateKey)
        val platformRow = todayRows.firstOrNull { it.platform == platform }

        val platformUsedSeconds = when (limitConfig.blockMode) {
            BlockMode.SECTION_ONLY -> platformRow?.verifiedReelsSeconds ?: 0L
            BlockMode.FULL_APP_FALLBACK -> {
                val verified = platformRow?.verifiedReelsSeconds ?: 0L
                val fallback = platformRow?.fallbackAppSeconds ?: 0L
                maxOf(verified, fallback)
            }
        }

        val totalUsedSeconds = todayRows.sumOf { row ->
            if (row.verifiedReelsSeconds > 0L) row.verifiedReelsSeconds else row.fallbackAppSeconds
        }

        val decision = BlockingDecisionEngine.evaluate(
            hasAccessibilityPermission = true, // Running inside connected AccessibilityService
            platform = platform,
            limitConfig = limitConfig,
            isShortFormSectionDetected = shortFormDetected,
            platformUsedSeconds = platformUsedSeconds,
            totalUsedSecondsAcrossPlatforms = totalUsedSeconds,
            totalDailyLimitMinutes = prefs.totalDailyLimitMinutes,
            isTotalDailyLimitEnabled = prefs.isTotalDailyLimitEnabled
        )

        if (decision is BlockingDecision.Block) {
            executeBlock(decision)
        }
    }

    private suspend fun executeBlock(decision: BlockingDecision.Block) {
        val now = System.currentTimeMillis()
        val lastLaunched = lastBlockLaunchTimes[decision.platform] ?: 0L
        if (now - lastLaunched < BLOCK_COOLDOWN_MS) return
        lastBlockLaunchTimes[decision.platform] = now

        val app = applicationContext as? ReelsGuardApplication
        app?.container?.usageRepository?.recordBlockingEvent(
            platform = decision.platform,
            mode = decision.mode,
            usageSecondsAtBlock = decision.usedSeconds,
            limitMinutesAtBlock = decision.limitMinutes,
            reason = decision.reason
        )

        // Exit Reels/Shorts section or return home depending on user-configured block mode
        when (decision.mode) {
            BlockMode.SECTION_ONLY -> performGlobalAction(GLOBAL_ACTION_BACK)
            BlockMode.FULL_APP_FALLBACK -> performGlobalAction(GLOBAL_ACTION_HOME)
        }

        val blockIntent = Intent(this, BlockingActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(BlockingActivity.EXTRA_PLATFORM, decision.platform.name)
            putExtra(BlockingActivity.EXTRA_USED_SECONDS, decision.usedSeconds)
            putExtra(BlockingActivity.EXTRA_LIMIT_MINUTES, decision.limitMinutes)
            putExtra(BlockingActivity.EXTRA_BLOCK_MODE, decision.mode.name)
            putExtra(BlockingActivity.EXTRA_REASON, decision.reason)
            putExtra(BlockingActivity.EXTRA_IS_PREVIEW, false)
        }
        runCatching { startActivity(blockIntent) }
    }

    private fun isDeviceInteractiveAndUnlocked(): Boolean {
        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        val interactive = powerManager?.isInteractive ?: true
        val locked = keyguardManager?.isKeyguardLocked ?: false
        return interactive && !locked
    }

    companion object {
        private const val BLOCK_COOLDOWN_MS = 2_500L
    }
}
