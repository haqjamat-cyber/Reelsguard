package com.reelsguard.app.service

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import android.view.accessibility.AccessibilityEvent
import com.reelsguard.app.ReelsGuardApplication
import com.reelsguard.app.model.BlockMode
import com.reelsguard.app.model.Platform
import com.reelsguard.app.ui.blocking.BlockingActivity
import com.reelsguard.app.utils.ResetScheduleCalculator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs

class ReelsGuardAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val reelCountTracker = ReelCountTracker()
    private var dynamicIslandOverlay: DynamicIslandOverlayManager? = null

    @Volatile
    private var activePlatform: Platform? = null

    @Volatile
    private var activePackageName: String? = null

    @Volatile
    private var isActiveScreenShortForm: Boolean = false

    private var tickerJob: Job? = null
    private val lastBlockLaunchTimes = ConcurrentHashMap<Platform, Long>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        dynamicIslandOverlay = DynamicIslandOverlayManager(this)
        startTrackingTicker()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkgName = event.packageName?.toString() ?: return

        if (pkgName == packageName) {
            clearActiveSession()
            return
        }

        val platform = Platform.fromPackageName(pkgName)
        if (platform == null) {
            clearActiveSession()
            return
        }

        val snapshot = ReelsSectionDetector.extractSnapshot(
            rootNode = rootInActiveWindow,
            packageName = pkgName,
            eventClassName = event.className?.toString()
        )
        val detection = ReelsSectionDetector.detect(snapshot)

        activePlatform = platform
        activePackageName = pkgName
        isActiveScreenShortForm = detection.isShortFormSection

        val isVerticalScroll = isVerticalScrollEvent(event)
        val scrollIndexKey = if (event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED &&
            event.fromIndex >= 0 && event.toIndex >= 0
        ) {
            "${event.fromIndex}:${event.toIndex}"
        } else {
            ""
        }

        val videoCompleted = reelCountTracker.onObservation(
            platform = platform,
            isShortFormSection = detection.isShortFormSection,
            nowMs = System.currentTimeMillis(),
            playbackProgressFraction = snapshot.playbackProgressFraction,
            isVideoPaused = snapshot.isVideoPaused,
            videoFingerprint = snapshot.videoFingerprint,
            isVerticalScrollEvent = isVerticalScroll,
            scrollIndexKey = scrollIndexKey
        )

        serviceScope.launch {
            handleObservationResult(
                platform = platform,
                isShortForm = detection.isShortFormSection,
                videoCompleted = videoCompleted
            )
        }
    }

    override fun onInterrupt() {
        clearActiveSession()
    }

    override fun onDestroy() {
        tickerJob?.cancel()
        dynamicIslandOverlay?.destroy()
        dynamicIslandOverlay = null
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun clearActiveSession() {
        activePlatform = null
        activePackageName = null
        isActiveScreenShortForm = false
        reelCountTracker.onLeftMonitoredApps(System.currentTimeMillis())
        dynamicIslandOverlay?.hide()
    }

    private fun isVerticalScrollEvent(event: AccessibilityEvent): Boolean {
        if (event.eventType != AccessibilityEvent.TYPE_VIEW_SCROLLED) return false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val dx = abs(event.scrollDeltaX)
            val dy = abs(event.scrollDeltaY)
            if (dx > 0 && dy == 0) return false
            if (dx > dy * 2 && dx > 40) return false
        }
        return true
    }

    private suspend fun handleObservationResult(
        platform: Platform,
        isShortForm: Boolean,
        videoCompleted: Boolean
    ) {
        val app = applicationContext as? ReelsGuardApplication ?: return
        val container = app.container
        val prefs = container.preferencesRepository.currentPreferences()
        val repo = container.usageRepository
        val limit = repo.getLimitForPlatform(platform)

        if (!limit.isTrackingEnabled) {
            dynamicIslandOverlay?.hide()
            return
        }

        if (videoCompleted) {
            repo.incrementWatchedReelsCount(platform, 1)
        }

        val dateKey = ResetScheduleCalculator.getCurrentCycleDateKey(
            resetHour = prefs.resetHour,
            resetMinute = prefs.resetMinute
        )
        val todayRows = repo.getTodayUsage(dateKey)
        val platformWatched = todayRows.firstOrNull { it.platform == platform }?.watchedReelsCount ?: 0
        val totalWatched = todayRows.sumOf { it.watchedReelsCount }

        val (displayCount, displayTarget) = resolveOverlayNumbers(
            platformWatched = platformWatched,
            platformTarget = if (limit.isLimitEnabled) limit.dailyVideoLimit else 0,
            totalWatched = totalWatched,
            totalTarget = if (prefs.isTotalDailyLimitEnabled) prefs.totalDailyVideoLimit else 0
        )

        if (prefs.showDynamicIslandCounter && isDeviceInteractiveAndUnlocked()) {
            dynamicIslandOverlay?.showOrUpdate(
                platform = platform,
                watchedCount = displayCount,
                targetCount = displayTarget,
                isActivelyInReels = isShortForm,
                animateIncrement = videoCompleted
            )
        } else {
            dynamicIslandOverlay?.hide()
        }

        evaluateAndEnforceIfNeeded(
            platform = platform,
            shortFormDetected = isShortForm
        )
    }

    private fun resolveOverlayNumbers(
        platformWatched: Int,
        platformTarget: Int,
        totalWatched: Int,
        totalTarget: Int
    ): Pair<Int, Int> {
        return when {
            platformTarget > 0 -> platformWatched to platformTarget
            totalTarget > 0 -> totalWatched to totalTarget
            else -> platformWatched to 0
        }
    }

    private fun startTrackingTicker() {
        tickerJob?.cancel()
        tickerJob = serviceScope.launch {
            while (isActive) {
                delay(1_000L)
                val platform = activePlatform ?: continue
                val pkgName = activePackageName ?: continue
                if (!isDeviceInteractiveAndUnlocked()) {
                    dynamicIslandOverlay?.hide()
                    continue
                }

                val rootNode = runCatching { rootInActiveWindow }.getOrNull()
                val currentWindowPkg = runCatching { rootNode?.packageName?.toString() }.getOrNull()
                if (currentWindowPkg != null &&
                    currentWindowPkg != SYSTEM_UI_PACKAGE &&
                    Platform.fromPackageName(currentWindowPkg) == null
                ) {
                    clearActiveSession()
                    continue
                }

                val app = applicationContext as? ReelsGuardApplication ?: continue
                val repo = app.container.usageRepository
                val limit = repo.getLimitForPlatform(platform)
                if (!limit.isTrackingEnabled) {
                    dynamicIslandOverlay?.hide()
                    continue
                }

                // Sample live progress bar, pause status & fingerprint every second so completion counts immediately
                val snapshot = ReelsSectionDetector.extractSnapshot(
                    rootNode = rootNode,
                    packageName = pkgName,
                    eventClassName = null
                )
                val detection = ReelsSectionDetector.detect(snapshot)
                isActiveScreenShortForm = detection.isShortFormSection

                val videoCompleted = reelCountTracker.onObservation(
                    platform = platform,
                    isShortFormSection = detection.isShortFormSection,
                    nowMs = System.currentTimeMillis(),
                    playbackProgressFraction = snapshot.playbackProgressFraction,
                    isVideoPaused = snapshot.isVideoPaused,
                    videoFingerprint = snapshot.videoFingerprint,
                    isVerticalScrollEvent = false
                )

                if (detection.isShortFormSection && !snapshot.isVideoPaused) {
                    repo.addVerifiedReelsSeconds(platform, 1L)
                }

                handleObservationResult(
                    platform = platform,
                    isShortForm = detection.isShortFormSection,
                    videoCompleted = videoCompleted
                )
            }
        }
    }

    private suspend fun evaluateAndEnforceIfNeeded(
        platform: Platform,
        shortFormDetected: Boolean
    ) {
        val app = applicationContext as? ReelsGuardApplication ?: return
        val container = app.container
        val repo = container.usageRepository

        repo.ensureDailyResetIfNeeded()
        val prefs = container.preferencesRepository.currentPreferences()
        val dateKey = ResetScheduleCalculator.getCurrentCycleDateKey(
            resetHour = prefs.resetHour,
            resetMinute = prefs.resetMinute
        )

        val limitConfig = repo.getLimitForPlatform(platform)
        val todayRows = repo.getTodayUsage(dateKey)
        val platformWatchedVideos = todayRows.firstOrNull { it.platform == platform }?.watchedReelsCount ?: 0
        val totalWatchedVideos = todayRows.sumOf { it.watchedReelsCount }

        val decision = BlockingDecisionEngine.evaluate(
            hasAccessibilityPermission = true,
            platform = platform,
            limitConfig = limitConfig,
            isShortFormSectionDetected = shortFormDetected,
            platformWatchedVideos = platformWatchedVideos,
            totalWatchedVideosAcrossPlatforms = totalWatchedVideos,
            totalDailyVideoLimit = prefs.totalDailyVideoLimit,
            isTotalDailyLimitEnabled = prefs.isTotalDailyLimitEnabled
        )

        if (decision is BlockingDecision.Block) {
            executeBlock(decision)
        }
    }

    private suspend fun executeBlock(decision: BlockingDecision.Block) {
        val now = System.currentTimeMillis()
        val lastLaunched = lastBlockLaunchTimes[decision.platform] ?: 0L
        if (now - lastLaunched < BLOCK_COOLDOWN_MS) return
        lastBlockLaunchTimes[decision.platform] = now

        dynamicIslandOverlay?.hide()

        val app = applicationContext as? ReelsGuardApplication
        app?.container?.usageRepository?.recordBlockingEvent(
            platform = decision.platform,
            mode = decision.mode,
            usageSecondsAtBlock = decision.watchedVideos.toLong(),
            limitMinutesAtBlock = decision.limitVideos,
            reason = decision.reason
        )

        when (decision.mode) {
            BlockMode.SECTION_ONLY -> performGlobalAction(GLOBAL_ACTION_BACK)
            BlockMode.FULL_APP_FALLBACK -> performGlobalAction(GLOBAL_ACTION_HOME)
        }

        val blockIntent = Intent(this, BlockingActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(BlockingActivity.EXTRA_PLATFORM, decision.platform.name)
            putExtra(BlockingActivity.EXTRA_WATCHED_VIDEOS, decision.watchedVideos)
            putExtra(BlockingActivity.EXTRA_LIMIT_VIDEOS, decision.limitVideos)
            putExtra(BlockingActivity.EXTRA_BLOCK_MODE, decision.mode.name)
            putExtra(BlockingActivity.EXTRA_REASON, decision.reason)
            putExtra(BlockingActivity.EXTRA_IS_PREVIEW, false)
        }
        runCatching { startActivity(blockIntent) }
    }

    private fun isDeviceInteractiveAndUnlocked(): Boolean {
        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        val interactive = powerManager?.isInteractive ?: true
        val locked = keyguardManager?.isKeyguardLocked ?: false
        return interactive && !locked
    }

    companion object {
        private const val BLOCK_COOLDOWN_MS = 2_500L
        private const val SYSTEM_UI_PACKAGE = "com.android.systemui"
    }
}
