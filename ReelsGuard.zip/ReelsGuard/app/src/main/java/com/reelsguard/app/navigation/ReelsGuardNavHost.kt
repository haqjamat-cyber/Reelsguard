package com.reelsguard.app.navigation

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.reelsguard.app.AppContainer
import com.reelsguard.app.analytics.AnalyticsScreen
import com.reelsguard.app.analytics.AnalyticsViewModel
import com.reelsguard.app.analytics.WeeklyReportsScreen
import com.reelsguard.app.settings.SettingsScreen
import com.reelsguard.app.settings.SettingsViewModel
import com.reelsguard.app.ui.ReelsGuardViewModelFactory
import com.reelsguard.app.ui.about.AboutScreen
import com.reelsguard.app.ui.achievements.AchievementScreen
import com.reelsguard.app.ui.achievements.AchievementViewModel
import com.reelsguard.app.ui.dashboard.DashboardScreen
import com.reelsguard.app.ui.dashboard.DashboardViewModel
import com.reelsguard.app.ui.limits.DailyLimitScreen
import com.reelsguard.app.ui.limits.DailyLimitViewModel
import com.reelsguard.app.ui.onboarding.OnboardingScreen
import com.reelsguard.app.ui.permissions.PermissionSetupScreen
import com.reelsguard.app.ui.permissions.PermissionViewModel
import com.reelsguard.app.ui.platforms.PlatformManagementScreen
import com.reelsguard.app.ui.platforms.PlatformManagementViewModel
import com.reelsguard.app.ui.splash.SplashScreen
import com.reelsguard.app.ui.theme.ReelsGuardTheme
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

@Composable
fun ReelsGuardNavHost(container: AppContainer) {
    val navController = rememberNavController()
    val factory = remember(container) { ReelsGuardViewModelFactory(container) }
    val scope = rememberCoroutineScope()
    val extra = ReelsGuardTheme.colors

    val onboardingCompleted by container.preferencesRepository.preferencesFlow
        .map { it.onboardingCompleted as Boolean? }
        .collectAsStateWithLifecycle(initialValue = null)

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val showBottomBar = primaryBottomNavDestinations.any { it.route == currentRoute }

    // Shared ViewModels scoped cleanly to navigation host
    val analyticsViewModel: AnalyticsViewModel = viewModel(factory = factory)

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Color.Transparent,
        bottomBar = {
            if (showBottomBar) {
                Surface(
                    color = extra.glassSurface,
                    tonalElevation = 6.dp,
                    modifier = Modifier.clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                ) {
                    NavigationBar(
                        containerColor = Color.Transparent,
                        tonalElevation = 0.dp
                    ) {
                        primaryBottomNavDestinations.forEach { destination ->
                            val selected = currentRoute == destination.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(destination.route) {
                                        popUpTo(Screen.Dashboard.route) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = {
                                    Icon(
                                        imageVector = destination.icon,
                                        contentDescription = destination.label
                                    )
                                },
                                label = {
                                    Text(
                                        text = destination.label,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = extra.accentPurple,
                                    selectedTextColor = extra.accentPurple,
                                    indicatorColor = extra.accentPurple.copy(alpha = 0.16f),
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        val bottomPadding = PaddingValues(bottom = innerPadding.calculateBottomPadding())

        NavHost(
            navController = navController,
            startDestination = Screen.Splash.route
        ) {
            composable(Screen.Splash.route) {
                SplashScreen(
                    onboardingCompleted = onboardingCompleted,
                    onNavigateToOnboarding = {
                        navController.navigate(Screen.Onboarding.route) {
                            popUpTo(Screen.Splash.route) { inclusive = true }
                        }
                    },
                    onNavigateToDashboard = {
                        navController.navigate(Screen.Dashboard.route) {
                            popUpTo(Screen.Splash.route) { inclusive = true }
                        }
                    }
                )
            }

            composable(Screen.Onboarding.route) {
                OnboardingScreen(
                    onFinishToPermissions = {
                        scope.launch { container.preferencesRepository.setOnboardingCompleted(true) }
                        navController.navigate(Screen.Permissions.createRoute(fromOnboarding = true)) {
                            popUpTo(Screen.Onboarding.route) { inclusive = true }
                        }
                    },
                    onSkipToDashboard = {
                        scope.launch { container.preferencesRepository.setOnboardingCompleted(true) }
                        navController.navigate(Screen.Dashboard.route) {
                            popUpTo(Screen.Onboarding.route) { inclusive = true }
                        }
                    }
                )
            }

            composable(
                route = Screen.Permissions.route,
                arguments = listOf(navArgument("fromOnboarding") { type = NavType.BoolType })
            ) { entry ->
                val fromOnboarding = entry.arguments?.getBoolean("fromOnboarding") ?: false
                val vm: PermissionViewModel = viewModel(factory = factory)
                PermissionSetupScreen(
                    viewModel = vm,
                    showBackButton = !fromOnboarding,
                    onBack = { navController.popBackStack() },
                    onContinueToDashboard = {
                        if (fromOnboarding) {
                            navController.navigate(Screen.Dashboard.route) {
                                popUpTo(navController.graph.findStartDestination().id) { inclusive = true }
                            }
                        } else {
                            navController.popBackStack()
                        }
                    }
                )
            }

            composable(Screen.Dashboard.route) {
                val vm: DashboardViewModel = viewModel(factory = factory)
                DashboardScreen(
                    viewModel = vm,
                    onOpenSettings = { navController.navigate(Screen.Settings.route) },
                    onOpenPermissions = {
                        navController.navigate(Screen.Permissions.createRoute(fromOnboarding = false))
                    },
                    onOpenDailyLimits = { navController.navigate(Screen.DailyLimits.route) },
                    onOpenPlatforms = { navController.navigate(Screen.Platforms.route) },
                    contentBottomPadding = bottomPadding
                )
            }

            composable(Screen.Platforms.route) {
                val vm: PlatformManagementViewModel = viewModel(factory = factory)
                PlatformManagementScreen(
                    viewModel = vm,
                    onOpenDailyLimits = { navController.navigate(Screen.DailyLimits.route) },
                    onOpenPermissions = {
                        navController.navigate(Screen.Permissions.createRoute(fromOnboarding = false))
                    },
                    contentBottomPadding = bottomPadding
                )
            }

            composable(Screen.DailyLimits.route) {
                val vm: DailyLimitViewModel = viewModel(factory = factory)
                DailyLimitScreen(
                    viewModel = vm,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Analytics.route) {
                AnalyticsScreen(
                    viewModel = analyticsViewModel,
                    onOpenWeeklyReports = { navController.navigate(Screen.WeeklyReports.route) },
                    contentBottomPadding = bottomPadding
                )
            }

            composable(Screen.WeeklyReports.route) {
                WeeklyReportsScreen(
                    viewModel = analyticsViewModel,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Achievements.route) {
                val vm: AchievementViewModel = viewModel(factory = factory)
                AchievementScreen(
                    viewModel = vm,
                    contentBottomPadding = bottomPadding
                )
            }

            composable(Screen.Settings.route) {
                val vm: SettingsViewModel = viewModel(factory = factory)
                SettingsScreen(
                    viewModel = vm,
                    onOpenPermissions = {
                        navController.navigate(Screen.Permissions.createRoute(fromOnboarding = false))
                    },
                    onOpenDailyLimits = { navController.navigate(Screen.DailyLimits.route) },
                    onOpenAbout = { navController.navigate(Screen.About.route) },
                    contentBottomPadding = bottomPadding
                )
            }

            composable(Screen.About.route) {
                AboutScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}
