package com.reelsguard.app.utils

import java.util.Locale

object TimeFormatter {

    fun formatDurationCompact(totalSeconds: Long): String {
        val safe = totalSeconds.coerceAtLeast(0L)
        val hours = safe / 3600L
        val minutes = (safe % 3600L) / 60L
        val seconds = safe % 60L

        return when {
            hours > 0L -> "${hours}h ${minutes}m"
            minutes > 0L && seconds > 0L -> "${minutes}m ${seconds}s"
            minutes > 0L -> "${minutes}m"
            else -> "${seconds}s"
        }
    }

    fun formatMinutesReadable(minutes: Int): String {
        val safe = minutes.coerceAtLeast(0)
        val h = safe / 60
        val m = safe % 60
        return when {
            h > 0 && m > 0 -> "${h}h ${m}m"
            h > 0 -> "${h}h"
            else -> "${m}m"
        }
    }

    fun formatCountdown(millisRemaining: Long): String {
        val totalSeconds = (millisRemaining / 1000L).coerceAtLeast(0L)
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    }

    fun formatRemainingLabel(remainingSeconds: Long): String {
        if (remainingSeconds == Long.MAX_VALUE) return "No limit set"
        if (remainingSeconds <= 0L) return "Limit reached"
        return "${formatDurationCompact(remainingSeconds)} left"
    }
}
