package com.reelsguard.app.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "achievements")
data class AchievementEntity(
    @PrimaryKey
    val badgeId: String,
    val title: String,
    val description: String,
    val progressCurrent: Int = 0,
    val progressTarget: Int = 1,
    val isUnlocked: Boolean = false,
    val unlockedAtEpochMs: Long? = null
)
