package com.reelsguard.app.service

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.reelsguard.app.ReelsGuardApplication
import com.reelsguard.app.utils.ResetScheduleCalculator
import java.util.concurrent.TimeUnit

/**
 * Reliable WorkManager worker that closes the prior daily cycle at the user's configured
 * reset time (midnight or custom hour/minute), updates discipline streaks, and reschedules itself.
 */
class DailyResetWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val app = applicationContext as? ReelsGuardApplication ?: return Result.failure()
        val container = app.container
        return try {
            container.usageRepository.ensureDailyResetIfNeeded()
            container.usageRepository.syncFallbackUsageStatsIfPermitted()

            val prefs = container.preferencesRepository.currentPreferences()
            DailyResetScheduler.scheduleNextExactReset(
                context = applicationContext,
                resetHour = prefs.resetHour,
                resetMinute = prefs.resetMinute
            )
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}

object DailyResetScheduler {
    private const val EXACT_RESET_WORK_NAME = "reelsguard_exact_daily_reset"
    private const val PERIODIC_SAFETY_WORK_NAME = "reelsguard_periodic_reset_safety"

    fun scheduleNextExactReset(context: Context, resetHour: Int, resetMinute: Int) {
        val delayMs = ResetScheduleCalculator.millisUntilNextReset(
            resetHour = resetHour,
            resetMinute = resetMinute
        )
        val request = OneTimeWorkRequestBuilder<DailyResetWorker>()
            .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
            .build()

        WorkManager.getInstance(context.applicationContext).enqueueUniqueWork(
            EXACT_RESET_WORK_NAME,
            ExistingWorkPolicy.REPLACE,
            request
        )
    }

    fun ensurePeriodicSafetyCheck(context: Context) {
        val periodic = PeriodicWorkRequestBuilder<DailyResetWorker>(6, TimeUnit.HOURS).build()
        WorkManager.getInstance(context.applicationContext).enqueueUniquePeriodicWork(
            PERIODIC_SAFETY_WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            periodic
        )
    }
}
