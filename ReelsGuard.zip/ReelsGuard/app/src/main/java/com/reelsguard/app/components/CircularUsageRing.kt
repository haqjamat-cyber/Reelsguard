package com.reelsguard.app.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.reelsguard.app.ui.theme.ReelsGuardTheme

@Composable
fun CircularUsageRing(
    progress: Float,
    primaryValueText: String,
    secondaryLabel: String,
    subtitleText: String,
    modifier: Modifier = Modifier,
    ringSize: Dp = 214.dp,
    strokeWidth: Dp = 16.dp
) {
    val extra = ReelsGuardTheme.colors
    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 850, easing = FastOutSlowInEasing),
        label = "usage_ring_progress"
    )

    val ringColors = when {
        animatedProgress >= 1f -> listOf(extra.danger, extra.warning, extra.danger)
        animatedProgress >= 0.8f -> listOf(extra.warning, extra.accentPurple, extra.warning)
        else -> listOf(extra.accentPurple, extra.accentBlue, extra.accentCyan, extra.accentPurple)
    }

    Box(
        modifier = modifier.size(ringSize),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(ringSize)) {
            val strokePx = strokeWidth.toPx()
            val inset = strokePx / 2f + 6.dp.toPx()
            val arcSize = Size(size.width - inset * 2, size.height - inset * 2)
            val topLeft = Offset(inset, inset)

            // Outer soft glow ring when active
            if (animatedProgress > 0f && extra.isDark) {
                drawArc(
                    brush = Brush.sweepGradient(ringColors),
                    startAngle = -90f,
                    sweepAngle = animatedProgress * 360f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    alpha = 0.22f,
                    style = Stroke(width = strokePx + 10.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            // Background track
            drawArc(
                color = extra.subtleTrack,
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )

            // Active gradient arc
            if (animatedProgress > 0.005f) {
                drawArc(
                    brush = Brush.sweepGradient(ringColors),
                    startAngle = -90f,
                    sweepAngle = (animatedProgress * 360f).coerceAtLeast(4f),
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokePx, cap = StrokeCap.Round)
                )
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = secondaryLabel,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = primaryValueText,
                style = MaterialTheme.typography.displayMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitleText,
                style = MaterialTheme.typography.labelMedium,
                color = if (progress >= 1f) extra.danger else extra.accentBlue
            )
        }
    }
}
