package com.reelsguard.app.ui.about

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Policy
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.reelsguard.app.BuildConfig
import com.reelsguard.app.components.GlassCard
import com.reelsguard.app.components.PremiumBackground
import com.reelsguard.app.components.ScreenTopHeader
import com.reelsguard.app.ui.theme.ReelsGuardTheme

@Composable
fun AboutScreen(onBack: () -> Unit) {
    val extra = ReelsGuardTheme.colors

    PremiumBackground {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                ScreenTopHeader(
                    title = "About ReelsGuard",
                    subtitle = "Version ${BuildConfig.VERSION_NAME} (Build ${BuildConfig.VERSION_CODE})",
                    onBack = onBack
                )
            }

            item {
                InfoSectionCard(
                    icon = Icons.Rounded.Shield,
                    tint = extra.accentPurple,
                    title = "Purpose & Philosophy",
                    body = "ReelsGuard helps you build calmer, more intentional habits around short-form video feeds on Instagram Reels, YouTube Shorts, and Facebook Reels. Everything is designed to encourage steady focus without shaming or intrusive dark patterns."
                )
            }

            item {
                InfoSectionCard(
                    icon = Icons.Rounded.Lock,
                    tint = extra.success,
                    title = "100% Local Privacy Architecture",
                    body = "ReelsGuard stores your usage records, daily limits, blocking history, and milestone badges strictly in an on-device Room database and DataStore. No analytics SDKs, no remote servers, and no background data uploads exist in this application."
                )
            }

            item {
                InfoSectionCard(
                    icon = Icons.Rounded.Policy,
                    tint = extra.accentBlue,
                    title = "Android Platform Transparency",
                    body = "• ReelsGuard does NOT modify Instagram, YouTube, or Facebook internally.
" +
                        "• Android UsageStatsManager only reports whole-app foreground duration, never individual Reels/Shorts sections. ReelsGuard explicitly labels UsageStats data as 'Full-App Fallback'.
" +
                        "• Verified Reels/Shorts section detection and automatic limit enforcement use Android's user-consented AccessibilityService API scoped strictly to supported packages.
" +
                        "• Because third-party apps can update their layouts at any time, you can switch any platform to Full-App Fallback mode in Platform Management."
                )
            }
        }
    }
}

@Composable
private fun InfoSectionCard(
    icon: ImageVector,
    tint: androidx.compose.ui.graphics.Color,
    title: String,
    body: String
) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = null, tint = tint)
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = body,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
