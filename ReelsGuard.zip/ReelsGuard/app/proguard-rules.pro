# Preserve Room entities and DAOs
-keep class com.reelsguard.app.database.** { *; }

# Preserve AccessibilityService and BroadcastReceiver entry points
-keep class com.reelsguard.app.service.ReelsGuardAccessibilityService { *; }
-keep class com.reelsguard.app.receiver.BootAndTimeChangeReceiver { *; }
-keep class com.reelsguard.app.service.DailyResetWorker { *; }
