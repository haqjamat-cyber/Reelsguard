import java.net.URI

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.reelsguard.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.reelsguard.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "1.2.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

val ensurePoppinsFonts by tasks.registering {
    group = "reelsguard"
    description = "Ensures official Poppins TTF font files exist in app/src/main/assets/fonts/"
    doLast {
        val fontsDir = file("src/main/assets/fonts")
        if (!fontsDir.exists()) fontsDir.mkdirs()

        val fontFiles = listOf(
            "Poppins-Regular.ttf",
            "Poppins-Medium.ttf",
            "Poppins-SemiBold.ttf",
            "Poppins-Bold.ttf"
        )
        val mirrors = listOf(
            "https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/poppins/",
            "https://raw.githubusercontent.com/google/fonts/main/ofl/poppins/"
        )

        for (fontName in fontFiles) {
            val target = File(fontsDir, fontName)
            if (target.exists() && target.length() > 20_000L) continue

            var downloaded = false
            for (mirror in mirrors) {
                if (downloaded) break
                try {
                    val conn = URI(mirror + fontName).toURL().openConnection().apply {
                        connectTimeout = 8_000
                        readTimeout = 15_000
                        setRequestProperty("User-Agent", "ReelsGuard-Gradle-FontFetcher")
                    }
                    conn.getInputStream().use { input ->
                        val bytes = input.readBytes()
                        if (bytes.size > 20_000) {
                            target.writeBytes(bytes)
                            downloaded = true
                            logger.lifecycle("ReelsGuard: Downloaded $fontName (${bytes.size} bytes)")
                        }
                    }
                } catch (e: Exception) {
                    logger.info("ReelsGuard: Could not fetch $fontName from $mirror (${e.message})")
                }
            }
            if (!downloaded) {
                logger.warn("ReelsGuard: Offline while fetching $fontName; falling back to system sans-serif until next online build.")
            }
        }
    }
}

tasks.named("preBuild") {
    dependsOn(ensurePoppinsFonts)
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.core.splashscreen)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.material.icons.extended)
    implementation(libs.androidx.navigation.compose)

    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    implementation(libs.androidx.datastore.preferences)
    implementation(libs.androidx.work.runtime.ktx)
    implementation(libs.kotlinx.coroutines.android)

    implementation(libs.vico.compose)
    implementation(libs.vico.compose.m3)
    implementation(libs.vico.core)

    testImplementation(libs.junit)
    testImplementation(libs.kotlinx.coroutines.test)
    testImplementation(libs.androidx.room.testing)

    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.ui.test.junit4)
    debugImplementation(libs.androidx.ui.tooling)
    debugImplementation(libs.androidx.ui.test.manifest)
}
