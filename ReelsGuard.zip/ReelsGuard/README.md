# ReelsGuard — Digital Wellbeing & Short-Form Video Control for Android

**ReelsGuard** (`com.reelsguard.app`) is a native Android application built with **Kotlin**, **Jetpack Compose**, **Material Design 3**, **Room**, **DataStore**, **WorkManager**, and **Vico Compose Charts**. It helps users monitor and gently manage their daily viewing time across **Instagram Reels**, **YouTube Shorts**, and **Facebook Reels** while keeping 100% of activity data locally on the device.

---

## Features Implemented

### 1. Premium Home Dashboard
- Animated circular progress ring showing today's usage, daily limit, and remaining time.
- Live blocking status pill and daily discipline status banner with streak indicator.
- Individual usage cards for **Instagram Reels**, **YouTube Shorts**, and **Facebook Reels**.
- Automatic updates via Kotlin `StateFlow` + lifecycle `ON_RESUME` rechecks.

### 2. Honest Dual-Mode Tracking (Zero Misleading Metrics)
- **Verified Reels/Shorts Mode (AccessibilityService):** Uses a cautious, multi-signal heuristic (`ReelsSectionDetector`) scoped strictly to Instagram, YouTube, and Facebook windows to measure active short-form viewing time when the screen is interactive and unlocked.
- **Full-App Fallback Mode (UsageStatsManager):** Uses `UsageStatsManager.queryEvents()` to compute whole-app foreground time since the current reset cycle start. ReelsGuard stores this in a separate Room column (`fallbackAppSeconds`) and explicitly labels it **"Full-App Fallback"** — never disguising whole-app time as verified Reels viewing time.

### 3. Configurable Daily Limits & Automatic Blocking
- Individual daily limits (defaults: **Instagram 20m**, **YouTube 15m**, **Facebook 10m**) plus an optional **Total Daily Short-Form Limit** (default 45m).
- Quick preset chips, sliders, and +/- 5-minute steppers.
- Per-platform toggle between **Reels / Shorts Section** blocking (`GLOBAL_ACTION_BACK` + full-screen `BlockingActivity`) and **Full App Fallback** blocking (`GLOBAL_ACTION_HOME` + `BlockingActivity`).
- Strict permission verification (`BlockingDecisionEngine`): if Accessibility permission is not enabled, ReelsGuard never claims blocking succeeded.

### 4. Configurable Daily Reset System
- Supports **Midnight (12:00 AM)** or **Custom Reset Time** via Material 3 `TimePicker`.
- Timezone-aware cycle computation (`ResetScheduleCalculator` using `java.time.ZonedDateTime`).
- Scheduled via `WorkManager` (`DailyResetWorker` exact reset + 6-hour safety worker), restored on reboot/clock/timezone change via `BootAndTimeChangeReceiver`, and rechecked on every app launch/resume.

### 5. Analytics, Weekly Reports & Achievements
- **Analytics Screen:** Daily platform breakdown, 7-day Vico column chart, 30-day Vico trend line + discipline heatmap, platform-wise comparison, average daily usage, most-used platform, and historical records (zero hardcoded fake demo stats).
- **Weekly Reports Screen:** Week-over-week comparison delta, days within goal, pause screens shown, peak day, and constructive takeaway.
- **Achievements Screen:** Encouraging, guilt-free streak counters, 7-day check-in ribbon, and 7 milestone badges with progress bars.

### 6. All 12 Screens Included
1. Splash Screen (`ui/splash/SplashScreen.kt`)
2. Onboarding Screens (`ui/onboarding/OnboardingScreen.kt`)
3. Permission Setup Screen (`ui/permissions/PermissionSetupScreen.kt`)
4. Home Dashboard (`ui/dashboard/DashboardScreen.kt`)
5. Platform Management Screen (`ui/platforms/PlatformManagementScreen.kt`)
6. Daily Limit Configuration Screen (`ui/limits/DailyLimitScreen.kt`)
7. Blocking Screen & Activity (`ui/blocking/BlockingScreen.kt`, `BlockingActivity.kt`)
8. Analytics Screen (`analytics/AnalyticsScreen.kt`)
9. Weekly Reports Screen (`analytics/WeeklyReportsScreen.kt`)
10. Achievement Screen (`ui/achievements/AchievementScreen.kt`)
11. Settings Screen (`settings/SettingsScreen.kt`)
12. About Application Screen (`ui/about/AboutScreen.kt`)

---

## Architecture & Tech Stack

- **Architecture:** Clean MVVM with manual dependency injection (`AppContainer` + `ReelsGuardViewModelFactory`), Kotlin Coroutines, and `StateFlow`.
- **Min SDK:** API 26 (Android 8.0 Oreo) | **Compile/Target SDK:** API 35 (Android 15)
- **Language & Build:** Kotlin `2.0.21`, AGP `8.7.2`, Gradle `8.9`, KSP `2.0.21-1.0.28`, JVM 17
- **UI:** Jetpack Compose BOM `2024.11.00`, Material 3, Vico `1.15.0`
- **Persistence:** Room `2.6.1` + Preferences DataStore `1.1.1`
- **Scheduling:** WorkManager `2.10.0`

---

## Setup & Build Instructions (Android Studio)

1. **Extract the ZIP** archive to a local folder (e.g., `ReelsGuard/`).
2. Open **Android Studio Ladybug (2024.2) or newer** with **JDK 17** configured.
3. Choose **File > Open** and select the extracted `ReelsGuard` root folder.
4. Allow Android Studio to **Sync Project with Gradle Files** (Android Studio will automatically download Gradle 8.9 and Maven dependencies).
5. Run unit tests from Android Studio or terminal:
   ```bash
   ./gradlew testDebugUnitTest
   ```
   *(If `./gradlew` is not present locally, open the Gradle tool window in Android Studio and run `app > Tasks > verification > testDebugUnitTest`, or run `gradle wrapper` once.)*
6. Build & run on an Android 8.0+ (API 26+) device or emulator:
   - Select **Run 'app'** (`Shift + F10`).
   - On first launch, complete onboarding and grant **Accessibility Service** (*Settings > Accessibility > Installed apps > ReelsGuard Focus Monitor*) and/or **Usage Access** (*Settings > Usage access > ReelsGuard*).

---

## Android System Limitations & Google Play Compliance

- **No Internal App Modification:** ReelsGuard never hooks into, patches, or modifies Instagram, YouTube, or Facebook binaries.
- **Section Detection Resilience:** Because third-party apps periodically update their view hierarchies and resource IDs, `ReelsSectionDetector` uses multi-signal heuristics rather than a single brittle view ID. If an upstream app update changes Reels/Shorts layouts, users can immediately toggle **Full App Fallback** per platform in the **Apps** tab.
- **Explicit Consent & Privacy:** Accessibility permission is never enabled silently; a clear in-app disclosure precedes every Settings redirect. All Room and DataStore records remain strictly on the user's device (`android:allowBackup="false"` and backup exclusions configured).
